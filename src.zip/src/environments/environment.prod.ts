export const environment = {
  production: true,
  baseUrl: 'https://my.nsf.org/oneprodtrackrest/',
  env: 'test',
  envName: 'Production'
};
