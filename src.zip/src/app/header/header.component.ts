import { Component, Input, OnInit } from '@angular/core';
import { MsalService } from '../azure-config/msal';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  @Input() userName: string | undefined;
  envType: any;

  constructor() {
  }

  ngOnInit(): void {
    this.envType = environment.envName;
  }
  /**
   * Logout FUnctionality
   */
  logOut(): void {
    // this.authService.logout();
  }

}

