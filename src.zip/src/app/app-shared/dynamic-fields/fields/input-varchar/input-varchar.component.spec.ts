import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InputVarcharComponent } from './input-varchar.component';

describe('InputVarcharComponent', () => {
  let component: InputVarcharComponent;
  let fixture: ComponentFixture<InputVarcharComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InputVarcharComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InputVarcharComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
