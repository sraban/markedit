import { Component, Input, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';

@Component({
  selector: 'app-input-varchar',
  templateUrl: './input-varchar.component.html',
  styleUrls: ['./input-varchar.component.scss']
})
export class InputVarcharComponent implements OnInit {
  @Input() formGroup!: FormGroup;
  @Input() field: any;
  constructor() { }

  ngOnInit(): void {
  }

}
