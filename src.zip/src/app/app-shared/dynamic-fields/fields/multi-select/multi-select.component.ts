import { Component, Input, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';

@Component({
  selector: 'app-multi-select',
  templateUrl: './multi-select.component.html',
  styleUrls: ['./multi-select.component.scss']
})
export class MultiSelectComponent implements OnInit {
  @Input() field: any;
  @Input() formGroup!: FormGroup;

  constructor() { }

  ngOnInit(): void {
  }

}






// tried to implement select all option in multi-select dropdown

// fields: any;

//   @Input() set field(data: any){
//   //  this.selectAll(data);
//    this.fields = data;
//   }

// selectAll(value: any): void {
//   const dropDownData: any[] = [];
//   const selectAllData: any[] = [];
//   const data = value.dropdown_list;
//   data.forEach((item: any, i: number) => {
//     dropDownData[i] = {
//       dropdown_desc: item.dropdown_desc,
//     dropdown_code: item.dropdown_code,
//     };
//     // selectAllData[i] = item.dropdown_desc;
//   });
//   // const select = {
//   //   dropdown_desc : 'selectAll',
//   //   dropdown_code : selectAllData,
//   // };

//   // dropDownData.splice(0, 0, select);
//   console.log(dropDownData);
//   this.dropdownlist = dropDownData;
// }
