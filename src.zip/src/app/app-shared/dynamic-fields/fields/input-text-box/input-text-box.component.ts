import { Component, Input, OnInit } from '@angular/core';
import { FormArray, FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-input-text-box',
  templateUrl: './input-text-box.component.html',
  styleUrls: ['./input-text-box.component.scss']
})
export class InputTextBoxComponent implements OnInit {
  fields: any;
  alternateControl!: string;
  @Input() formGroup!: FormGroup;

  @Input() set field(data: any){
  this.fields = data;
  this.alternateControl = `alternate ${this.fields.field_name}`;
  }

  constructor() {
    this.formGroup = new FormGroup({});
  }

  ngOnInit(): void {
  }

  get alternateData(): any {
   return this.formGroup.get(`alternate ${this.fields.field_name}`) as FormArray;
  }

  addAlternateData(): any {
    this.alternateData.push(new FormControl(''));
  }

  clearAlternateData(index: number): void{
    const alternateArray = this.formGroup.get(`alternate ${this.fields.field_name}`) as FormArray;
    alternateArray.removeAt(index);
  }

}
