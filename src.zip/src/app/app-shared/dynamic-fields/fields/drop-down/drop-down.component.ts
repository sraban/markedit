import { Component, Input, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';

@Component({
  selector: 'app-drop-down',
  templateUrl: './drop-down.component.html',
  styleUrls: ['./drop-down.component.scss']
})
export class DropDownComponent implements OnInit {
  @Input() field: any;
  @Input() formGroup!: FormGroup;
  constructor() { }

  public defaultItem: { dropdown_desc: string; dropdown_code: any } = {
    dropdown_desc: '',
    dropdown_code: null,
  };

  ngOnInit(): void {}

}
