import { OnDestroy } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import { FormArray, FormControl, FormGroup, Validators } from '@angular/forms';
import { DataService } from 'src/app/common/data.service';

@Component({
  selector: 'app-dynamic-fields',
  templateUrl: './dynamic-fields.component.html',
  styleUrls: ['./dynamic-fields.component.scss']
})
export class DynamicFieldsComponent implements OnInit, OnDestroy {
  formGroup!: FormGroup;
  fields: any[] = [];
  fieldHeader!: string;

  constructor(private service: DataService) {
    this.formGroup = new FormGroup({});
  }

  ngOnInit(): void {
    this.setValuetoFields();
  }

  public submitForm(): void {
    // console.log(this.formGroup.value);
}

public resetForm(): void {
    this.formGroup.reset(this.formGroup);
}
// for testing purpose
setValuetoFields(): void{
   this.service.getTestFormFields().subscribe((data: any) => {
    this.fieldHeader = data.section_name;
    this.fields = data.dynamic_list;
    const fieldCtrls: any = {};
    this.fields.forEach((element: any) => {
    if (element.field_data_type === 'READONLY') {
      fieldCtrls[element.field_name] = new FormControl(element.field_value);
    } else if (element.field_data_type === 'TEXT') {
      fieldCtrls[element.field_name] = new FormControl(element.field_value || '', [Validators.required]);
      fieldCtrls['alternate ' + element.field_name] = new FormArray([]);
    } else if (element.field_data_type === 'CHECKBOX') {
      fieldCtrls[element.field_name] = new FormControl(element.field_value || false);
    } else if (element.field_data_type === 'DROPDOWN'){
      fieldCtrls[element.field_name] = new FormControl(element.field_value || '');
    }
    this.formGroup = new FormGroup(fieldCtrls);
  });
  });
}

ngOnDestroy(): void {
  // tslint:disable-next-line: no-unused-expression
  this.service.getTestFormFields().unsubscribe;
}

}
