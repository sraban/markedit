import {
  AfterViewInit, Component, ElementRef, EventEmitter, Input,
  OnInit, Output, Renderer2, ViewChild, ViewEncapsulation
} from '@angular/core';
import { FormGroup } from '@angular/forms';
import { DataBindingDirective, GridComponent, PageChangeEvent } from '@progress/kendo-angular-grid';
import { TooltipDirective } from '@progress/kendo-angular-tooltip';
import { ExcelExportData } from '@progress/kendo-angular-excel-export';
import { process } from '@progress/kendo-data-query';
import { PdfPrinterDirective } from '../directives/pdf-printer.directive';

const hasClass = (el: any, className: any) => new RegExp(className).test(el.className);

const isChildOf = (el: any, className: any) => {
  while (el && el.parentElement) {
    if (hasClass(el.parentElement, className)) {
      return true;
    }
    el = el.parentElement;
  }
  return false;
};

@Component({
  selector: 'app-kendo-grid',
  templateUrl: './kendo-grid.component.html',
  styleUrls: ['./kendo-grid.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class KendoGridComponent implements OnInit, AfterViewInit {
  @ViewChild(DataBindingDirective) dataBinding!: DataBindingDirective;
  @ViewChild(TooltipDirective) public tooltipDir!: TooltipDirective;
  @ViewChild('temp') public template!: ElementRef;

  // GridComponent hanldes edit a row, add a row, cancel,save functionalities
  @ViewChild(GridComponent) private grid !: GridComponent;

  public formGroup: any;
  public gridView: any[] = [];
  // tslint:disable-next-line: variable-name
  public grid_Data: any[] = [];
  public total: any;
  public dccValue: any;
  public standardValue: any;
  public facilityValue: any;
  public tradeValue: any;
  public supplierValue: any;
  public formulatorValue: any;
  public coNumberValue: any;
  public coNameValue: any;
  public facilityLocationValue: any;
  public dccStatusValue: any;
  public productStatusValue: any;

  @Input() set pageable(value: any) {
    if (value) {
      this.pagination = value.pageable;
      this.pageSize = value.pageSize;
      this.buttonCount = value.buttonCount;
      this.paginationAlignment();
    } else {
      this.pagination = false;
    }
  }
  // *****gridData - bind data to the grid****
  @Input() set gridData(value: any) {
    if (value?.count >= 0) {
      this.total = value.count;
      this.grid_Data = value.results;
      // this.pageData(value.results);
       this.paginationAlignment();
    }
    else {
      this.gridView = value;
      this.grid_Data = value;
    }
  }

  // ****columnHeaders - array of headers needed to specify title and field in kendo-grid
  public commonSearchFilter: any[] = [];
  public headers: any[] = [];
  @Input() set columnHeaders(data: any) {
    this.headers = data;
    data.forEach((field: any, i: number) => {
      this.commonSearchFilter.push({
        field: field.field,
        operator: 'contains',
      });
    });
  }

  // ****control - of type formGroup,needed for editing existing data and also adding a data
  @Input() control!: FormGroup;
  @Input() colGroupHeader: any;
  selectedData: any[] = [];
  pagination: any;
  pageSize: any;
  buttonCount!: number;
  pageSizes = 25;
  skip = 0;
  @Input() height: any;
  @Input() filterable = true;

  @Input() selectRowCheckbox!: string;

  editorTitle!: string;
  editorWidth!: number;
  editorType!: string;
  editorWithPopup!: boolean;
  @Input() set editorCol(data: { title: string, width: number, type: string, openPopUp: boolean }) {
    this.editorTitle = data.title;
    this.editorWidth = data.width;
    this.editorType = data.type;
    this.editorWithPopup = data.openPopUp;
  }

  private editedRowIndex: any;
  private isNew!: boolean;
  public mySelection: any[] = [];
  public pagerPageSize = [25, 50, 75, 100];
  public exportto!: boolean;
  public fileName!: string;
  @Input() set export(data: { exportto: boolean, fileName: string }) {
    this.exportto = data.exportto;
    this.fileName = data.fileName;
  }

  @Output() editedData = new EventEmitter();
  @Output() totalPageSize = new EventEmitter();
  @Output() filterGridData = new EventEmitter()
  internalList = [{ internal_flg: 'Y', internal_text: 'Yes' }, { internal_flg: 'N', internal_text: 'No' }];
  totalRows: any;

  constructor(private renderer: Renderer2, public printer: PdfPrinterDirective) {
    this.pageable = false;
    this.allData = this.allData.bind(this);
  }


  ngOnInit(): void {
    if (!this.editorType) {
      this.renderer.listen('document', 'click', ({ target }) => {
        if (!isChildOf(target, 'k-grid')) {
          this.saveRow();
        }
      });
    }
    this.renderer.listen('window', 'keydown', (e: Event) => {
      setTimeout(() => {
        const ele = document.querySelectorAll('input.k-textbox');
        ele.forEach(item => {
          if (e.target === item) {
            console.log(e.target, item);
            const pagerInfo = document.getElementsByClassName('k-grid-pager');
            const info = document.querySelectorAll('.k-pager-info');
            const nodatainfo = document.querySelectorAll('.nodataavail');
            this.totalRows = pagerInfo[0].attributes.getNamedItem('ng-reflect-total')?.value;
            if (!+this.totalRows) {
              info.forEach(pagerInfo => {
                pagerInfo.setAttribute('style', 'display:none');
              });
              nodatainfo.forEach(infoNoData => {
                infoNoData.removeAttribute('style');
              });
            } else {
              info.forEach(pagerInfo => {
                pagerInfo.removeAttribute('style');
              });
              nodatainfo.forEach(infoNoData => {
                infoNoData.setAttribute('style', 'display:none');
              });
            }
          }
        });
      }, 550);
    });
  }
  public exportToExcel(grid: GridComponent): void {
    grid.saveAsExcel();
  }

  ngAfterViewInit(): void {
    // **** Pagination icons to letter(First, Last)****
    if (this.pagination) {
      this.paginationAlignment();
    }
  }

  // ****add handler - handles adding a row***
  public addHandler(): void {
    this.closeEditor();
    this.formGroup = this.control;
    this.formGroup.reset();
    this.isNew = true;
    this.grid.addRow(this.formGroup);
  }

  public editHandler({ sender, rowIndex, dataItem }: { sender: any, rowIndex: any, dataItem: any }): void {
    this.isNew = false;
    this.closeEditor();
    if (this.editorWithPopup) {
      const data = ['openDialog', dataItem];
      this.editedData.emit(data);
    } else {
      if (dataItem.hasOwnProperty('internal_flg')) {
        if (dataItem.internal_flg === 'Y') {
          dataItem.internal_flg = true;
        } else {
          dataItem.internal_flg = false;
        }
      }
      this.formGroup = this.control;
      this.formGroup.patchValue(dataItem);
      this.editedRowIndex = rowIndex;
      this.grid.editRow(rowIndex, this.formGroup);
      this.editedRowIndex = rowIndex;
      sender.editRow(rowIndex, this.formGroup);
    }

  }

  public saveHandler({ sender, rowIndex, isNew }: { sender: any, rowIndex: number, isNew: boolean }): void {
    let saveEditedData;
    if (isNew) {
      saveEditedData = ['newData', this.formGroup.value];
    } else {
      saveEditedData = ['editData', this.formGroup.value, rowIndex];
    }
    this.editedData.emit(saveEditedData);
    sender.closeRow(rowIndex);
  }

  public removeHandler({ rowIndex, dataItem }: { rowIndex: any, dataItem: any }): void {
    const removeData = ['removeData', dataItem, rowIndex];
    this.editedData.emit(removeData);
  }


  public saveRow(): void {
    if (this.formGroup && this.formGroup.valid) {
      this.saveCurrent();
    } else if (this.mySelection.length !== 0) {
      this.mySelection.forEach((item: any) => {
        this.grid_Data.forEach((data: any) => {
          if (data[this.selectRowCheckbox] === item) {
            this.selectedData.push(data);
          }
        });
      });
    }
    this.mySelection = [];
  }

  // ****Edit handler - handles editing a particular row****
  public cellClickHandler({ isEdited, dataItem, rowIndex }: { isEdited: boolean, dataItem: any, rowIndex: number }): void {
    if (!this.editorType) {
      if (isEdited || (this.formGroup && !this.formGroup.valid)) {
        return;
      }
      if (this.isNew) {
        rowIndex += 1;
      }

      this.saveCurrent();
      if (this.control) {
        this.formGroup = this.control;
        this.formGroup.patchValue(dataItem);
        this.editedRowIndex = rowIndex;
        this.grid.editRow(rowIndex, this.formGroup);
      } else {
        this.editedData.emit(dataItem);
      }
    }
  }

  // cancel editing or adding data
  public cancelHandler({ sender, rowIndex, dataItem }: { sender: any, rowIndex: number, dataItem: any }): void {
    if (dataItem.hasOwnProperty('internal_flg')) {
      if (dataItem.internal_flg === true) {
        dataItem.internal_flg = 'Y';
      } else {
        dataItem.internal_flg = 'N';
      }
    }
    this.closeEditor();
  }

  private closeEditor(): void {
    this.grid.closeRow(this.editedRowIndex);
    this.isNew = false;
    this.editedRowIndex = undefined;
    this.formGroup = undefined;
  }

  // ***send the edited and added data to parent component or server***
  private saveCurrent(): void {
    if (this.formGroup) {
      this.editedData.emit(this.formGroup.value);
      this.closeEditor();
    }
  }

  public allData(): ExcelExportData {
    return { data: this.grid_Data };
  }

  public onFilter(value: any): void {
    const inputValue = value.target.value;
    this.commonSearchFilter.forEach((item: any) => {
      item.value = inputValue;
    });
    this.grid_Data = process(this.gridView, {
      filter: {
        logic: 'or',
        filters: this.commonSearchFilter,

      }
    }).data;

    this.dataBinding.skip = 0;
  }

  public onPageChange(e: PageChangeEvent): any {
    console.log(e)
      const currentPage = (e.skip + this.pageSize) / this.pageSize;
    this.skip = e.skip;
    this.pageSizes = e.take;
    this.pageSize = e.take;
    const pageDta = {
      pageNumber: currentPage,
      pageSize: this.pageSize
    };
    if(this.total> this.pageSize)  this.totalPageSize.emit(pageDta);    
  }

  public paginationAlignment(): void {
    setTimeout(() => {
      const seekW = document.getElementsByClassName('k-i-arrow-w');
      const seekWLength = seekW.length;
      for (let i = 0; i < seekWLength; i++) {
        seekW[0].innerHTML = 'Previous';
        seekW[0].className = 'k-previous';
      }
      const seekE = document.getElementsByClassName('k-i-arrow-e');
      const seekElength = seekE.length;
      for (let i = 0; i < seekElength; i++) {
        seekE[0].innerHTML = 'Next';
        seekE[0].className = 'k-next';
      }
      const exportIcons = document.querySelectorAll('.custom-icons');
      // tslint:disable-next-line: prefer-for-of
      for (let i = 0; i < exportIcons.length; i++) {
        if (exportIcons.length === 2) {
          exportIcons[i].setAttribute('style', 'display:none');
        } else if (exportIcons.length > 2) {
          exportIcons[2].setAttribute('style', 'display:none');
          exportIcons[3].setAttribute('style', 'display:none');
        }
      }
    }, 0);
  }

  public getDCCScreen(dcc: any): void {
    const url = dcc.target.value;
    window.open(url, '_blank');
  }

  public filterData(): any {
    let filterData = {
      dcc_filter: this.dccValue,
      standard_filter: this.standardValue,
      facility_filter: this.facilityValue,
      trade_name_filter: this.tradeValue,
      supplier_filter: this.supplierValue,
      formulator_filter: this.formulatorValue,
      co_filter: this.coNumberValue,
      co_name_filter: this.coNameValue,
      facility_location_filter: this.facilityLocationValue,
      dcc_status_filter: this.dccStatusValue,
      product_status_filter: this.productStatusValue,
    }
    this.skip=0;
    
    this.dataBinding.skip = 0;
    this.filterGridData.emit(filterData)
  }
  
  showTotalContent(col: number, row: any): any {
    const paraID = 'totalCount' + col + row;
    const initialTxt = 'initialTxt' + col + row;
    console.log(paraID);
    const element = document.getElementById(paraID);
    const intiElement = document.getElementById(initialTxt);
    intiElement?.removeAttribute('style');
    intiElement?.setAttribute('style', 'display:none');
    element?.removeAttribute('style');
  }
  showInitialTxt(col: number, row: any): void {
    const paraID = 'totalCount' + col + row;
    const initialTxt = 'initialTxt' + col + row;
    const element = document.getElementById(paraID);
    const intiElement = document.getElementById(initialTxt);
    element?.setAttribute('style', 'display:none');
    intiElement?.setAttribute('style', 'display:block');
  }
}
