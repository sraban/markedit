import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { GridModule, ExcelModule, PDFModule } from '@progress/kendo-angular-grid';
import { ExcelExportModule } from '@progress/kendo-angular-excel-export';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { IconsModule } from '@progress/kendo-angular-icons';
import { LayoutModule } from '@progress/kendo-angular-layout';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { InputsModule } from '@progress/kendo-angular-inputs';
import { LabelModule } from '@progress/kendo-angular-label';
import { DropDownsModule } from '@progress/kendo-angular-dropdowns';
import { MultiSelectComponent } from './dynamic-fields/fields/multi-select/multi-select.component';
import { TranslateModule } from '@ngx-translate/core';
import { DynamicFieldsComponent } from './dynamic-fields/dynamic-fields.component';
import { DropDownComponent } from './dynamic-fields/fields/drop-down/drop-down.component';
import { InputTextBoxComponent } from './dynamic-fields/fields/input-text-box/input-text-box.component';
import { InputVarcharComponent } from './dynamic-fields/fields/input-varchar/input-varchar.component';
import { KendoGridComponent } from './kendo-grid/kendo-grid.component';
import { CheckBoxComponent } from './dynamic-fields/fields/check-box/check-box.component';
import { DialogModule } from '@progress/kendo-angular-dialog';
import { CustomHandsontableComponent } from './custom-handsontable/custom-handsontable.component';
import { HotTableModule } from '@handsontable/angular';
import { DialogComponent } from './dialog/dialog.component';
import { CustomConfirmPopupComponent } from './custom-confirm-popup/custom-confirm-popup.component';
import { CustomNotificationComponent } from './custom-notification/custom-notification.component';
import { CustomLoaderComponent } from './custom-loader/custom-loader.component';
import { CustomLookupselectionComponent } from './custom-lookupselection/custom-lookupselection.component';
import { PagerModule } from '@progress/kendo-angular-pager';
import { TooltipModule } from '@progress/kendo-angular-tooltip';
import { ValidationComponent } from './validation/validation.component';
import { BreadcrumbComponent } from './breadcrumb/breadcrumb.component';
import { PdfPrinterDirective } from './directives/pdf-printer.directive';
import { ClickOusideDirective } from './directives/click-ouside.directive';
import { NumbersOnlyDirective } from './directives/numbers-only.directive';
import { SearchDropdownComponent } from './search-dropdown/search-dropdown.component';
import { DecimalDirective } from './directives/decimal.directive';
import { PopupModule } from '@progress/kendo-angular-popup';
import { PopupAnchorDirective } from './directives/popup-anchor.directive';
import { RouterModule } from '@angular/router';
import { CustomRemovePopupComponent } from './custom-remove-popup/custom-remove-popup.component';
import { DocumentsComponent } from './documents/documents.component';
import { NotesComponent } from './notes/notes.component';


@NgModule({
  declarations: [
    KendoGridComponent,
    DynamicFieldsComponent,
    InputTextBoxComponent,
    InputVarcharComponent,
    CheckBoxComponent,
    DropDownComponent,
    MultiSelectComponent,
    CustomHandsontableComponent,
    DialogComponent,
    CustomConfirmPopupComponent,
    CustomNotificationComponent,
    CustomLoaderComponent,
    CustomLookupselectionComponent,
    ValidationComponent,
    PdfPrinterDirective,
    ClickOusideDirective,
    BreadcrumbComponent,
    NumbersOnlyDirective,
    SearchDropdownComponent,
    DecimalDirective,
    PopupAnchorDirective,
    CustomRemovePopupComponent,
    DocumentsComponent,
    NotesComponent,
  ],
  imports: [
    CommonModule,
    GridModule,
    IconsModule,
    ExcelExportModule,
    LayoutModule,
    FormsModule,
    IconsModule,
    InputsModule,
    ButtonsModule,
    FormsModule,
    ReactiveFormsModule,
    DropDownsModule,
    ButtonsModule,
    LabelModule,
    TranslateModule,
    DialogModule,
    HotTableModule,
    ExcelModule,
    PDFModule,
    TooltipModule,
    PagerModule,
    PopupModule,
    RouterModule
  ],
  exports: [
    GridModule,
    IconsModule,
    ExcelExportModule,
    LayoutModule,
    FormsModule,
    IconsModule,
    InputsModule,
    ButtonsModule,
    FormsModule,
    ReactiveFormsModule,
    DropDownsModule,
    ButtonsModule,
    LabelModule,
    TooltipModule,
    TranslateModule,
    PagerModule,
    KendoGridComponent,
    DynamicFieldsComponent,
    CustomHandsontableComponent,
    DialogComponent,
    DialogModule,
    CustomConfirmPopupComponent,
    CustomNotificationComponent,
    CustomLoaderComponent,
    CustomLookupselectionComponent,
    ValidationComponent,
    BreadcrumbComponent,
    NumbersOnlyDirective,
    ClickOusideDirective,
    DecimalDirective,
    PopupAnchorDirective,
    CustomRemovePopupComponent,
    DocumentsComponent,
    NotesComponent

  ],
  providers: [ PdfPrinterDirective ],
})
export class AppSharedModule { }
