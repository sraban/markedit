import { DecimalDirective } from './decimal.directive';

describe('DecimalDirective', () => {
  it('should create an instance', () => {
    const directive = new DecimalDirective();
    expect(directive).toBeTruthy();
  });
});
