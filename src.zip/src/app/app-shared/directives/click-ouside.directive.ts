import {
  Directive,
  EventEmitter,
  Input,
  Output,
  Renderer2,
} from '@angular/core';

@Directive({
  selector: '[appClickOutside]',
})
export class ClickOusideDirective {
  @Output() isMenuOpen = new EventEmitter<any>();
  @Input('appClickOutside') toggleButton: any;
  @Input('menu1') burgerMenu: any;
  @Input() count: any;
  public listItems: any[] = [];

  constructor(private renderer: Renderer2) {
    this.renderer.listen('window', 'click', (e: Event) => {
      if (this.count === 1){
        if (
          e.target !== this.burgerMenu.nativeElement.children[0].children[0] && e.target !== this.burgerMenu.nativeElement) {
          this.isMenuOpen.emit('none');
        }
        
      }else if(this.count === 2) {
        if (e.target !== this.toggleButton && e.target !== this.burgerMenu.nativeElement.children[0].children[0]
          && e.target !== this.burgerMenu.nativeElement) {
          this.isMenuOpen.emit('changeCount');
        }
      }else {
        if (e.target !== this.toggleButton && e.target !== this.burgerMenu.nativeElement.children[0].children[0]
          && e.target !== this.burgerMenu.nativeElement) {
          this.isMenuOpen.emit('none');
        }
      }
     
    });
  }
  hamburger(e : any): void{
    this.listItems.forEach(item => {
      return e !== item;
    })
  }
}
