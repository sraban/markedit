import { Directive, ElementRef, HostListener } from '@angular/core';

@Directive({
  selector: 'input[appDecimal]'
})
export class DecimalDirective {

   private regex: RegExp = new RegExp(/^\d*\.?\d{0,2}$/g);
   private specialKeys: Array<string> = ['Backspace', 'Tab', 'End', 'Home', '-', 'ArrowLeft', 'ArrowRight', 'Del', 'Delete'];

   constructor(private el: ElementRef) {
   }
   @HostListener('keydown', ['$event'])
   onKeyDown(event: KeyboardEvent): any {
     if (this.specialKeys.indexOf(event.key) !== -1 || (event.key === 'c' && event.ctrlKey === true) ||  (event.key === 'v' && event.ctrlKey === true)) {
       return;
     }
     const current: string = this.el.nativeElement.value;
     const position = this.el.nativeElement.selectionStart;
     const next: string = [current.slice(0, position), event.key === 'Decimal' ? '.' : event.key, current.slice(position)].join('');
     if (next && !String(next).match(this.regex)) {
       event.preventDefault();
     }
   }
   @HostListener('input', ['$event']) onInputChange(event: any): any {
     const initalValue = this.el.nativeElement.value;
     this.el.nativeElement.value = initalValue.replace(/[^0.00-9.00]*/g, '');
     if (initalValue !== this.el.nativeElement.value) {
       event.stopPropagation();
     }
   }

}
