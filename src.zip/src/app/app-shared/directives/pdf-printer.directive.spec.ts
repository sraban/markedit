import { PdfPrinterDirective } from './pdf-printer.directive';

describe('PdfPrinterDirective', () => {
  it('should create an instance', () => {
    const directive = new PdfPrinterDirective();
    expect(directive).toBeTruthy();
  });
});
