import { Directive, ElementRef } from '@angular/core';

@Directive({
  exportAs: 'printer',
  selector: '[appPdfPrinter]'
})
export class PdfPrinterDirective {
constructor(private el: ElementRef) { }
public print(searchData: any, title: string, columnHeaders: any): any {
    let myPrintContent = '';
    let template = '';
    let header = '';
    columnHeaders.forEach((row: any) => {
       header += `<th style='text-align: left'>${row.header_title}</th>`;
    });
    myPrintContent += `<thead><tr>${header}</tr></thead>`;
    searchData.forEach((row: any) => {
      columnHeaders.forEach((item: any) => {
        template += `<td style="word-wrap: break-word; max-width:500px">${row[item.field] ? row[item.field] : ''}</td>`;
      });
      myPrintContent += `<tr>${template}</tr>`;
      template = ``;
    });
    const myPrintWindow: any = window.open('', 'Print Grid', 'left=300,top=100,width=auto,height=100%');
    const  content = `
    <title>${title}</title>
    <table width="100%" cellpadding="5" rules="all" border="1">${myPrintContent}</table><br>
    `;
    myPrintWindow.document.write(content);
    const cssRef = document.createElement('link');
    cssRef.onload = () => {
      myPrintWindow.focus();
      myPrintWindow.print();
      myPrintWindow.close();
    };
    console.log(myPrintWindow.document);
    cssRef.rel = 'stylesheet';
    cssRef.href = 'https://cdn.jsdelivr.net/npm/@progress/kendo-theme-default@latest/dist/all.css';
    myPrintWindow.document.head.appendChild(cssRef);
    myPrintWindow.document.close();

    return false;
  }

}

