import { ClickOusideDirective } from './click-ouside.directive';

describe('ClickOusideDirective', () => {
  it('should create an instance', () => {
    const directive = new ClickOusideDirective();
    expect(directive).toBeTruthy();
  });
});
