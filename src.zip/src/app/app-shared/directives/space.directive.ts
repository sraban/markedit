import { AbstractControl, ValidationErrors } from '@angular/forms';
  
export class spaceValidator {
    static cannotContainSpace(control: AbstractControl) : ValidationErrors | null {
      if(control.value){
        if((control.value as string).indexOf(' ') >= 0){
          control.patchValue('');
            return {cannotContainSpace: true}
        }
      }
  
        return null;
    }
  }