import { AfterViewInit, Component, EventEmitter, Input, Output, Renderer2, ViewChild, ViewEncapsulation } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { GridComponent } from '@progress/kendo-angular-grid';

const hasClass = (el: any, className: any) =>
  new RegExp(className).test(el.className);

const isChildOf = (el: any, className: any) => {
  while (el && el.parentElement) {
    if (hasClass(el.parentElement, className)) {
      return true;
    }
    el = el.parentElement;
  }
  return false;
};
@Component({
  selector: 'app-custom-lookupselection',
  templateUrl: './custom-lookupselection.component.html',
  styleUrls: ['./custom-lookupselection.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class CustomLookupselectionComponent implements AfterViewInit {
  // GridComponent hanldes edit a row, add a row, cancel,save functionalities
  @ViewChild(GridComponent) private grid!: GridComponent;

  public formGroup: any;
  // tslint:disable-next-line: variable-name
  public grid_Data: any;
  // gridData - bind data to the grid
  @Input() set gridData(data: any){
     this.grid_Data = data;
     this.paginationAlignment();
  }

  // columnHeaders - array of headers needed to specify title and field in kendo-grid
  @Input() columnHeaders: any;

  // formControl - of type formGroup,needed for editing existing data and also adding a data
  @Input() formControl!: FormGroup;

  @Input() colGroupHeader: any;
  totalRows: any;
  selectedData: any[] = [];
  pagination: any;
  pageSize = 100;
  skip = 0;

  @Input() height: any;

  @Input() selectRowCheckbox!: string;

  @Input() set pageable(value: any) {
    if (value) {
      this.pagination = value.pageable;
      this.pageSize = value.pageSize;
      this.paginationAlignment();
    } else {
      this.pagination = false;
    }
  }
  public pagerPageSize = [25, 50, 75, 100];
  buttonCount!: number;
  @Output() editedData = new EventEmitter();
  private editedRowIndex: any;
  private isNew!: boolean;

  public mySelection: any[] = [];

  constructor(private renderer: Renderer2) {
    this.pageable = false;
  }

  ngAfterViewInit(): void {
    if (this.pagination) {
      this.paginationAlignment();
    }
    this.renderer.listen('window', 'keydown', (e: Event) => {
        setTimeout(() => {
          const ele = document.querySelectorAll('input.k-textbox');
          ele.forEach(item => {
            if (e.target === item) {
              console.log(e.target, item);
              const pagerInfo = document.getElementsByClassName('k-grid-pager');
              const info = document.querySelectorAll('.k-pager-info');
              const nodatainfo = document.querySelectorAll('.nodataavail');
              this.totalRows = pagerInfo[0].attributes.getNamedItem('ng-reflect-total')?.value;
              if (!+this.totalRows) {
                info.forEach((pagerInfo: any) => {
                  pagerInfo.setAttribute('style', 'display:none');
                });
                nodatainfo.forEach(infoNoData => {
                  infoNoData.removeAttribute('style');
                });
              } else {
                info.forEach(pagerInfo => {
                  pagerInfo.removeAttribute('style');
                });
                nodatainfo.forEach(infoNoData => {
                  infoNoData.setAttribute('style', 'display:none');
                });
              }
            }
          });
        }, 550);
      });

  }

  public saveRow(): void {
    if (this.mySelection.length > 1) {
      this.mySelection.forEach((item: any) => {
        this.grid_Data.forEach((data: any) => {
          if (data[this.selectRowCheckbox] === item) {
            this.selectedData.push(data);
          }
        });
      });
      this.editedData.emit(this.selectedData);
    }
    this.mySelection = [];
  }

  public cellClickHandler({
    isEdited,
    dataItem,
    rowIndex,
  }: {
    isEdited: boolean;
    dataItem: any;
    rowIndex: number;
  }): void {
    if (isEdited || (this.formGroup && !this.formGroup.valid)) {
      return;
    }

    if (this.isNew) {
      rowIndex += 1;
    }
    this.editedData.emit(dataItem);
  }
  public paginationAlignment(): void {
    setTimeout(() => {
      const seekW = document.getElementsByClassName('k-i-arrow-w');
      const seekWLength = seekW.length;
      for (let i = 0; i < seekWLength; i++) {
        seekW[0].innerHTML = 'Previous';
        seekW[0].className = 'k-previous';
      }
      const seekE = document.getElementsByClassName('k-i-arrow-e');
      const seekElength = seekE.length;
      for (let i = 0; i < seekElength; i++) {
        seekE[0].innerHTML = 'Next';
        seekE[0].className = 'k-next';
      }
    }, 0);
  }

}
