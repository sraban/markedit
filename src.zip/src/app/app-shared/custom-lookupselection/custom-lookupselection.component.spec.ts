import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomLookupselectionComponent } from './custom-lookupselection.component';

describe('CustomLookupselectionComponent', () => {
  let component: CustomLookupselectionComponent;
  let fixture: ComponentFixture<CustomLookupselectionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomLookupselectionComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomLookupselectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
