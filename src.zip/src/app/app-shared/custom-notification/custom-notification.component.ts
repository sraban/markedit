import { Component, Input, OnInit, ViewChild, ViewContainerRef, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-custom-notification',
  templateUrl: './custom-notification.component.html',
  styleUrls: ['./custom-notification.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class CustomNotificationComponent {
  content!: string;
  style: any;
  bgStyle: any;
  fontColor: any;
  timeInterval: any;

  @Input() set show(data: any) {
    this.style = data.style;
    this.content = data.style === 'success' ? (data.content ? data.content : 'Success') :
      (data.content === 'error' ? data.content : (data.content ? data.content : 'info'));

    this.bgStyle = {
      'background-color': this.style === 'success' ? '#b5f1ba' : (this.style === 'error' ? '#F9DBE3' : '#d9f1ff'),
      'border-color': this.style === 'success' ? '#629b6c' : (this.style === 'error' ? '#70021E' : '#1687b2')
    };
    this.fontColor = {
      color : this.style === 'success' ? '#096808' : (this.style === 'error' ? '#70021E' : '#057199')
    };

    // this.timeInterval = setTimeout(() => {
    //   this.style = null;
    // }, 10000);
  }

  clearNotification(): void {
    this.style = null;
    // clearInterval(this.timeInterval);
  }

}

















//   if (data.content && data.style){
    //   this.notificationService.show({
      //     animation: { type: 'fade', duration: 200 },
    //     position: { horizontal: 'center', vertical: 'top' },
    //     type: { style: data.style, icon: true },
    //     closable: true,
    //     hideAfter: 4000
    //   });
    // }
