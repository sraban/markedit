import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-custom-remove-popup',
  templateUrl: './custom-remove-popup.component.html',
  styleUrls: ['./custom-remove-popup.component.scss']
})
export class CustomRemovePopupComponent{

  @Input() opened!: boolean;
  @Output() onclose = new EventEmitter();
  @Input() showTitle: any;


  dialogClose(): void {
    this.opened = false;
    this.onclose.emit('Close');
  }

  onAccept(): void {
    this.onclose.emit('Yes');
    this.opened = false;
  }

  onDecline(): void {
    this.onclose.emit('No');
    this.opened = false;
  }
}
