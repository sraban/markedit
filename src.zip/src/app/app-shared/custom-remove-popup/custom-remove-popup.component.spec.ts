import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomRemovePopupComponent } from './custom-remove-popup.component';

describe('CustomRemovePopupComponent', () => {
  let component: CustomRemovePopupComponent;
  let fixture: ComponentFixture<CustomRemovePopupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomRemovePopupComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomRemovePopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
