import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomConfirmPopupComponent } from './custom-confirm-popup.component';

describe('CustomConfirmPopupComponent', () => {
  let component: CustomConfirmPopupComponent;
  let fixture: ComponentFixture<CustomConfirmPopupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomConfirmPopupComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomConfirmPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
