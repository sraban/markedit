import { Component, EventEmitter, Input, OnInit, Output, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-custom-confirm-popup',
  templateUrl: './custom-confirm-popup.component.html',
  styleUrls: ['./custom-confirm-popup.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class CustomConfirmPopupComponent implements OnInit {

  @Input() opened!: boolean;
  @Output() onclose = new EventEmitter();
  @Input() showTitle: any;

  constructor() {}

  ngOnInit(): void {}

  dialogClose(): void {
    this.opened = false;
    this.onclose.emit('Close');
  }

  onAccept(): void {
    this.onclose.emit('Yes');
    this.opened = false;
  }

  onDecline(): void {
    this.onclose.emit('No');
    this.opened = false;
  }
}
