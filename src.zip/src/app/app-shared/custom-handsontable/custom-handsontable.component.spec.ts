import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomHandsontableComponent } from './custom-handsontable.component';

describe('CustomHandsontableComponent', () => {
  let component: CustomHandsontableComponent;
  let fixture: ComponentFixture<CustomHandsontableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomHandsontableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomHandsontableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
