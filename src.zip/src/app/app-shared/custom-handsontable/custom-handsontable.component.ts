import { Component, EventEmitter, Input, Output, ViewEncapsulation } from '@angular/core';
import { HotTableRegisterer } from '@handsontable/angular';
import Handsontable from 'handsontable';

@Component({
  selector: 'app-custom-handsontable',
  templateUrl: './custom-handsontable.component.html',
  styleUrls: ['./custom-handsontable.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class CustomHandsontableComponent {

  @Output() instance = new EventEmitter();
  @Output() cellValue = new EventEmitter();

  @Input() dataSet: any = [];
  @Input() set columnHeader(data: any) {
    this.colHeaders = data;

  }
  @Input() columns: any;
  manageColBtn!: boolean;
  index: any;
  deleteBtnIndex!: number;
  specificCol!: number[];
  @Input() set commandIndex(data: {
    checkbox?: number, options?: number,
    manageCol?: boolean, height?: number | string, width?: number | string, deleteBtnIndex?: number
    specificCol?: number[]
  }) {
    this.index = data;
    if (typeof data === 'object') {
      const inst = this.ht.getInstance(this.id);
      data.manageCol ? this.manageColBtn = data.manageCol : this.manageColBtn = false;
      data.deleteBtnIndex ? this.deleteBtnIndex = data.deleteBtnIndex : 0;
      data.specificCol ? this.specificCol = data.specificCol : 0;
      const header = [...this.colHeaders];
      this.disabledCol = [...this.colHeaders];
      if (typeof data.checkbox === 'number') {
        header.splice(data.checkbox, 1);
        this.disabledCol.splice(data.checkbox, 1, '');
      }
      if (data.checkbox && data.options && typeof data.options === 'number' && data.checkbox > data.options) {
        header.splice(data.options, 1);
        this.disabledCol.splice(data.options, 1, '');
      } else if (data.checkbox && data.options) {
        header.splice(data.options - 1, 1);
        this.disabledCol.splice(data.options, 1, '');
      }
      this.manageColHeader = header;
      if (data.height || data.width) {
        inst.updateSettings({
          height: data.height ? data.height : 'auto',
          width: data.width ? data.width : 'auto'
        });
      }

      this.manageCol();

      // }
    }
  }
  @Input() id: any;
  @Input() aftcellClick: any;
  @Input() set lookUpValue(data: any) {
    this.setDataAtCell(data);
  }

  @Input() readonly!: boolean;
  colHeaders: any[] = [];
  coords!: { row: number, col: number };
  afterInitCallback: any;
  inst: any;
  value = '';
  manageColumnRows: number[] = [];
  ht = new HotTableRegisterer();
  rowsOnClear = 0;
  addedRowsArray: number[] = [];
  targetElement: any;
  addedRows: number[] = [];
  checkedRows: number[] = [];
  deleteAddedRows: number[] = [];
  dataalreadyavail = false;
  opened = false;
  title = 'Delete Row';
  showList = false;
  manageColHeader: any[] = [];
  hideCol: any[] = [];
  disabledCol: any;
  disabledColEle: any[] = [];

  hotSettings: Handsontable.GridSettings = {
    stretchH: 'all',
    search: false,
    manualColumnResize: true,
    copyPaste: true,
    height: 'auto',
    width: 'auto',
    multiColumnSorting: true,
    hiddenColumns: true,
    afterScrollHorizontally: () => {
      this.aftChangeDetection();
    },
    afterScrollVertically: () => {
      this.aftChangeDetection();
    },
    afterChange: (changes, source) => {
      const instance = this.ht.getInstance(this.id);
      this.aftChangeDetection();
      if (this.coords && this.specificCol && this.checkIsPresent()) {
        const cellValue = instance.getDataAtCell(this.coords.row, this.coords.col);
        this.cellValue.emit([cellValue, this.coords.row, this.coords.col, source]);
      }
    },
    afterOnCellMouseDown: (event: MouseEvent, coords: any, TD: HTMLTableCellElement) => {
      let ele: any;
      this.coords = coords;
      const eleList = TD.children;
      const instance = this.ht.getInstance(this.id);
      for (let i = 0; i < eleList.length; i++) {
        if (TD.children[i] === event.target) {
          ele = eleList[i];
          if (TD.children[i].id === 'search') {
            ele?.addEventListener('click', () => {
              this.instance.emit('opened');
              this.coords = coords;

            });
          } else if (TD.children[i].id === 'delete') {
            ele?.addEventListener('click', () => {
              instance.alter('remove_row', coords.row);
              this.addedRowsArray.forEach((item: any, index: number) => {
                if (coords.row === item) {
                  this.addedRowsArray.splice(index, 1);
                  this.rowsOnClear--;
                }
              });
            });
          } else if (TD.children[i].id === 'deletePopup') {
            ele?.addEventListener('click', () => {
              this.opened = true;
            });
          } else if (TD.children[i].id === 'edit') {
            ele?.addEventListener('click', () => {
              this.instance.emit('editOpened');
            });
          } else if (TD.children[i].id === 'editInline') {
            ele?.addEventListener('click', () => {
              this.deleteAddedRows.push(coords.row);
              this.checkedRows.forEach((row, index) => {
                this.deleteAddedRows.forEach((rowCount) => {
                  if (row === rowCount) {
                    this.enableDeleteBtn(row, coords.col);
                    this.enableButtons(row, coords.col);
                    this.checkedCheckbox(row, this.index.checkbox);
                    this.checkedRows.splice(index, 1);
                  } else {
                    this.checkedCheckbox(row, this.index.checkbox);
                    this.enableButtons(row, coords.col);
                  }
                });
              });
              this.aftChangeDetection();
              this.instance.emit('editOpened');
            });
          } else if (TD.children[i].id === 'add') {
            ele?.addEventListener('click', () => {
              this.instance.emit('addOpened');
              instance.alter('insert_row', coords.row - 1);
            });
          } else if (TD.children[i].id === 'addInline') {
            ele?.addEventListener('click', () => {
              this.deleteAddedRows.forEach((rowCount, inx) => {
                if (rowCount > coords.row || rowCount === coords.row) {
                  this.deleteAddedRows.splice(inx, 1, rowCount + 1);
                }
              });
              this.deleteAddedRows.push(coords.row);
              instance.alter('insert_row', coords.row);
              this.checkedRows.forEach((item, index) => {
                if (coords.row < item) {
                  this.checkedRows.splice(index, 1, item + 1);
                }
              });
              this.checkedRows.forEach((item, index) => {
                if (item === coords.row) {
                  this.checkedRows.splice(index, 1);
                }
              });

              this.aftChangeDetection();
            });
          } else if (TD.children[i].id === 'checkbox') {
            ele?.addEventListener('change', (e: any) => {
              if (e.target.checked) {
                this.checkedRows.push(coords.row);
                this.aftChangeDetection();
              } else {
                this.removeCellProperty(coords.row);
                this.checkedRows.forEach((item, intx) => {
                  if (item === coords.row) {
                    this.checkedRows.splice(intx, 1);
                  }
                });
                this.deleteAddedRows.forEach((item, index) => {
                  if (item === coords.row) {
                    this.deleteAddedRows.splice(index, 1);
                  }
                });
                this.hideDeleteBtn(coords.row, this.index.options);
                this.disableButtons(coords.row, this.index.options);
                this.aftChangeDetection();
              }
            });
          } else if (TD.children[i].id === 'copyInline') {
            ele.addEventListener('click', () => {
              const copiedValue = instance.getDataAtRow(coords.row);
              this.deleteAddedRows.forEach((rowCount, inx) => {
                if (rowCount > coords.row || rowCount === coords.row) {
                  this.deleteAddedRows.splice(inx, 1, rowCount + 1);
                }
              });
              this.deleteAddedRows.push(coords.row);
              instance.alter('insert_row', coords.row);
              this.checkedRows.forEach((item, index) => {
                if (coords.row < item) {
                  this.checkedRows.splice(index, 1, item + 1);
                } else if (coords.row === item) {
                  this.checkedRows.splice(index, 1);
                }
              });
              const metaDataofRow = instance.getCellMetaAtRow(coords.row);
              for (let num = 0; num < metaDataofRow.length; num++) {
                copiedValue.forEach((item: any, indexNo: number) => {
                  if (indexNo === num) {
                    instance.setDataAtCell(coords.row, indexNo, item);
                  }
                });
              }
              this.aftChangeDetection();
            });
          }
        }
      }
      // if (TD.children[0].children[0] && TD.children[0].children[0].children[0].id === 'selectAllCheckbox'
      //   && event.target === TD.children[0].children[0].children[0]) {
      //   console.log(TD.children[0].children[0].children[0].id, event.target);
      //   const element = TD.children[0].children[0].children[0];
      //   element?.addEventListener('change', (e: any) => {
      //     if (e.target.checked) {
      //       const rowLength = instance.countRows();
      //       const rows = Array.from(Array(rowLength).keys());
      //       console.log(rows);
      //       this.checkedRows = rows;
      //       this.aftChangeDetection();
      //     } else {
      //       this.checkedRows.forEach(row => {
      //         this.removeCellProperty(row);
      //         this.hideDeleteBtn(row, this.index.options);
      //         this.disableButtons(row, this.index.options);
      //         const cellElement = instance.getCell(row, this.index.checkbox);
      //         cellElement?.children[0].removeAttribute('checked');
      //       });
      //       this.checkedRows = [];
      //       this.deleteAddedRows = [];
      //       this.aftChangeDetection();
      //     }
      //   });
      // }
    }

  };
  removeRows = false;

  constructor() {
    this.afterInitCallback = this.afterInit.bind(this);
  }

  public enableButtons(row: number, col: number): void {
    const instance = this.ht.getInstance(this.id);
    const btnEnable = instance.getCell(row, col, true);
    const btnCount = btnEnable?.children.length;
    if (btnCount) {
      for (let i = 0; i < btnCount; i++) {
        btnEnable?.children[i].removeAttribute('disabled');
      }
    }
  }

  public disableButtons(row: number, col: number): void {
    const instance = this.ht.getInstance(this.id);
    const btnDisable = instance.getCell(row, col, true);
    const btnCount = btnDisable?.children.length;
    if (btnCount) {
      for (let i = 0; i < btnCount; i++) {
        btnDisable?.children[i].setAttribute('disabled', 'true');
      }
    }
  }

  public checkedCheckbox(row: number, col: number): void {
    const instance = this.ht.getInstance(this.id);
    const checkbox = instance.getCell(row, col, true);
    checkbox?.children[0].setAttribute('checked', 'true');
  }

  public enableDeleteBtn(row: number, col: number): void {
    const instance = this.ht.getInstance(this.id);
    const ren = instance.getCell(row, col, true);
    ren?.children[this.deleteBtnIndex].removeAttribute('style');
  }

  public hideDeleteBtn(row: number, col: number): void {
    const instance = this.ht.getInstance(this.id);
    const ren = instance.getCell(row, col, true);
    ren?.children[this.deleteBtnIndex].setAttribute('style', 'display: none');
  }

  public confirmPopup(data: any): void {
    console.log(data);
    if (data === 'Yes') {
      const instance = this.ht.getInstance(this.id);
      instance.alter('remove_row', this.coords.row);
      this.checkedRows.forEach((item, index) => {
        if (this.coords.row === item) {
          this.checkedRows.splice(index, 1);
        } else if (this.coords.row < item) {
          this.checkedRows.splice(index, 1, item - 1);
        }
      });
      this.deleteAddedRows.forEach((eRow, arrI) => {
        if (this.coords.row === eRow) {
          this.deleteAddedRows.splice(arrI, 1);
        } else if (eRow > this.coords.row) {
          this.deleteAddedRows.splice(arrI, 1, eRow - 1);
        }
      });

      // this.checkedRows.forEach((item, index) => {
      //   this.enableDeleteBtn(item, this.coords.col);
      //   this.checkedCheckbox(item, this.index.checkbox);
      // });

      // this.deleteAddedRows.forEach((item) => {
      //   this.enableDeleteBtn(item, this.coords.col);
      //   this.checkedCheckbox(item, this.index.checkbox);
      //   this.enableButtons(item, this.coords.col);
      // });
      this.aftChangeDetection();
    }
    this.opened = false;
  }

  public settingCellProperty(row: number): void {
    const instance = this.ht.getInstance(this.id);
    const metaDataofRow = instance.getCellMetaAtRow(row);
    for (let num = 0; num < metaDataofRow.length; num++) {
      const cell = instance.getCell(row, num, true);
      cell?.setAttribute('class', 'newStyleFortd');
      if (cell?.children && num !== this.index.checkbox &&
        num !== this.index.options) {
        metaDataofRow[num].readOnly = false;
        cell.children.length ? cell.children[0].className = 'para' : cell.className = 'para';
        // cell.children[0].className = 'para';
      }
    }
  }

  public removeCellProperty(row: number): void {
    const instance = this.ht.getInstance(this.id);
    const metaDataofRow = instance.getCellMetaAtRow(row);
    for (let num = 0; num < metaDataofRow.length; num++) {
      const cell = instance.getCell(row, num, true);
      cell?.removeAttribute('class');
      if (cell?.children.length && num !== this.index.checkbox &&
        num !== this.index.options) {
        metaDataofRow[num].readOnly = true;
        cell.children[0].removeAttribute('class');
      }
    }
  }

  public aftChangeDetection(): void {
    this.checkedRows.forEach((row) => {
      this.checkedCheckbox(row, this.index.checkbox);
      this.enableButtons(row, this.index.options);
    });
    this.deleteAddedRows.forEach((row) => {
      this.checkedCheckbox(row, this.index.checkbox);
      this.enableButtons(row, this.index.options);
      this.enableDeleteBtn(row, this.index.options);
      this.settingCellProperty(row);
    });
  }


  public getData(): void {
    const instance = this.ht.getInstance(this.id);
    const rows = instance.getData();
    const data = instance.getSourceData(rows.length - 1, this.columns.length);
  }

  afterInit(): void {
    if (this.ht.getInstance(this.id)) {
      const inst = this.ht.getInstance(this.id);
      this.instance.emit(inst);
    }
  }

  addRow(): void {
    const instance = this.ht.getInstance(this.id);
    const totalrows = instance.countRows();
    this.addedRowsArray.push(totalrows);
    this.rowsOnClear++;
    const previousValue = instance.getDataAtCell(totalrows - 1, 3);
    this.colHeaders.forEach((item: any, i: number) => {
      if (i === 3) {
        instance.setDataAtCell(totalrows, i, previousValue + 10);
      } else {
        instance.setDataAtCell(totalrows, i, null);
      }
    });
  }


  cancelAdd(): void {
    const instance = this.ht.getInstance(this.id);
    let totalrows = instance.countRows();
    if (this.addedRowsArray) {
      for (let i = 0; i < this.rowsOnClear; i++) {
        instance.alter('remove_row', (totalrows - 1));
        totalrows--;
      }
    }
    this.rowsOnClear = 0;
  }

  setDataAtCell(data: any): void {
    if (data) {
      const instance = this.ht.getInstance(this.id);
      instance.setDataAtCell(this.coords.row, this.coords.col, `${data} `);
    }
  }

  manageColumn(event: any): void {
    const hideCol = this.colHeaders.indexOf(event.target.value);
    const instance = this.ht.getInstance(this.id);
    if (event.target.checked) {
      this.hideCol.forEach((colNumber, index) => {
        if (colNumber === hideCol) {
          this.hideCol.splice(index, 1);
        }
      });
      if (this.disabledColEle.length) {
        const col = document.getElementsByClassName(this.disabledColEle[0]);
        col[0].removeAttribute('disabled');
        this.disabledColEle = [];
      }
      instance.updateSettings({
        width: 'auto',
        hiddenColumns: {
          columns: this.hideCol,
        }
      });
      this.aftChangeDetection();
    } else {
      this.hideCol.push(hideCol);
      instance.updateSettings({
        width: 'auto',
        hiddenColumns: {
          columns: this.hideCol,
        }
      });
      if (this.manageColHeader.length - 1 === this.hideCol.length) {
        this.disabledColEle = [...this.disabledCol];
        this.hideCol.forEach(item => {
          this.disabledColEle.splice(item, 1, '');
        });
        this.disabledColEle = this.disabledColEle.filter(Boolean);
        const col = document.getElementsByClassName(this.disabledColEle[0]);
        col[0].setAttribute('disabled', '');
      }
      this.aftChangeDetection();
    }
  }

  public insertSortingArrows(): void {
    const sortingArrows = document.getElementsByClassName('k-i-arrow-chevron-down');
    if (!sortingArrows.length) {
      setTimeout(() => {
        const ele = document.getElementsByClassName('relative');
        // tslint:disable-next-line: prefer-for-of
        for (let i = 0; i < ele.length; i++) {
          const arrowUp = document.createElement('span');
          arrowUp.setAttribute('class', 'k-icon k-i-arrow-chevron-up  sortAction ascending');
          const arrowdown = document.createElement('span');
          arrowdown.setAttribute('class', 'k-icon k-i-arrow-chevron-down  sortAction descending');
          ele[i].appendChild(arrowUp);
          ele[i].appendChild(arrowdown);
        }
      }, 0);
    }
  }

  manageCol(): void {
    this.insertSortingArrows();
    const headersLength = this.manageColHeader.length;
    const count = headersLength / 3;
    for (let i = 0; i < count; i++) {
      this.manageColumnRows.push(i + 1);
    }
  }
  checkIsPresent(): any {
    for (const col of this.specificCol) {
      if (col === this.coords.col) {
        return true;
      } else {
      }
    }
  }
}

