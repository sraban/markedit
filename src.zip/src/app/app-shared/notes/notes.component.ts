import { Component, OnInit, EventEmitter, Input, Output, ViewChild } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { GridComponent } from '@progress/kendo-angular-grid';

@Component({
  selector: 'app-notes',
  templateUrl: './notes.component.html',
  styleUrls: ['./notes.component.scss']
})
export class NotesComponent implements OnInit {
  public formGroup: any;
  @Input() control!: FormGroup;
  @Input() gridHeaders: any;
  @Input() gridData: any;
  @Output() removeData = new EventEmitter();
  @Output() addEditData = new EventEmitter();
  @ViewChild(GridComponent) private grid !: GridComponent;
  allowToEdit!: string;
  allowToAdd!: string;
  allowToDelete!: string;
  isNew!: boolean;
  editedRowIndex: any;
  @Input() set gridOptions(data: { allowToEdit: string, allowToAdd: string, allowToDelete: string }) {
    this.allowToEdit = data.allowToEdit;
    this.allowToAdd = data.allowToAdd;
    this.allowToDelete = data.allowToDelete;
  }
  editorTitle!: string;
  editorWidth!: number;
  editorType!: string;
  editorWithPopup!: boolean;
  filterable!: boolean;
  @Input() set editorCol(data: { title: string, width: number, type: string, openPopUp: boolean, filterable: boolean }) {
    this.editorTitle = data.title;
    this.editorWidth = data.width;
    this.editorType = data.type;
    this.editorWithPopup = data.openPopUp;
    this.filterable = data.filterable;
  }
  constructor() { }

  ngOnInit(): void {
  }
  addHandler(): void {
    this.isNew = true;
    this.closeEditor();
    this.formGroup = this.control;
    this.formGroup.reset();
    this.grid.addRow(this.formGroup);
  }

  editHandler({ sender, rowIndex, dataItem }: { sender: any, rowIndex: any, dataItem: any }): void {
    this.isNew = false;
    this.formGroup = this.control;
    this.formGroup.patchValue(dataItem);
    this.editedRowIndex = rowIndex;
    this.grid.editRow(rowIndex, this.formGroup);
    this.editedRowIndex = rowIndex;
    sender.editRow(rowIndex, this.formGroup);
  }

  removeHandler({ rowIndex, dataItem }: { rowIndex: any, dataItem: any }): void {
    this.removeData.emit({rowIndex, dataItem});
  }

  closeEditor(): void {
    this.grid.closeRow(this.editedRowIndex);
    this.isNew = false;
    this.editedRowIndex = undefined;
  }

  // cancel editing or adding data
  public cancelHandler({ sender, rowIndex, dataItem }: { sender: any, rowIndex: number, dataItem: any }): void {
    this.closeEditor();
  }

  public saveHandler({ sender, rowIndex, isNew }: { sender: any, rowIndex: number, isNew: boolean }): void {
    console.log(this.gridData);
    console.log(this.formGroup.value);
    this.addEditData.emit({isAdd: this.isNew, notesData: this.formGroup.value});
    sender.closeRow(rowIndex);
  }
}
