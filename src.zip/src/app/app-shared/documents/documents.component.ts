import { Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { GridComponent } from '@progress/kendo-angular-grid';

@Component({
  selector: 'app-documents',
  templateUrl: './documents.component.html',
  styleUrls: ['./documents.component.scss']
})
export class DocumentsComponent implements OnInit {
  @Input() gridHeaders: any;
  @Input() gridData: any;
  @Input() control: any;
  @Output() removeData = new EventEmitter();
  @Output() editData = new EventEmitter();
  @Output() addData = new EventEmitter();
  public formGroup: any;
  @ViewChild(GridComponent) private grid !: GridComponent;
  allowToEdit!: string;
  allowToAdd!: string;
  allowToDelete!: string;
  isNew!: boolean;
  editedRowIndex: any;
  @Input() set gridOptions(data: { allowToEdit: string, allowToAdd: string, allowToDelete: string }) {
    this.allowToEdit = data.allowToEdit;
    this.allowToAdd = data.allowToAdd;
    this.allowToDelete = data.allowToDelete;
  }
  editorTitle!: string;
  editorWidth!: number;
  editorType!: string;
  editorWithPopup!: boolean;
  filterable!: boolean;
  @Input() set editorCol(data: { title: string, width: number, type: string, openPopUp: boolean, filterable: boolean }) {
    this.editorTitle = data.title;
    this.editorWidth = data.width;
    this.editorType = data.type;
    this.editorWithPopup = data.openPopUp;
    this.filterable = data.filterable;
  }
  constructor() { }

  ngOnInit(): void {
  }

  addHandler(): void {
    this.isNew = true;
    this.closeEditor();
    this.addData.emit();
  }

  editHandler({ sender, rowIndex, dataItem }: { sender: any, rowIndex: any, dataItem: any }): void {
    this.isNew = false;
    this.closeEditor();
    
    this.editData.emit({ dataItem, rowIndex });
  }

  removeHandler(event: any): void {
    this.removeData.emit(event);
  }

  closeEditor(): void {
    this.grid.closeRow(this.editedRowIndex);
    this.isNew = false;
    this.editedRowIndex = undefined;
    this.formGroup = undefined;
  }
}
