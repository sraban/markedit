import { Component, Input, OnInit } from '@angular/core';
import { FormGroup,FormControl } from '@angular/forms';

@Component({
  selector: 'app-validation',
  templateUrl: './validation.component.html',
  styleUrls: ['./validation.component.scss']
})
export class ValidationComponent implements OnInit {
  @Input()
  public form!: FormGroup;
  public errors: string[] = [];
  @Input() formNames: any;

  constructor() { }

  ngOnInit(): void {
    this.generateErrorMessages();

    this.form.statusChanges.subscribe(() => {
      this.resetErrorMessages();
      this.generateErrorMessages();
    });
  }
  public resetErrorMessages(): void {
    this.errors.length = 0;
  }
  public generateErrorMessages(): void {
    const controlNames = Object.keys(this.form.controls);
    controlNames.forEach((controlName) => {
      const control = this.form.controls[controlName];
      const errors = control.errors;
      if (errors === null || errors.length === 0) {
        return;
      }

      if (errors.required || errors.whitespace) {
        this.errors.push(`Please enter ${this.formNames[controlName]}`);
      }

      if (errors.minlength) {
        this.errors.push(
          `${controlName} minimum length is ${errors.minlength.requiredLength}.`
        );
      }

      if (errors.email) {
        this.errors.push(`${controlName} is not a valid email`);
      }
    });
  }

  public noWhitespaceValidator(control: FormControl) {
    const isWhitespace = (control.value || '').trim().length === 0;
    const isValid = !isWhitespace;
    return isValid ? null : { 'whitespace': true };
  }
  clearVal(i: any){
    console.log(i)
   document.getElementById(i)?.remove()
  }
}
