import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  { path: '', loadChildren: () => import('./modules/psp-home/psp-home.module').then(m => m.PspHomeModule) },
  { path: 'prodtrack', loadChildren: () => import('./modules/prodtrack-home/prodtrack-home.module').then(m => m.ProdtrackHomeModule) },
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
