import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor
} from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable()
export class BaseInterceptorInterceptor implements HttpInterceptor {

  constructor() { }

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    // const userToken = 'secure-user-token';
    const modifiedReq = request.clone({
      // headers: req.headers.set('Authorization', `Bearer ${userToken}`),
      headers: request.headers.set('UserName', 'KLYONS'),
    });
    return next.handle(modifiedReq);
  }
}
