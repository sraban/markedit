import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ComponentFactoryResolver, Injectable, ɵCodegenComponentFactoryResolver } from '@angular/core';

import { Observable, Subject } from 'rxjs';
import { environment } from 'src/environments/environment';
// import * as testDecision from '../../assets/test-decision.json'

@Injectable({
  providedIn: 'root'
})
export class DataService {

  public testDecision = '../../assets/test-decisions.json';
  public test2ForForms = '../../assets/test2-forms.json';
  public testHandsontable = '../../assets/Tradename Response.json';
  public tableData:any=[];
  public counter:any=this.tableData.length
  public tableDataSubject = new Subject();

  constructor(private http: HttpClient) { }
  // sample for common grid
  getTestDecision(): any {
  return this.http.get(this.testDecision);
  }

getTestFormFields(): any {
  return this.http.get(this.test2ForForms);
  }

  getHandsontableData(): any{
    return this.http.get(this.testHandsontable);
  }

// tslint:disable-next-line:typedef
// getProgramsDropdown(reqObj: any) {
//   return this.http.post(`${environment.mydevUrl}${ServiceUrl.programsDropdown}`, reqObj);
// }

// getDashboard() {
//   return this.http.get(`${environment.baseUrl}${ServiceUrl.programsDropdown}`);
// }

// search button API
public getFilteredData(params: any): any{
  return this.http.post(`${environment.baseUrl}` + 'dcc/searchTool/get', params);
}

//generate dcc service
public totaltableData(){
  return this.tableDataSubject.asObservable()
}

public save(data:any,isNew:any){
  if(isNew){
    data.cellID=this.tableData.length
    this.tableData.push(data)
    this.tableDataSubject.next(this.tableData)
    
  }
  else{
    this.tableData.map((val:any)=>{
    })
    Object.assign(
      this.tableData.find(({cellID}:{cellID:any})=>
        cellID===data.cellID),data
        
      
    )
    this.tableDataSubject.next(this.tableData)
  }
}
public remove(val: any): void {
  const index = this.tableData.findIndex(
    ({ cellID }:{cellID:any}) => cellID === val.cellID
  );
  this.tableData.splice(index, 1);
  let setIndexes=this.tableData.map((data:any,index:any)=>{
    let val={
      textCode:data.textCode,
      description:data.description,
      cellID:index
    }
    return val
  })
  this.tableData=setIndexes
  this.tableDataSubject.next(this.tableData)
}

}
