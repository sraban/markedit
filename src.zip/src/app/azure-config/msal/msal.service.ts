import { Location } from '@angular/common';
import { Injectable } from '@angular/core';
import {
    AccountInfo, AuthenticationResult, AuthorizationUrlRequest, EndSessionRequest,
    IPublicClientApplication, PopupRequest, PublicClientApplication, RedirectRequest,
    SilentRequest
} from '@azure/msal-browser';
import { from, Observable } from 'rxjs';
import { ConfigService } from '../services/config.service';
import { MsalBroadcastService } from './msal.broadcast.service';


interface IMsalService {
    acquireTokenPopup(request: PopupRequest): Observable<AuthenticationResult>;
    acquireTokenRedirect(request: RedirectRequest): Observable<void>;
    acquireTokenSilent(silentRequest: SilentRequest): Observable<AuthenticationResult>;
    getAccountByUsername(userName: string): AccountInfo | null;
    getAllAccounts(): AccountInfo[];
    handleRedirectObservable(): Observable<AuthenticationResult | null>;
    loginPopup(request?: PopupRequest): Observable<AuthenticationResult>;
    loginRedirect(request?: RedirectRequest): Observable<void>;
    logout(logoutRequest?: EndSessionRequest): Observable<void>;
    ssoSilent(request: AuthorizationUrlRequest): Observable<AuthenticationResult>;
}

@Injectable()
export class MsalService implements IMsalService {
    private redirectHash!: string;
    msalInstance!: IPublicClientApplication;

    // Temporarily commented instance injection and brodcast service will be used in future
    constructor(
        private broadcastService: MsalBroadcastService,
        private configService: ConfigService,
        private location: Location
    ) {
        // Cache the code hash before Angular router clears it
        const hash = this.location.path(true).split('#').pop();
        if (hash) {
            this.redirectHash = `#${hash}`;
        }

        /**
         * Azure AD Authentication IDs and Redirect URL Configurations
         */
        this.configService.ssoConfig$.subscribe((value: any) => {
            if (value !== undefined && value !== null) {
                this.msalInstance = new PublicClientApplication({
                    auth: {
                        clientId: 'ecfcfecb-6621-4020-bec2-780ae59938cb',
                        authority: `https://login.microsoftonline.com/${'400696bb-3ef5-44ed-b838-ceb5afd17d90'}`,
                        redirectUri: window.location.origin + '/vault/',
                        postLogoutRedirectUri: window.location.origin,

                    },
                });
                this.configService.setSSOInitialized(true);
            }
        });
    }
    // Acquire Token popup function if the given request is popup
    acquireTokenPopup(request: PopupRequest): Observable<AuthenticationResult> {
        return from(this.msalInstance.acquireTokenPopup(request));
    }
    // Acquire token redirect if the given request is redirect
    acquireTokenRedirect(request: RedirectRequest): Observable<void> {
        return from(this.msalInstance.acquireTokenRedirect(request));
    }
    // Token silent request from the MSAL Library service
    acquireTokenSilent(silentRequest: SilentRequest): Observable<AuthenticationResult> {
        return from(this.msalInstance.acquireTokenSilent(silentRequest));
    }
    // Get account Username function after the successful login through Azure AD
    getAccountByUsername(userName: string): AccountInfo | null {
        return this.msalInstance.getAccountByUsername(userName);
    }
    // Get all accounts logged in
    getAllAccounts(): AccountInfo[] {
        return this.msalInstance.getAllAccounts();
    }
    // Handle redirect request from MSAL Library service.
    handleRedirectObservable(): Observable<AuthenticationResult | null> {
        return from(this.msalInstance.handleRedirectPromise(this.redirectHash));
    }
    // Login Popup functionality from MSAL , If the request is POPUP
    loginPopup(request?: PopupRequest): Observable<AuthenticationResult> {
        return from(this.msalInstance.loginPopup(request));
    }
    // Login redirect functionality from MSAL , If the request is REDIRECT
    loginRedirect(request?: RedirectRequest): Observable<void> {
        return from(this.msalInstance.loginRedirect(request));
    }
    // Logout functionality will invoke to end the current logged in session.
    logout(logoutRequest?: EndSessionRequest): Observable<void> {
        return from(this.msalInstance.logout(logoutRequest));
    }
    // SSO Authentication URL request can be invoked
    ssoSilent(request: AuthorizationUrlRequest): Observable<AuthenticationResult> {
        return from(this.msalInstance.ssoSilent(request));
    }

}
