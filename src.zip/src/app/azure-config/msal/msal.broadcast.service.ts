import { Injectable } from '@angular/core';
import { EventMessage } from '@azure/msal-browser';
import { Observable, Subject } from 'rxjs';

@Injectable()
export class MsalBroadcastService {
  // tslint:disable-next-line: variable-name
  private _msalSubject: Subject<any>;
  public msalSubject$: Observable<any>;
  // Broadcast MSAL subject is created here
  constructor(
  ) {
    this._msalSubject = new Subject<EventMessage>();
    this.msalSubject$ = this._msalSubject.asObservable();
  }

}
