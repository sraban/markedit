import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { Injector, NgModule } from '@angular/core';
import { InteractionType } from '@azure/msal-browser';
import { ConfigService } from '../services/config.service';
import { MSAL_GUARD_CONFIG, MSAL_INTERCEPTOR_CONFIG } from './constants';
import { MsalBroadcastService } from './msal.broadcast.service';
import { MsalGuard } from './msal.guard';
import { MsalGuardConfiguration } from './msal.guard.config';
import { MsalInterceptor } from './msal.interceptor';
import { MsalInterceptorConfig } from './msal.interceptor.config';
import { MsalService } from './msal.service';


export let InjectorInstance: Injector;

function MSALInterceptorConfigFactory(): MsalInterceptorConfig {
    const protectedResourceMap = new Map<string, Array<string>>();
    protectedResourceMap.set('https://graph.microsoft.com/v1.0/me', ['user.read']);

    return {
        interactionType: InteractionType.Popup,
        protectedResourceMap,
    };
}
@NgModule({
    declarations: [],
    imports: [],
    providers: [ConfigService,
        MsalService]
})
export class MsalModule {
    constructor() {
    }
    // All the necessary services for MSAL Azure is provided here
    static forRoot(): any {
        return {
            ngModule: MsalModule,
            providers: [
                {
                    provide: MSAL_GUARD_CONFIG,
                    useValue: {
                        interactionType: InteractionType.Popup,
                    } as MsalGuardConfiguration
                },
                {
                    provide: MSAL_INTERCEPTOR_CONFIG,
                    useFactory: MSALInterceptorConfigFactory

                },
                MsalGuard,
                MsalBroadcastService,
                {
                    provide: HTTP_INTERCEPTORS,
                    useClass: MsalInterceptor,
                    multi: true
                },
            ]
        };
    }

}
