import { HttpBackend, HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, Subscription } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ConfigService {
  // tslint:disable: variable-name
  private settings: any;
  private http: HttpClient;
  private _ssoConfig = new BehaviorSubject<object>({});
  public ssoConfig$ = this._ssoConfig.asObservable();

  private _isSSOInitialized = new BehaviorSubject<boolean>(false);
  public isSSOInitialized$ = this._isSSOInitialized.asObservable();

  constructor(private readonly httpHandler: HttpBackend) {
    this.http = new HttpClient(httpHandler);
    // this.init();
  }
  // Getting the Client ID, Tenant ID and Redirect URL from Azure AD
  init(): Subscription {
    return this.http.post('http://localhost:8080/vaultrest/api/azureSSODetails', {}).pipe(map(res => res)).subscribe(res => {
      this._ssoConfig.next(res);
    });
  }
  // Return true if the application is initialized with SSO login
  isSSOInitialized(): Observable<boolean> {
    return this.isSSOInitialized$;
  }
  // Sets , If the APllication is initialized for the SSO Login
  setSSOInitialized(val: boolean): void {
    this._isSSOInitialized.next(val);
  }
  // Included for returning the settings added for the Current Logged in user
  getSettings(key?: string | Array<string>): any {
    if (!key || (Array.isArray(key) && !key[0])) {
      return this.settings;
    }
    if (!Array.isArray(key)) {
      key = key.split('.');
    }
    const result = key.reduce((acc: any, current: string) => acc && acc[current], this.settings);
    return result;
  }
}
