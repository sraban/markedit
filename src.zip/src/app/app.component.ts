import { Component, Inject, OnInit } from '@angular/core';
import { InteractionType, PopupRequest, RedirectRequest } from '@azure/msal-browser';
import { MsalService } from './azure-config/msal';
import { MSAL_INTERCEPTOR_CONFIG } from './azure-config/msal/constants';
import { MsalInterceptorConfig } from './azure-config/msal/msal.interceptor.config';
import { ConfigService } from './azure-config/services/config.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  userToShow!: string | null;
  userName: string | undefined;
  loginDisplay = false;
  accounts: any;

  constructor(private configService: ConfigService) {
    this.setLoginDisplay();
  }

  ngOnInit(): void {
    if ((sessionStorage.getItem('userToShow') !== undefined || sessionStorage.getItem('userToShow') !== null)) {
      this.userToShow = sessionStorage.getItem('userToShow');
    }
    // For checking the account details
    // try {
    //   const account = this.authService.getAllAccounts()[0];
    //   if (account === undefined) {
    //     //this.callSSO();
    //   } else {
    //     this.validateUser();
    //   }
    // } catch (e) {
    //  // this.callSSO();
    // }
  }

  /**
   * @ngdoc method
   * @method callSSO
   * @methodOf AppComponent (Microsoft Azure call)
   * @description
   * To validate the user via loginPopup & acquireTokenRedirect to retive accessToken
   */
  // callSSO(): void {
  //   this.configService.isSSOInitialized$.subscribe((data) => {
  //     let ssoResponse;
  //     if (data != null && data !== undefined && data !== false) {
  //       if (this.msalInterceptorConfig.interactionType === InteractionType.Popup) {
  //         ssoResponse = this.authService.loginPopup({ ...this.msalInterceptorConfig.authRequest } as PopupRequest).toPromise();
  //         ssoResponse.then((value) => {
  //           this.setLoginDisplay();
  //           this.checkAndSetActiveAccount();
  //           this.validateUser();
  //         });
  //       } else {
  //         const redirectStartPage = window.location.href;
  //         this.authService.acquireTokenRedirect({ ...this.msalInterceptorConfig.authRequest, redirectStartPage } as RedirectRequest);
  //       }
  //     }
  //   });
  // }
  // Condition check for the background display flag.
  setLoginDisplay(): any {
   // this.loginDisplay = this.authService.msalInstance.getAllAccounts().length > 0;
  }
  checkAndSetActiveAccount(): void {
    /**
     * If no active account set but there are accounts signed in, sets first account to active account
     * To use active account set here, subscribe to inProgress$ first in your component
     * Note: Basic usage demonstrated. Your app may require more complicated account selection logic
     */

    // if (this.authService.msalInstance.getAllAccounts().length > 0) {
    //   this.accounts = this.authService.msalInstance.getAllAccounts();
    // }
  }


  /**
   * @ngdoc method
   * @method validateUser
   * @methodOf AppComponent (Service call)
   * @description
   * To validate the audit user and get AuditNo and VistNo
   */
  // validateUser(): void {
  //   if ((sessionStorage.getItem('auditorNo') === undefined || sessionStorage.getItem('auditorNo') === null)) {
  //     const account = this.authService.getAllAccounts()[0];
  //     const email = account.username;
  //     const sp = email.split('@');
  //     sessionStorage.setItem('userToShow', sp[0]);
  //     this.userToShow = sessionStorage.getItem('userToShow');
  //     /**
  //      * For now there is no service call called ,In future inneed.
  //      */
  //     this.userName = sp[0];

  //   } else {
  //     console.error('Error');
  //   }
  // }
}
