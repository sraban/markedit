import { HttpClient, HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { DialogModule, DialogsModule } from '@progress/kendo-angular-dialog';
import { GridModule } from '@progress/kendo-angular-grid';
import { LayoutModule } from '@progress/kendo-angular-layout';
import { MenuModule } from '@progress/kendo-angular-menu';
import { NavigationModule } from '@progress/kendo-angular-navigation';
import { PagerModule } from '@progress/kendo-angular-pager';
import { TooltipModule } from '@progress/kendo-angular-tooltip';
import { AppRoutingModule } from './app-routing.module';
import { AppSharedModule } from './app-shared/app-shared.module';
import { AppComponent } from './app.component';
// import { MsalModule } from './azure-config/msal/msal.module';
import { BaseInterceptorInterceptor } from './common/base-interceptor.interceptor';
import { DataService } from './common/data.service';
import { FooterComponent } from './footer/footer.component';
import { HeaderComponent } from './header/header.component';
import { TestinHandsontableComponent } from './modules/testin-handsontable/testin-handsontable.component';
import { TestingKendoComponent } from './modules/testing-kendo/testing-kendo.component';
import { PopupModule } from '@progress/kendo-angular-popup';


export function HttpLoaderFactory(http: HttpClient): TranslateHttpLoader {
  return new TranslateHttpLoader(http, './assets/i18n/', '.json');
}
@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    TestingKendoComponent,
    FooterComponent,
    TestinHandsontableComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    GridModule,
    TranslateModule.forRoot({
      defaultLanguage: 'en',
      isolate: true,
      loader: {
        provide: TranslateLoader,
        useFactory: (HttpLoaderFactory),
        deps: [HttpClient]
      }
    }),
    // MsalModule.forRoot(),
    BrowserAnimationsModule,
    NavigationModule,
    AppSharedModule,
    LayoutModule,
    DialogModule,
    MenuModule,
    PagerModule,
    DialogsModule,
    TooltipModule,
    PopupModule,
  ],
  providers: [DataService,
    { provide: HTTP_INTERCEPTORS, useClass: BaseInterceptorInterceptor,  multi: true }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }

