import { Component, EventEmitter, OnInit, Output, ViewEncapsulation } from '@angular/core';
import Handsontable from 'handsontable';
import { DataService } from 'src/app/common/data.service';

@Component({
  selector: 'app-testin-handsontable',
  templateUrl: './testin-handsontable.component.html',
  styleUrls: ['./testin-handsontable.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class TestinHandsontableComponent implements OnInit {

  // dataSet accepts table data
  dataSet1: any[] = [];
  dataSet2: any[] = [];
  id1 = 'hotTable1';
  id2 = 'hotTable2';
  opened = false;
  showTitle = 'Testing';
  lookUpValue: any;
  readonly =  true;

  // columnHeader -- header for the respective column
  columnHeader: string[] = [`<input type='checkbox' id='selectAllCheckbox' />`, 'Field Name', 'Field Type', 'Max Field Length', 'Max Precision',
  'Lov Flg', 'Field Heading', 'Field Value', 'Mandatory Flg'];

  // columns -- specify column details like width, data, readOnly, validators etc.,
  columns: any[] = [];
  commandIndex: any;
  columnsWithRemove: any;
  instance: any;

  hotSettings: Handsontable.GridSettings = {};
  selectedLUV: any;
  constructor(private service: DataService) { }

  ngOnInit(): void {
    this.service.getHandsontableData().subscribe((response: any) => {
      const data = response.results[0];
      this.dataSet1 = data.dynamic_list;
      this.commandIndex = { checkbox: 0, options: 5, manageCol: true, height: 350, deleteBtnIndex: 3, specificCol: [1, 2] };
      // this.dataSet2 = data.outSideTradeNameTableList;
      // this.columnHeader = ['commands', 'Field Name', 'Field Type', 'Max Field Length', 'Max Precision',
      //   'Lov Flg', 'Field Heading', 'Field Value', 'Mandatory Flg'];

      this.hotSettings.columns = [
        {
          renderer: (instance, TD, row, col, prop, value, cellProperties) => {
            TD.innerHTML = `<input type='checkbox' id='checkbox' /> `;
            return TD;
          },
          colHeaders: true, width: 300, readOnly: true
        },
        { data: 'field_name', width: 200, type: 'dropdown', source: ['A', 'B', 'C', 'D', 'E', 'F'],
          renderer: (instance, TD, row, col, prop, value, cellProperties) => {
            TD.innerHTML = `<span class="alignBeforeSelection">${value ? value : ''}</span> `;
            return TD;
          } },
        { data: 'field_type', width: 60, renderer: (instance, TD, row, col, prop, value, cellProperties) => {
          TD.innerHTML = `<span class="alignBeforeSelection">${value ? value : ''}</span> `;
          return TD;
        } },
        { data: 'max_field_length', readOnly: true, width: 40, validator: this.numberValidate,
        allowInvalid: false, renderer: (instance, TD, row, col, prop, value, cellProperties) => {
          TD.innerHTML = `<span class="alignBeforeSelection">${value ? value : 0}</span> `;
          return TD;
        } },
        { data: 'max_precision', readOnly: true, width: 40,  renderer: (instance, TD, row, col, prop, value, cellProperties) => {
          TD.innerHTML = `<span class="alignBeforeSelection">${value ? value : ''}</span> `;
          return TD;
        } },
        {
          data: 'lov_flg', width: 200, class: 'newStyleFortd' , renderer: (instance, TD, row, col, prop, value, cellProperties) => {
            TD.innerHTML = `<button id='editInline' disabled="true" class="k-icon k-i-edit ">
            </button> <button id='addInline' disabled="true" class="k-icon k-i-add"></button>
            </button> <button id='copyInline' disabled="true" class="k-icon k-i-copy"></button>
             <span style="display: none;" id='deletePopup' (click)="del(instance, row)" class="k-icon k-i-delete"></span>`;
            return TD;
          }
        },
        { data: 'field_heading', width: 200, readOnly: true, renderer: (instance, TD, row, col, prop, value, cellProperties) => {
          TD.innerHTML = `<span class="alignBeforeSelection">${value ? value : ''}</span> `;
          return TD;
        } },
        { data: 'field_value', readOnly: true, width: 400, renderer: (instance, TD, row, col, prop, value, cellProperties) => {
          TD.innerHTML = `<span class="alignBeforeSelection">${value ? value : ''}</span> `;
          return TD;
        } },
        { data: 'mandatory_flg', readOnly: true, width: 200, renderer: (instance, TD, row, col, prop, value, cellProperties) => {
          TD.innerHTML = `<span class="alignBeforeSelection">${value ? value : ''}</span> `;
          return TD;
        } }
      ];
      this.columns = this.hotSettings.columns;


    // this.dataSet1 = response.Values;
    // const headerDetails = response.headers;
    // headerDetails.forEach((col: any, i: number) => {
      // this.columnHeader.length = col.field_order > this.columnHeader.length ? col.field_order :
      //  this.columnHeader.length;
      //  this.columns.length = col.field_order > this.columns.length ? col.field_order :
      //  this.columns.length;
      // this.columnHeader.push(col.field_heading);
      // this.columns.push({
      //   data: col.field_name,
      //   title: col.field_heading,
        
      // });
      // this.columnHeader.splice(col.field_order, 1, col.field_heading);
      // this.columns.splice(col.field_order, 1, {
      //     data: col.field_name,
      //     title: col.field_heading,
      //   });
    // });

// this.columns = this.columns.filter(Boolean);
// this.columnHeader = this.columnHeader.filter(Boolean);
    // this.hotSettings.columns = [{}];
    });
  }

  set() {
    this.dataSet2 = this.dataSet1;
  }

  reset() {
    this.dataSet2 = [];
  }
  getInstance(data: any): void {
    if (data === 'opened') {
      this.opened = true;
    }else {
      // console.log(data);
      // data.render();
    }
  }
  getCellValue(data: any): void {
    console.log(data);
  }

  public checkBox(instance: any, td: any, row: any, col: any, prop: any, value: any, cellProperties: any): void {
    const del = document.createElement('input');
    del.setAttribute('id', 'checkbox');
    del.setAttribute('type', 'checkbox');
    Handsontable.dom.empty(td);
    td.appendChild(del);
  }

  public delete(instance: any, td: any, row: any, col: any, prop: any, value: any, cellProperties: any): void {
    const del = document.createElement('span');
    del.setAttribute('class', 'k-icon k-i-add');
    del.setAttribute('value', 'Add');
    // del.setAttribute()
    Handsontable.dom.empty(td);
    td.appendChild(del);
    Handsontable.dom.addEvent(del, 'click', () => {
      console.log('removed');
      instance.alter('insert_row', row + 1);
    });
    // del.addEventListener('click', () => {
    //   console.log('removed');
    //   instance.alter('insert_row', row + 1);
    // });
  }


  del(instance: any, td: any, row: any, col: any, prop: any, value: any, cellProperties: any) {
    const p = document.createElement('p');
    const ele = document.createElement('span');
    ele.setAttribute('class', 'k-icon k-i-zoom');
    ele.setAttribute('id', 'search');
    p.appendChild(document.createTextNode(`${value}     `));
    p.appendChild(ele);
    Handsontable.dom.empty(td);
    td.appendChild(p);
    ele.addEventListener('click', () => {
      console.log('removed');
      instance.alter('insert_row', row + 1);
      this.service.getHandsontableData().subscribe((data: any) => {
      console.log(data);
      })
    });
  }


  numberValidate(value: any, callback: any): void {
    if (/^[0-9]*$/.test(value)) {
      callback(true);
    } else {
      callback(false);
    }
  }

  setValue(data: any): void {
    this.selectedLUV = data;
    this.opened = false;
    if (typeof data === 'object') {
      this.lookUpValue = data.CODE;
      // console.log(this.lookUpValue);
    }
  }


  aftGridClosed(data: any): void {
    if (!data) {
      this.opened = false;
    }
  }
}














// , 'Field Show', 'Mandatory Flg', 'Code', 'Section Name',
// 'Section Code', 'Field Data Type', 'Dropdown Query', 'Dropdown Code', 'Dropdown Desc',
// 'Dropdown List', 'Table Flg', 'Field Order', 'Matrix Type', 'Info', 'GetFieldValueList',
// 'Field Return Type'

 //  {data: 'field_show', width: 10 },
      //  {data: 'mandatory_flg', width: 10 },
      //  {data: 'code', width: 10 },
      //  {data: 'section_name', width: 10 },
      //  {data: 'section_code', width: 10 },
      //  {data: 'field_data_type', width: 10 },
      //  {data: 'dropdown_query', width: 10 },
      //  {data: 'dropdown_code', width: 10 },
      //  {data: 'dropdown_desc', width: 10 },
      //  {data: 'dropdown_list', width: 10 },
      //  {data: 'table_flg', width: 10 },
      //  {data: 'field_order', width: 10 },
      //  {data: 'matrix_type', width: 10 },
      //  {data: 'info', width: 10 },
      //  {data: 'getFieldValueList', width: 10 },
      //  {data: 'field_return_type', width: 10 },


      // renderHtml( instance: any, td: any, row: any, col: any, prop: any, value: any, cellProperties: any): void {
      //   const cellValue = instance.getDataAtCell(row, 5);
      //   // console.log(cellValue, value);
      //   const p = document.createElement('p');
      //   const ele = document.createElement('span');
      //   ele.setAttribute('class', 'k-icon k-i-zoom');
      //   // ele.setAttribute('value', 'Search');
      //   ele.setAttribute('id', 'search');
      //   p.appendChild(document.createTextNode(`${value}     `));
      //   p.appendChild(ele);
      //   Handsontable.dom.empty(td);
      //   td.appendChild(p);
      //   ele.addEventListener('click', () => {
      //     this.opened = true;
      //   });
      // }

      // public delete( instance: any, td: any, row: any, col: any, prop: any, value: any, cellProperties: any): void {
      //   const del = document.createElement('span');
      //   del.setAttribute('class', 'k-icon k-i-delete');
      //   // del.setAttribute('value', 'Delete');
      //   Handsontable.dom.empty(td);
      //   td.appendChild(del);
      //   // Handsontable.dom.addEvent(del, 'click', () => {
      //   //   console.log('removed');
      //   //   instance.alter('remove_row', row);
      //   // });
      //   del.addEventListener('click', () => {
      //     console.log('removed');
      //     instance.alter('remove_row', row);
      //   });
      // }
