import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TestinHandsontableComponent } from './testin-handsontable.component';

describe('TestinHandsontableComponent', () => {
  let component: TestinHandsontableComponent;
  let fixture: ComponentFixture<TestinHandsontableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TestinHandsontableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TestinHandsontableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
