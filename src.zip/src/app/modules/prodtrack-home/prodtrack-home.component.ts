import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-prodtrack-home',
  templateUrl: './prodtrack-home.component.html',
  styleUrls: ['./prodtrack-home.component.scss']
})
export class ProdtrackHomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
