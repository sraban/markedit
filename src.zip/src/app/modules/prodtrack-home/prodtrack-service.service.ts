import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProdtrackServiceService {

  public valueChange = new BehaviorSubject(false);
  // for Search value
  private searchSubject = new Subject<any>();
  searchObservable = this.searchSubject.asObservable();
  editMaterialData: any;
  public materialSearchFormState = new BehaviorSubject<boolean>(true);
  editReviewData: any;
  constructor() {
  }

  // tslint:disable-next-line:typedef
  setValue(value: boolean) {
    this.valueChange.next(value);
  }
  // tslint:disable-next-line:typedef
  getValue() {
    return this.valueChange.asObservable();
  }
  // Service message commands
  callComponentMethod(value: any): void {
    this.searchSubject.next(value);
  }
  setEditMaterialData(data: any): void {
    this.editMaterialData = data;
  }
  getEditMaterialData(): any {
    return this.editMaterialData;
  }
  setEditReviewData(data: any): void {
    this.editReviewData = data;
  }
  getEditReviewData(): any {
    return this.editReviewData;
  }
}
