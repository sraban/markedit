import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-breadcrumb-prodtrack',
  templateUrl: './breadcrumb.component.html',
  styleUrls: ['./breadcrumb.component.scss']
})
export class BreadcrumbComponent {
  path: any;
  constructor(private router: Router) {
    router.events.subscribe( val => {

      this.path = this.router.url;
      const pathArray = this.path.split('/');
      this.path = 'prodtrack-breadcrumb.' + pathArray[2];


    });

  }



}
