import { TestBed } from '@angular/core/testing';

import { ProdtrackBaseService } from './prodtrack-base.service';

describe('ProdtrackBaseService', () => {
  let service: ProdtrackBaseService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ProdtrackBaseService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
