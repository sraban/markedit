import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Subject } from 'rxjs';
import { constObj } from '../prodtrack-constants';

@Injectable({
  providedIn: 'root'
})
export class ProdtrackBaseService {
  public resetForm: Subject<any> = new Subject<any>();
  constructor(private http: HttpClient) { }

  // Common API for Dropdown
  getDropdownAPI(url: any, reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + url, reqObj);
  }

  // Save material DB API
  saveMaterial(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.addMaterialDb.save, reqObj);
  }
  // load CPL material details
  loadWpl(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.addMaterialDb.loadWpl, reqObj);
  }
  // load CPL material details
  loadSubWpl(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.addMaterialDb.loadSubWpl, reqObj);
  }
  // search Dcc in add material details
  dccSearch(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.addMaterialDb.dccSearch, reqObj);
  }
  // Edit material DB API to fetch material details
  addMateriaDb(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.addMaterialDb.add, reqObj);
  }
  // Edit material DB API to fetch material details
  editMateriaDb(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.testedMaterialDb.editMaterialdb.edit, reqObj);
  }
  // Edit material DB API to load CPL material details
  loadWplDetailsEditMaterialDb(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.testedMaterialDb.editMaterialdb.wplDetails, reqObj);
  }
  // Edit material DB API to save material details
  saveEditMaterialDbInfo(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.testedMaterialDb.editMaterialdb.saveEditMaterial, reqObj);
  }
  // Edit material DB API to clear material details
  clearEditMaterialDbInfo(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.testedMaterialDb.editMaterialdb.clearEditMaterial, reqObj);
  }
  // view material db info
  viewMaterialDbInfo(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.viewMaterialDB.view, reqObj);
  }
  // Get Trade Names  material db info
  getTradeNames(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.addMaterialDb.tradeName, reqObj);
  }
  // Review/Manage Review Table Data
  manageReviewTableData(): any {
    return this.http.get(constObj.prodtrackReview.manageReview.manageReviewTableInfo);
  }
  // Review/ManageReview Details
  manageReviewDetails(): any {
    return this.http.get(constObj.prodtrackReview.manageReview.manageReviewInfo);
  }
  // Edit material DB API to load CPL Table header material details
  cplTableHeader(): any {
    return this.http.get(constObj.testedMaterialDb.editMaterialdb.cplHeaderDetails);
  }
  // Edit material DB API to load CPL Table column material details
  cplTableColumn(): any {
    return this.http.get(constObj.testedMaterialDb.editMaterialdb.cplColumnDetails);
  }
  // Search material DB API to fetch material details
  searchMaterialDb(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.searchMaterialDB.search, reqObj);
  }
   // Review Search  API to fetch  details
   reviewsearch(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.reviewsearch.search, reqObj);
  }
   // Review Search justification  API to fetch details
   getJustificationDropDown(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.reviewsearch.getJustificationDropDown, reqObj);
  }
   // Review Search justification  API to fetch details
   programDropDown(reqObj: any): any {
      return this.http.post(`${environment.baseUrl}` + constObj.reviewsearch.programDropDown, reqObj);
    }
    reviewTypeDropDown(reqObj: any): any {
      return this.http.post(`${environment.baseUrl}` + constObj.reviewsearch.reviewTypeDropDown, reqObj);
    }
    reviewStatusDropDown(reqObj: any): any {
      return this.http.post(`${environment.baseUrl}` + constObj.reviewsearch.reviewStatusDropDown, reqObj);
    }

// Info Tab in Edit Review
  getNotesDetails(reqObj: any): any{
    return this.http.post(`${environment.baseUrl}` + constObj.prodtrackReview.notes.getNotes, reqObj);
  }
  deleteNote(reqObj: any): any{
    return this.http.post(`${environment.baseUrl}` + constObj.prodtrackReview.notes.delete, reqObj);
  }
  createNotes(reqObj: any): any{
    return this.http.post(`${environment.baseUrl}` + constObj.prodtrackReview.notes.createNotes, reqObj);
  }
}
