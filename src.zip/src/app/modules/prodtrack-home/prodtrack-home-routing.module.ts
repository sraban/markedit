import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddMaterialDBComponent } from './material-db/add-material-db/add-material-db.component';
import { MaterialDbComponent } from './material-db/material-db.component';
import { ProdtrackHomeComponent } from './prodtrack-home.component';
import { CreateReviewComponent } from './review/create-review/create-review.component';
import { ManageReviewComponent } from './review/manage-review/manage-review.component';
import { ReviewComponent } from './review/review.component';
import { ViewReviewComponent } from './review/view-review/view-review.component';
import { SearchMaterialsComponent } from './material-db/add-material-db/search-materials/search-materials.component';
import { ViewMaterialDbComponent } from './view-material-db/view-material-db.component';
import { EditMaterialsDbComponent } from './material-db/edit-material-db/edit-material-db.component';


const routes: Routes = [{
  path: '', component: ProdtrackHomeComponent,
  children: [
    { path: '', redirectTo: 'searchTestedMaterialDb', pathMatch: 'prefix' },
    { path: 'searchTestedMaterialDb', component: MaterialDbComponent },
    { path: 'addtestedmaterials', component: SearchMaterialsComponent },
    { path: 'addtestedmaterialdb', component: AddMaterialDBComponent },
    { path: 'editTestedMaterialDb', component: EditMaterialsDbComponent },
    { path: 'viewTestedMaterialDb/:epsfId', component: ViewMaterialDbComponent },
    { path: 'review', component: ReviewComponent },
    { path: 'createReview', component: CreateReviewComponent },
    { path: 'viewReview', component: ViewReviewComponent },
    { path: 'manageReview', component: ManageReviewComponent }
  ]
}];


@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ProdtrackHomeRoutingModule { }
