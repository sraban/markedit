import { Component, ElementRef, OnInit, Renderer2, ViewChild } from '@angular/core';


@Component({
  selector: 'app-sub-header',
  templateUrl: './sub-header.component.html',
  styleUrls: ['./sub-header.component.scss']
})
export class SubHeaderComponent implements OnInit {
  isMenuOpen!: boolean;
  @ViewChild('toggleButton') toggleButton!: ElementRef;
  @ViewChild('menu1') menu1!: ElementRef;

  constructor(
    private renderer: Renderer2
  ) {
    /**
     * Popup close functionality when click outside the Menu popup
     */
    this.renderer.listen('window', 'click', (e: Event) => {
      if (this.isMenuOpen) {
        if (e.target !== this.toggleButton.nativeElement &&
          e.target !== this.menu1.nativeElement) {
          this.isMenuOpen = false;
        }
      }
    });
  }

  ngOnInit(): void {
    // component initializing
  }

  /**
   * toggle function helps to open/close the hamburger menu
   */
  toggleMenu(): any {
    setTimeout(() => {
      this.isMenuOpen = !this.isMenuOpen;
    }, 100);
  }

}
