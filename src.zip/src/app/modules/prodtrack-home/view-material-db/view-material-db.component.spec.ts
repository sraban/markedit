import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewMaterialDbComponent } from './view-material-db.component';

describe('ViewMaterialDbComponent', () => {
  let component: ViewMaterialDbComponent;
  let fixture: ComponentFixture<ViewMaterialDbComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewMaterialDbComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewMaterialDbComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
