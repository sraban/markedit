import { HttpClient } from '@angular/common/http';
import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { ProdtrackServiceService } from '../prodtrack-service.service';
import { ProdtrackBaseService } from '../services/prodtrack-base.service';

@Component({
  selector: 'app-view-material-db',
  templateUrl: './view-material-db.component.html',
  styleUrls: ['./view-material-db.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class ViewMaterialDbComponent implements OnInit {
  dataset: any;
  columnHeader: any;
  columns: any;
  id = 'viewTable';
  public loader: any;
  private isActive = new Subject();
  notify: any;
  viewMaterialDbInfo: any;
  editMaterialDbInfo: any;
  epsfId: any;
  showTable = false;
  constructor(
    private http: HttpClient,
    private prodtrackBaseService: ProdtrackBaseService,
    private dataservice: ProdtrackServiceService,
    private router: Router,
    private activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {
    this.epsfId = this.activatedRoute.snapshot.params.epsfId;
    // View Material Table Headers
    this.columnHeader = ['DspSeq#', 'Item#', 'Alt Ind', 'In Plant', 'Part DCC', 'Part Trade Name', 'Part',
      'Part Desc', 'Supplier', 'Formulator', 'Quantity', 'Material Type', 'Wetted Area Part', 'Wetted Area Units'
    ];
    // View Material Table Columns
    this.columns = [
      {
        data: 'dspSeqNbr'
      },
      {
        data: 'itmNum'
      },
      {
        data: 'altInd'
      },
      {
        data: 'inPlant'
      },
      {
        data: 'dcc'
      },
      {
        data: 'tradeName'
      },
      {
        data: 'partNum'
      },
      {
        data: 'descr'
      },
      {
        data: 'supplier'
      },
      {
        data: 'formulator'
      },
      {
        data: 'quantity'
      },
      {
        data: 'matType'
      },
      {
        data: 'areaUnit'
      }
    ];
    this.viewmaterialData();
  }
  // Get viewMaterialInfo using epsf-id
  viewmaterialData(): any {
    const reqObj = {
      epsfId: this.epsfId
    };
    this.loader = true;
    this.prodtrackBaseService
      .viewMaterialDbInfo(reqObj)
      .pipe(takeUntil(this.isActive))
      .subscribe(
        (response: any) => {
          if (response.status === 'SUCCESS') {
            this.showTable = true;
            this.viewMaterialDbInfo = response.results;
            this.dataset = response.results.mainWplDtls;
            this.editMaterialDbInfo = response.results.mHdr;
            this.loader = false;
            if (this.viewMaterialDbInfo === '') {
              this.loader = false;
              this.notify =
              {
                style: 'error',
                content: 'No records found, Please click back button and try with different EPSF ID'
              };
            }
          } else {
            this.loader = false;
            this.notify =
            {
              style: 'error',
              content: 'No records found, Please click back button and try with different EPSF ID'
            };
          }
        },
        (err: any) => {
          this.loader = false;
          this.notify =
          {
            style: 'error',
            content: err.statusText
          };
        }
      );
  }
  // navigate to edit material component
  navigateEditMaterial(): void {
    this.dataservice.setEditMaterialData(this.editMaterialDbInfo);
    this.router.navigate(['prodtrack/editTestedMaterialDb']);
  }
}
