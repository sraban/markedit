import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';

import { ProdtrackHomeRoutingModule } from './prodtrack-home-routing.module';
import { ProdtrackHomeComponent } from './prodtrack-home.component';

import { SubHeaderComponent } from './sub-header/sub-header.component';
import { SideMenuComponent } from './side-menu/side-menu.component';
import { MaterialDbComponent } from './material-db/material-db.component';
import { PanelBarModule } from '@progress/kendo-angular-layout';
import { MenuModule } from '@progress/kendo-angular-menu';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ViewMaterialDbComponent } from './view-material-db/view-material-db.component';
import { AddMaterialDBComponent } from './material-db/add-material-db/add-material-db.component';
import { MaterialDbSavedSearchComponent } from './material-db/material-db-saved-search/material-db-saved-search.component';

import { LabelModule } from '@progress/kendo-angular-label';
import { InputsModule } from '@progress/kendo-angular-inputs';
import { DropDownListModule, DropDownsModule } from '@progress/kendo-angular-dropdowns';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { IntlModule } from '@progress/kendo-angular-intl';
import { DateInputsModule } from '@progress/kendo-angular-dateinputs';

import { SearchFilterTextComponent } from './common-component/search-filter-text/search-filter-text.component';
import { SearchFilterTextemployeeComponent } from './common-component/search-filter-textemployee/search-filter-textemployee.component';
import { SearchFilterMultiselectComponent } from './common-component/search-filter-multiselect/search-filter-multiselect.component';
import { AppSharedModule } from 'src/app/app-shared/app-shared.module';
import { ProdtrackBaseService } from './services/prodtrack-base.service';
import { ReviewComponent } from './review/review.component';
import { CreateReviewComponent } from './review/create-review/create-review.component';
import { ReviewSavedSearchComponent } from './review/review-saved-search/review-saved-search.component';
import { ViewReviewComponent } from './review/view-review/view-review.component';
import { ManageReviewComponent } from './review/manage-review/manage-review.component';
import { SearchMaterialsComponent } from './material-db/add-material-db/search-materials/search-materials.component';
import { BreadcrumbComponent } from './breadcrumb/breadcrumb.component';
import { EditMaterialsDbComponent } from './material-db/edit-material-db/edit-material-db.component';
import { CustomConfirmPopupProdtrackComponent } from './common-component/custom-confirm-popup-prodtrack/custom-confirm-popup-prodtrack.component';
import { SerachDropdownlistComponent } from './common-component/serach-dropdownlist/serach-dropdownlist.component';

@NgModule({
  declarations: [
    ProdtrackHomeComponent,
    SubHeaderComponent,
    SideMenuComponent,
    MaterialDbComponent,
    ViewMaterialDbComponent,
    MaterialDbSavedSearchComponent,
    SearchFilterTextComponent,
    SearchFilterMultiselectComponent,
    SearchFilterTextemployeeComponent,
    AddMaterialDBComponent,
    ReviewComponent,
    CreateReviewComponent,
    ReviewSavedSearchComponent,
    ViewReviewComponent,
    ManageReviewComponent,
    SearchMaterialsComponent,
    BreadcrumbComponent,
    EditMaterialsDbComponent,
    CustomConfirmPopupProdtrackComponent,
    SerachDropdownlistComponent
  ],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    ProdtrackHomeRoutingModule,
    ProdtrackHomeRoutingModule,
    MenuModule,
    FormsModule,
    PanelBarModule,
    LabelModule,
    InputsModule,
    DropDownListModule,
    DropDownsModule,
    AppSharedModule,
    ButtonsModule,
    DateInputsModule,
    IntlModule
  ],
  providers: [ ProdtrackBaseService , DatePipe],
})
export class ProdtrackHomeModule { }
