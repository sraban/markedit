import { Component, Input, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { ProdtrackServiceService } from '../../prodtrack-service.service';

@Component({
  selector: 'app-material-db-search-buttons',
  templateUrl: './material-db-search-buttons.component.html',
  styleUrls: ['./material-db-search-buttons.component.scss']
})
export class MaterialDbSearchButtonsComponent implements OnInit {
  @Input() formGroup!: FormGroup;
   // add fields in search material db
   dropDownFields = [
    'Epsf #', 'Primary(Tested) DCC', 'City', 'TestType', 'Emp #', 'User Type', 'Part #', 'Corporate(Tested)DCC', 'Trade Name', 'Emp Name', 'Super Corporate', 'Supplier'
  ];
  constructor(private prodTrackService: ProdtrackServiceService ) { }

  ngOnInit(): void {
  }
// dynamic filter for serach of grid
  searchButton(): void{
    const status = this.formGroup.value.status[0].text;
    this.prodTrackService.callComponentMethod(status.toLowerCase());
  }

}
