import { Component, Input, OnInit, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-material-db-saved-search',
  templateUrl: './material-db-saved-search.component.html',
  styleUrls: ['./material-db-saved-search.component.scss'],
  encapsulation: ViewEncapsulation.None

})
export class MaterialDbSavedSearchComponent implements OnInit {
  // drop down for slected
  dropDown = [
    'default', '.........', 'Personalize..'
  ];
  showmodel = false;
  selectedValue: any;
  showpopup = false;
  // tslint:disable-next-line:no-inferrable-types
  duplicateFlag: boolean = false;
  // Drop for dialog model
  dropDownSearch = [
    'Default'
  ];
  showTitle = 'Personalize Saved Searches';
  popupTitle = 'Warning';
  public saveForm: FormGroup;
  constructor(private fb: FormBuilder) {
    this.saveForm = this.fb.group({
      savedSearchName: new FormControl('Default copy'),
      setDefault: new FormControl(),
      runAtStart: new FormControl(),
      Searchshowlist: new FormControl(),
      savedSearch: new FormControl(this.selectedValue),
    });
  }

  ngOnInit(): void {

  }
  // adding the field dialog Saved Search
  Duplicate(): any {
    this.duplicateFlag = true;
    this.dropDownSearch.push(this.selectedValue);
  }
  // delete field on popup

  Delete(): any {
    this.showpopup = true;
  }
  // click action dialog eventemiter
  useraction(data: boolean): any {
    // form  for user action

  }
  // drop down at the selected dialog model
  valueChange(ev: any): any {
    if (this.selectedValue === 'Personalize..') {
      this.showmodel = true;
    }
  }
  // after closing event calling dialog purpose
  showDialog(data: any): any {
    this.showmodel = data;
  }

}
