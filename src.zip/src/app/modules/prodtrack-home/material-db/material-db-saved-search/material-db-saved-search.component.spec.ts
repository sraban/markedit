import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MaterialDbSavedSearchComponent } from './material-db-saved-search.component';

describe('MaterialDbSavedSearchComponent', () => {
  let component: MaterialDbSavedSearchComponent;
  let fixture: ComponentFixture<MaterialDbSavedSearchComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MaterialDbSavedSearchComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MaterialDbSavedSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
