import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MaterialDbComponent } from './material-db.component';

describe('MaterialDbComponent', () => {
  let component: MaterialDbComponent;
  let fixture: ComponentFixture<MaterialDbComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MaterialDbComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MaterialDbComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
