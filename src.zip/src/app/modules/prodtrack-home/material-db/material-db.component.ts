import { Component, OnDestroy, OnInit, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { gridData, searchFilters, conditionDropdownListData, dropDownFields } from './data';
import { process } from '@progress/kendo-data-query';
import { ProdtrackServiceService } from '../prodtrack-service.service';
import { takeUntil } from 'rxjs/operators';
import { Subject } from 'rxjs';
import { ProdtrackBaseService } from '../services/prodtrack-base.service';
import { Router } from '@angular/router';
import { GridDataResult, PageChangeEvent } from '@progress/kendo-angular-grid';


@Component({
  selector: 'app-material-db',
  templateUrl: './material-db.component.html',
  styleUrls: ['./material-db.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class MaterialDbComponent implements OnInit, OnDestroy {
  public gridView: GridDataResult;
  formGroup!: any;
  fieldControls: any = {};
  count = 0;
  match = 'match';
  buttonCount = 5;
  pageSize = 50;
  savepopup = false;
  saveTitle = 'Create Saved Search';
  public skip = 0;
  /*To set collapsible open*/
  expanded = true;
  searchKey!: string;
  /* Sample data from services*/
  public dataSet: any = gridData;
  public searchFilters: any = searchFilters;
  public conditionDropdownList: Array<any> = conditionDropdownListData;
  public dropDownFields: any = dropDownFields;
  // public gridView: {
  //   data: any[],
  //   total: number,
  // };
  public columns: any[] = [];
  oldResult: any;
  searchButtonDisable = true;
  reqObj: any;
  public saveForm: FormGroup;
  public loader: any;
  private isActive = new Subject();
  notify: any;
  searchMaterialDetails: any;
  id = 'materialTable';
  data: any[];
  showTable = false;
  constructor(
    private prodTrackService: ProdtrackServiceService, private fb: FormBuilder,
    private prodtrackBaseService: ProdtrackBaseService, private router: Router,
  ) {
    this.gridView = {
      data: [],
      total: 0
    };
    this.data = [];
    this.saveForm = this.fb.group({
      savedSearchName: new FormControl('Default copy'),
      setDefault: new FormControl(),
      runAtStart: new FormControl(),
      savedSearch: new FormControl(),
    });
  }
  public pageChange(event: PageChangeEvent): void {
    this.skip = event.skip;
    this.loadProducts();
  }

  private loadProducts(): void {
    this.gridView = {
      data: this.data.slice(this.skip, this.skip + this.pageSize),
      total: this.data.length,
    };
  }
  ngOnInit(): void {
    this.createFromGroup();
    this.loadProducts();
    this.oldResult = this.formGroup.value;
    this.prodTrackService.searchObservable.subscribe((res: any) => {
      this.onFilter(res);
    }
    );
    this.prodTrackService.materialSearchFormState.subscribe(response => {
      this.searchButtonDisable = response;
    });
    this.gridView = {
      data: [],
      total: 0
    };
  }
  /*
  * create from Group
  */
  navigate(epsfId: any): void {
    this.router.navigate(['/prodtrack/viewTestedMaterialDb/' + epsfId]);
  }
  createFromGroup(): void {
    searchFilters.forEach((element: any) => {
      this.fieldControls[element.name] = new FormControl(element.value);
      this.fieldControls[element.conditionName] = new FormControl(element.conditionValue);
    });
    this.fieldControls[this.match] = new FormControl('All');
    this.formGroup = new FormGroup(this.fieldControls);
  }
  // Specific search filter for Review page based on the Review type.
  public onFilter(inputValue: any): void {
    if (inputValue) {
      this.gridView.data = process(this.dataSet, {
        filter: {
          logic: 'or',
          filters: [
            {
              field: 'Status',
              operator: 'contains',
              value: inputValue,
            },
            {
              field: 'EPSF',
              operator: 'contains',
              value: inputValue,
            },
            {
              field: 'PrimaryTestedDCC',
              operator: 'contains',
              value: inputValue,
            },
            {
              field: 'PrimaryTestedCorporate',
              operator: 'contains',
              value: inputValue,
            },
            {
              field: 'UseType',
              operator: 'contains',
              value: inputValue,
            },
            {
              field: 'TestType',
              operator: 'contains',
              value: inputValue,
            },
            {
              field: 'TradeName',
              operator: 'contains',
              value: inputValue,
            },
          ],
        }
      }).data;
    } else {
      this.gridView = this.dataSet;
    }
  }
  // tslint:disable-next-line:typedef
  getStatus(value: any) {
    if (value ?.length > 0) {
      const filterValue = value[0].text;
      return filterValue.toLowerCase();
    }
    else {
      return '';
    }

  }
  // tslint:disable-next-line:typedef
  compareSearchTerm(oldValue: any, newValue: any) {
    // tslint:disable-next-line:forin
    let searchKey = '';
    this.reqObj = {
      searchFields: []
    };
    // tslint:disable-next-line:forin
    for (const oldKey in oldValue) {
      const savedValue = oldValue[oldKey];
      let isMatchFound = false;
      // tslint:disable-next-line:forin
      for (const newKey in newValue) {
        const changeValue = newValue[newKey];
        if (!isMatchFound && oldKey === newKey && savedValue !== changeValue) {
          if (Array.isArray(changeValue)) {
            searchKey = changeValue[0].text;
            this.getRequestedSearchFields(this.reqObj, newKey, newValue);
          } else {
            searchKey = changeValue;
            this.getRequestedSearchFields(this.reqObj, newKey, newValue);
          }
          isMatchFound = true;
        }
      }
    }
    this.searchKey = searchKey;
  }
  // Get updated fields of material search
  getRequestedSearchFields(reqObj: any, newKey: any, newValue: any): void {
    if (!newKey.includes('Condition')) {
      const obj = {
        fieldName: '',
        operator: '',
        value: ''
      };
      obj.value = newValue[newKey];
      obj.operator = newValue[newKey + 'Condition'];
      obj.fieldName = newKey;
      reqObj.searchFields.push(obj);
    }
  }
  /**
   * To do Sreach
   */
  search(): void {
    this.compareSearchTerm(this.oldResult, this.formGroup.value);
    this.prodTrackService.callComponentMethod(this.searchKey);
    this.loader = true;
    this.prodtrackBaseService
      .searchMaterialDb(this.reqObj)
      .pipe(takeUntil(this.isActive))
      .subscribe(
        (response: any) => {
          if (response.status === 'SUCCESS') {
            this.loader = false;
            this.searchMaterialDetails = response.results;
            this.data = response.results;
            this.gridView.data = response.results;
            if (this.searchMaterialDetails === '') {
              this.notify =
                {
                  style: 'error',
                  content: 'No records found with these search criteria'
                };
            }
          } else {
            this.loader = false;
          }
        },
        (err: any) => {
          this.loader = false;
          this.notify =
            {
              style: 'error',
              content: err.statusText
            };
        }
      );
  }

  /**
   * To set all values in the form
   */
  reset(): void {
    this.gridView.data = [];
    this.gridView.total = 0;
    this.createFromGroup(
    );
  }

  /**
   * add search filter Field
   */
  save(): void {
    this.savepopup = true;
    // saving form data
  }
  /**
   * To remove added search filter
   */
  valueChange(ev: any): void {
    const index = this.searchFilters.findIndex((item: any) => item.label === ev.text);
    if (this.searchFilters[index].type === 'textWithDelete') {
      this.searchFilters[index].show = true;
      const dropDownIndex = this.dropDownFields.findIndex((x: any) => x.text === ev.text);
      this.dropDownFields[dropDownIndex].disabled = true;

    }
  }
  /**
   * To remove added search filter
   */
  removeField(index: any, field: any): void {
    this.searchFilters[index].show = false;
    const dropDownIndex = this.dropDownFields.findIndex((x: any) => x.text === field.label);
    this.dropDownFields[dropDownIndex].disabled = false;
  }
  ngOnDestroy(): void {
    this.prodTrackService.materialSearchFormState.next(true);
  }
}
