import { HttpClient } from '@angular/common/http';
import { Component, Input, OnInit, ViewEncapsulation } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { HotTableRegisterer } from '@handsontable/angular';
import { process, State } from '@progress/kendo-data-query';
import Handsontable from 'handsontable';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { empcolumnHeaders, empfieldsets } from 'src/app/modules/prodtrack-home/material-db/data';
import { ProdtrackServiceService } from '../../prodtrack-service.service';
import { ProdtrackBaseService } from '../../services/prodtrack-base.service';

@Component({
  selector: 'app-edit-material-db',
  templateUrl: './edit-material-db.component.html',
  styleUrls: ['./edit-material-db.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class EditMaterialsDbComponent implements OnInit {
  @Input() field: any;
  @Input() formGroup: FormGroup = new FormGroup({});
  @Input() conditionDropdownList: any;

  // Patching the input values
  editHandsonForm: FormGroup = new FormGroup({
    AltInd: new FormControl(''),
    Color: new FormControl(''),
    Formulator: new FormControl(''),
    MaterialType: new FormControl(''),
    MediaAmt: new FormControl(''),
    MediaUnits: new FormControl(''),
    Part: new FormControl(''),
    PartDescription: new FormControl(''),
    ParTradeName: new FormControl(''),
    Qty: new FormControl(''),
    Supplier: new FormControl(''),
    WettedArea: new FormControl(''),
    WettedAreaUnits: new FormControl(''),
    dspseq: new FormControl(''),
    inPlantMixing: new FormControl(''),
    item: new FormControl('')
  });
  searchType = 'Advanced search';
  match = 'match';
  opened = false;
  showAddField = false;
  columnHeaders: any = empcolumnHeaders;
  fieldsets: any = empfieldsets;
  fieldControls: any = {};
  dataset: any;
  gridData: any = [];
  columnHeader: any;
  columns: any;
  id = 'viewTable';
  editMaterialDetails: any;
  showStatusHistory = false;
  loadWplDetails: any;
  Add = false;
  update = false;
  Edit = false;
  title = 'Status History';
  item: any;
  handsonitem: any;
  handsonData: any;
  statusData: any;
  statusValue: any;
  selectedStatus: any;
  updatedStatusData: any;
  dataGoingtoEdit: any;
  public basicEnable = false;
  public advanceEnable = true;
  public isDialog: any = false;
  public isDialogEpsf: any = false;
  // tslint:disable-next-line:no-inferrable-types
  enable: boolean = false;
  // tslint:disable-next-line:no-inferrable-types
  addEnable: boolean = false;
  saveEditMaterialDetails: any;
  editedVolume: any;
  public loader: any;
  successmsg: any;
  clearDetails: any;
  reviewData: any;
  commandIndex: any;
  showErrorMessage: any;
  notify: any;
  actionColumnData: any;
  subcplrow = 0;
  private isActive = new Subject();
  subCplDataset: any;
  showSubCplDetails = false;
  ht = new HotTableRegisterer();
  subid = 'subcplTable';

  // Grid header
  subWplColumnHeader = [
    'Select All', 'Actions', 'Dsp Seq #', 'Item #', 'Alt Ind', 'In Plant',
    'Part DCC', 'Part Trade Name', 'Part #', 'Part Description', 'Supplier', 'Formulator',
    'Qty', 'Color', 'Material Type', 'Wetted Area(Per Part)', 'Wetted Area Units', 'Media Amt',
    'Media Units', 'Approval Status'
  ];

  subWplColumns = [
    { data: 'dirty', type: 'checkbox' },
    {
      data: 'dspSeqNbr', readOnly: true
    },
    {
      data: 'itmNum', readOnly: true
    },
    {
      data: 'altInd', readOnly: true,
    },
    { type: 'checkbox', readOnly: true },
    {
      data: 'dcc', readOnly: true
    },
    {
      data: 'tradeName', readOnly: true
    },
    {
      data: 'partNum', readOnly: true
    },
    {
      data: 'descr', readOnly: true
    },
    {
      data: 'supplier', readOnly: true
    },
    {
      data: 'formulator', readOnly: true
    },
    {
      data: 'quantity', readOnly: true,
    },
    {
      data: 'color', readOnly: true
    },
    {
      data: 'matType', readOnly: true
    },
    {
      data: 'WettedArea', readOnly: true
    },
    {
      data: 'WettedAreaUnits', readOnly: true,
    },
    {
      data: 'mediaAmt', readOnly: true,
    },
    {
      data: 'mediaUnit', readOnly: true,
    },
    { data: '', readOnly: true }
  ];
  constructor(
    private http: HttpClient, private router: Router,
    private dataservice: ProdtrackServiceService,
    private prodtrackBaseService: ProdtrackBaseService) {
  }
  public listItems: Array<string> = [];

  basic(): void {
    this.enable = !this.enable;
    this.addEnable = false;
  }
  advance(): void {
    this.enable = !this.enable;
    this.addEnable = true;
  }
  // To show delete warning popup
  public closeConfirmDialog(status: any): void {
    if (status === 'cancel' || status === 'no') {
      this.isDialog = false;
    } else {
      // this.gridData.splice()
      this.isDialog = true;
    }
  }

  ngOnInit(): void {
    const results = this.dataservice.getEditMaterialData();
    if (results === undefined) {
      this.router.navigate(['prodtrack/searchTestedMaterialDb']);
      return;
    } else {
      this.item = results.mHdr;
    }
    const status = this.item.mdb_status;

    if (status === 'APPROVED') {
      this.listItems = ['APPROVED'];
    }
    else if (status === 'DRAFT') {
      this.listItems = ['DRAFT', 'APPROVED'];
    }
    else {
      this.listItems = ['DRAFT', 'APPROVED'];
    }



    // custom handson table headers
    this.columnHeader = [
      'Select All', 'Actions', 'Dsp Seq #', 'Item #', 'Alt Ind', 'In Plant',
      'Part DCC', 'Part Trade Name', 'Part #', 'Part Description', 'Supplier', 'Formulator',
      'Qty', 'Color', 'Material Type', 'Wetted Area(Per Part)', 'Wetted Area Units', 'Media Amt',
      'Media Units', 'Approval Status'

    ];
    // this.loadTableData();
    results.mainWplDtls.forEach((element: any) => {
      if (element.excludeWithoutMedia === 'Y') {
        element.excludeWithoutMedia = true;
      } else if (element.excludeWithoutMedia === 'N') {
        element.excludeWithoutMedia = false;
      }
    });
    this.dataset = results.mainWplDtls;
    if (this.item.mdb_status === 'APPROVED') {
      this.actionColumnData = `<button id='editInline' style="cursor: pointer; color: #015A9E; border: 2px solid #015A9E; border-radius: 4px; background-color: white; width: unset; height: unset"  disabled="true" class='k-icon k-i-edit
      '></button><button id='deletePopup' (click)="del(instance, row)" class='k-icon k-i-close'></button>`;
    }
    else {
      this.actionColumnData = `<button id='addInline' style="cursor: pointer; color: #015A9E; border: 2px solid #015A9E; border-radius: 4px; background-color: white; width: unset; height: unset" disabled="true" class='k-icon k-i-plus
              '></button> <button id='copyInline' style="cursor: pointer; color: #015A9E; border: 2px solid #015A9E; border-radius: 4px; background-color: white; width: unset; height: unset" disabled="true" class="k-icon k-i-copy"></button>
               <button id='editInline' style="cursor: pointer; color: #015A9E; border: 2px solid #015A9E; border-radius: 4px; background-color: white; width: unset; height: unset"  disabled="true" class='k-icon k-i-edit
              '></button><button style="display: none; cursor: pointer; color: #015A9E; border: 2px solid #015A9E; border-radius: 4px; background-color: white; width: unset; height: unset" id='deletePopup' (click)="del(instance, row)" class='k-icon k-i-close'></button>`;
    }
    this.cplTableColumn();
  }

  // Load cpl Column data
  cplTableColumn(): any {
    this.loader = true;
    this.commandIndex = { checkbox: 0, options: 1, manageCol: true, deleteBtnIndex: 3 }; // height, width
    // custom handson table columns
    this.columns = [
      {
        renderer: (instance: any, TD: any, row: any, col: any, prop: any, value: any, cellProperties: any) => {
          TD.innerHTML = `<input type='checkbox' id='checkbox' /> `;
          return TD;
        },
        colHeaders: true, width: 80, readOnly: true
      },
      {
        class: 'newStyleFortd', width: 150,
        renderer:
          (instance: any, TD: any, row: number, col: number, prop: any, value: any, cellProperties: any) => {
            TD.innerHTML = this.actionColumnData;
            return TD;
          }
      },
      {
        data: 'dspSeqNbr', readOnly: true,
        renderer: (instance: any, TD: any, row: number, col: number, prop: any, value: any, cellProperties: any) => {
          TD.innerHTML = `<span class="alignBeforeSelection">${value ? value : ''}</span> `;
          return TD;
        }

      },
      {
        data: 'itmNum', readOnly: true,
        renderer: (instance: any, TD: any, row: number, col: number, prop: any, value: any, cellProperties: any) => {
          TD.innerHTML = `<span class="alignBeforeSelection">${value ? value : ''}</span> `;
          return TD;
        }
      },
      {
        data: 'altInd', readOnly: true,
        renderer: (instance: any, TD: any, row: number, col: number, prop: any, value: any, cellProperties: any) => {
          TD.innerHTML = `<span class="alignBeforeSelection">${value ? value : ''}</span> `;
          return TD;
        }
      },
      {
        type: 'checkbox', readOnly: true,
        renderer: (instance: any, TD: any, row: number, col: number, prop: any, value: any, cellProperties: any) => {
          TD.innerHTML = `<input type='checkbox' id='checkbox' /> `;
          return TD;
        }
      },
      {
        data: 'dcc', renderer:
          (instance: any, td: any, row: number, col: number, prop: any, value: any) => {
            let spantag = null;
            spantag = document.createElement('a');
            spantag.className = 'subwpl-link';
            const hasSubWpl = this.dataset[row].hasSubWpl;
            if (hasSubWpl === 'Y') {
              const count = this.dataset[row].numOfSubWplsSelected;
              if (count) {
                spantag.innerHTML = ' (' + count + ')';
              }
              else {
                spantag.innerHTML = ' ( ' + '0' + ' )';
              }
            }

            Handsontable.dom.addEvent(spantag, 'mousedown', event => {
              event.preventDefault();
              this.loadSubCplDetails(this.dataset[row].seq, row);
            });
            Handsontable.dom.empty(td);

            if (value === null) {
              td.innerHTML = ' ';
            } else {
              td.innerHTML = value + ' ';
            }
            td.appendChild(spantag);
            return td;
          }
      },
      {
        data: 'tradeName', readOnly: true,
        renderer: (instance: any, TD: any, row: number, col: number, prop: any, value: any, cellProperties: any) => {
          TD.innerHTML = `<span class="alignBeforeSelection">${value ? value : ''}</span> `;
          return TD;
        }
      },
      {
        data: 'partNum', readOnly: true,
        renderer: (instance: any, TD: any, row: number, col: number, prop: any, value: any, cellProperties: any) => {
          TD.innerHTML = `<span class="alignBeforeSelection">${value ? value : ''}</span> `;
          return TD;
        }
      },
      {
        data: 'descr', readOnly: true,
        renderer: (instance: any, TD: any, row: number, col: number, prop: any, value: any, cellProperties: any) => {
          TD.innerHTML = `<span class="alignBeforeSelection">${value ? value : ''}</span> `;
          return TD;
        }
      },
      {
        data: 'supplier', readOnly: true,
        renderer: (instance: any, TD: any, row: number, col: number, prop: any, value: any, cellProperties: any) => {
          TD.innerHTML = `<span class="alignBeforeSelection">${value ? value : ''}</span> `;
          return TD;
        }
      },
      {
        data: 'formulator', readOnly: true,
        renderer: (instance: any, TD: any, row: number, col: number, prop: any, value: any, cellProperties: any) => {
          TD.innerHTML = `<span class="alignBeforeSelection">${value ? value : ''}</span> `;
          return TD;
        }
      },
      {
        data: 'quantity', readOnly: true,
        renderer: (instance: any, TD: any, row: number, col: number, prop: any, value: any, cellProperties: any) => {
          TD.innerHTML = `<span class="alignBeforeSelection">${value ? value : ''}</span> `;
          return TD;
        }
      },
      {
        data: 'color', readOnly: true,
        renderer: (instance: any, TD: any, row: number, col: number, prop: any, value: any, cellProperties: any) => {
          TD.innerHTML = `<span class="alignBeforeSelection">${value ? value : ''}</span> `;
          return TD;
        }
      },
      {
        data: 'matType', readOnly: true,
        renderer: (instance: any, TD: any, row: number, col: number, prop: any, value: any, cellProperties: any) => {
          TD.innerHTML = `<span class="alignBeforeSelection">${value ? value : ''}</span> `;
          return TD;
        }
      },
      {
        data: 'WettedArea', readOnly: true,
        renderer: (instance: any, TD: any, row: number, col: number, prop: any, value: any, cellProperties: any) => {
          TD.innerHTML = `<span class="alignBeforeSelection">${value ? value : ''}</span> `;
          return TD;
        }
      },
      {
        data: 'WettedAreaUnits', readOnly: true,
        renderer: (instance: any, TD: any, row: number, col: number, prop: any, value: any, cellProperties: any) => {
          TD.innerHTML = `<span class="alignBeforeSelection">${value ? value : ''}</span> `;
          return TD;
        }
      },
      {
        data: 'mediaAmt', readOnly: true,
        renderer: (instance: any, TD: any, row: number, col: number, prop: any, value: any, cellProperties: any) => {
          TD.innerHTML = `<span class="alignBeforeSelection">${value ? value : ''}</span> `;
          return TD;
        }
      },
      {
        data: 'mediaUnit', readOnly: true,
        renderer: (instance: any, TD: any, row: number, col: number, prop: any, value: any, cellProperties: any) => {
          TD.innerHTML = `<span class="alignBeforeSelection">${value ? value : ''}</span> `;
          return TD;
        }
      },
      {
        data: '', readOnly: true,
        renderer:
          (instance: any, TD: any, row: number, col: number, prop: any, value: any, cellProperties: any) => {
            TD.innerHTML = `<div><input type="radio" value="true" kendoRadioButton />Yes<input type="radio" kendoRadioButton />No</div>`;
            return TD;
          }
      }
    ];
    if (this.item.test_type === 'Both') {
      this.columns.push(
        {
          data: 'excludeWithoutMedia', type: 'checkbox'
        }
      );
      this.columnHeader.push('Exclude for Without Media');
    }
    this.loader = false;
  }

  // For Changing the event from status history popup
  dataStateChange(state: State): void {
    this.gridData = process(this.updatedStatusData, state).data;
  }

  /**
   * To open dialog box
   */
  dialogOpen(): void {
    this.opened = true;
  }

  /**
   * To open close box
   */
  dialogClose(): void {
    this.opened = false;
  }

  // rendering the add and edit actions for handson Table
  getInstance(data: any): void {
    if (data[0] === 'editOpened') {
      this.dataGoingtoEdit = data[1];
      this.editHandsonForm.patchValue(this.dataGoingtoEdit[0]);
      this.Edit = true;
      this.title = 'Duplicate';
    } else if (data === 'addOpened') {
      this.Add = true;
      this.title = 'Add';
    } else if (data[0] === 'dltOpened') {
      this.isDialog = true;
      this.update = true;
      this.title = 'Add';
    }

  }
  // closing the popup
  dialogOnclose(data: any): void {
    this.showStatusHistory = false;
    this.Add = false;
    this.Edit = false;
  }
  // Saving the material db details
  onSave(): any {
    this.loader = true;
    let reqObj: object;
    reqObj = {
      epsfId: this.item.epsf_id, // 'J-00093812'
      mHdr: {
        seq: this.item.seq,
        epsf_id: this.item.epsf_id,
        dcc: this.item.dcc,
        code: this.item.code,
        cus_name: this.item.cus_name,
        trade_name: this.item.trade_name,
        use_type: this.item.use_type,
        test_type: this.item.test_type,
        test_date: this.item.test_date,
        expiry_date: this.item.expiry_date,
        volume: this.item.volume,
        Reviewer_emp_no: this.item.Reviewer_emp_no,
        qc_name: this.item.qc_name,
        mdb_status: this.item.mdb_status,
        status_change_reason: this.item.status_change_reason ? this.item.status_change_reason : '',
        group_code: this.item.group_code,
        modify_user: this.item.modify_user,
        modify_date: this.item.modify_date
      },
      mainWplDtls: this.dataset
    };
    this.prodtrackBaseService.saveEditMaterialDbInfo(reqObj).subscribe((response: any) => {
      if (response.status === 'SUCCESS') {
        this.saveEditMaterialDetails = response;
        this.successmsg = 'Material Details Saved Successfully';
      }
      this.loader = false;
    });
  }

  // Close confirmation pop up
  closeConfirmDialogEspf(value: any): void {
    if (value === 'Yes') {
      this.removeEpsf();
    }
    this.isDialogEpsf = false;

  }
  // Clear epsf
  onClear(): any {

    this.isDialogEpsf = true;

  }

  // To clear all data
  removeEpsf(): void {
    this.item.volume = '';
    this.listItems[0] = '';
    this.loader = true;
    let reqObj: object;
    reqObj = {
      epsfId: this.item.epsf_id,
    };
    this.prodtrackBaseService.clearEditMaterialDbInfo(reqObj).subscribe((response: any) => {
      if (response.status === 'SUCCESS') {
        this.clearDetails = response;
        this.notify = {
          content: 'Material Details Cleared Successfully',
          style: 'success'
        };
        this.router.navigate(['prodtrack/addtestedmaterialdb']);
      } else {
        this.notify = {
          content: response.results[0].message,
          style: 'error'
        };

      }
      this.loader = false;
    });
  }
  // handling volume input data
  onVolumeChange(data: any): void {
    if (data === '' || data === undefined || data === null) {
      this.showErrorMessage = 'Please enter volume';
    } else {
      this.showErrorMessage = undefined;
    }
  }

  loadSubCplDetails(seqNumber: number, row: number): void {
    this.subcplrow = row;
    this.notify = false;
    this.loader = true;
    // replace seqNumber once service changes done
    const req = { flag: 'edit', seq: seqNumber, epsfid: 'A-00336217' };
    // const req = {flag: '', seq : '2305550', epsfid: 'J-00074796'};
    // Load CPL Data Grid
    this.prodtrackBaseService
      .loadSubWpl(req)
      .pipe(takeUntil(this.isActive))
      .subscribe(
        (response: any) => {
          this.loader = false;
          if (response.status === 'SUCCESS') {
            this.subCplDataset = response.results.subWplDtls;
            this.showSubCplDetails = true;
          } else {
            this.loader = false;
            this.notify = {
              content: response.results[0].message,
              style: 'error'
            };
          }
        },
        (): any => {
          this.loader = false;
          alert('Update: API Error');
        }
      );
  }

  // Done selecting
  doneSelecting(): void {
    const count = this.subCplDataset.filter((data: any) => data.dirty === true).length;
    this.dataset[this.subcplrow].numOfSubWplsSelected = count;
    this.showSubCplDetails = false;
    this.ht.getInstance(this.id).render();
  }
  // To cancel Subwpl Selecting
  cancelSubwplSelecting(): void {
    this.showSubCplDetails = false;
  }
}
