export const dropDownFields = [
  { text: 'Epsf #', disabled: true, checked: true },
  { text: 'Primary(Tested) DCC', disabled: true },
  { text: 'City', disabled: false },
  { text: 'Test Type', disabled: true },
  { text: 'Emp #', disabled: false },
  { text: 'User Type', disabled: true },
  { text: 'Part #', disabled: true },
  { text: 'Corporate(Tested) DCC', disabled: true },
  { text: 'Trade Name', disabled: true },
  { text: 'Emp Name', disabled: false },
  { text: 'Super Corporate', disabled: true },
  { text: 'Supplier', disabled: true }
];
export const empDropDownFields = [
  { text: 'City', disabled: true },
  { text: 'Emp #', disabled: true },
  { text: 'Emp Name', disabled: true },
];
export const searchFilters = [
  {
    label: 'EPSF ID',
    type: 'text',
    value: '',
    name: 'epsfId',
    conditionName: 'epsfIdCondition',
    conditionValue: 'LIKE',
    show: true
  },
  {
    label: 'Use Type',
    type: 'text',
    value: '',
    name: 'useType',
    conditionName: 'useTypeCondition',
    conditionValue: 'IN',
    show: true
  },
  {
    label: 'DCC Number',
    type: 'text',
    value: '',
    name: 'primaryDcc',
    conditionName: 'primaryDccCondition',
    conditionValue: 'LIKE',
    show: true
  },
  {
    label: 'Corporate # (Tested)',
    type: 'text',
    value: '',
    name: 'corporateTested',
    conditionName: 'corporateTestedCondition',
    conditionValue: 'LIKE',
    show: true
  },
  {
    label: 'Supporting DCC #',
    type: 'text',
    value: '',
    name: 'supportingDcc',
    conditionName: 'supportingDccCondition',
    conditionValue: 'LIKE',
    show: true
  },
  {
    label: 'Corporate Name (Tested)',
    type: 'text',
    value: '',
    name: 'corporateTestedName',
    conditionName: 'corporateTestedNameCondition',
    conditionValue: 'LIKE',
    show: true
  },
  {
    label: 'Status',
    type: 'multiSelect',
    Value: '',
    values: [
      {
        descr: 'All',
        id: 1,
        items: [
          { descr: 'CREATED', id: 2 },
          { descr: 'DRAFT', id: 3 },
          { descr: 'APPROVED', id: 4 },
        ],
      }],
    name: 'status',
    conditionName: 'epsfCondition',
    conditionValue: 'IN',
    show: true
  },
  {
    label: 'EPSF Plant #',
    type: 'text',
    value: '',
    name: 'epsfPlant',
    conditionName: 'epsfPlantCondition',
    conditionValue: 'LIKE',
    show: true
  },
  {
    label: 'Trade Name',
    type: 'text',
    value: '',
    name: 'tradeName',
    conditionName: 'tradeNameCondition',
    conditionValue: 'LIKE',
    show: true
  },
  {
    label: 'Super Corporate #',
    type: 'text',
    value: '',
    name: 'superCorporate',
    conditionName: 'superCorporateCondition',
    conditionValue: 'LIKE',
    show: true
  },
  {
    label: 'Supplier',
    type: 'text',
    value: '',
    name: 'supplier',
    conditionName: 'supplierCondition',
    conditionValue: 'LIKE',
    show: true
  },
  {
    label: 'Part #',
    type: 'text',
    value: '',
    name: 'partNumber',
    conditionName: 'partNumberCondition',
    conditionValue: 'LIKE',
    show: true
  },
  {
    label: 'Tested Type',
    type: 'text',
    value: '',
    name: 'testType',
    conditionName: 'testTypeCondition',
    conditionValue: 'IN',
    show: true
  },
  {
    label: 'City',
    type: 'textWithDelete',
    value: '',
    name: 'city',
    conditionName: 'cityCondition',
    conditionValue: 'LIKE',
    show: false
  },
  {
    label: 'Emp #',
    type: 'textWithDelete',
    value: '',
    name: 'empNo',
    conditionName: 'empCondition',
    conditionValue: 'LIKE',
    show: false
  },
  {
    label: 'Emp Name',
    type: 'textWithDelete',
    value: '',
    name: 'empName',
    conditionName: 'empNameCondition',
    conditionValue: 'LIKE',
    show: false
  },
];

export const empcolumnHeaders = [
  {
    header_title: 'Emp Name',
    width: 150,
    type: 'input_text',
    field: 'name'
  },
  {
    header_title: 'Emp #',
    width: 150,
    type: 'input_text',
    field: 'empNo'
  }];
export const empData = [{ name: 'bala', empNo: '10' }, { name: 'chan', empNo: '11' }];
export const empfieldsets = [
  {
    label: 'Emp #',
    type: 'text',
    value: '',
    name: 'empNoLookup',
    conditionName: 'empfCondition',
    conditionValue: 'LIKE'
  },
  {
    label: 'EmpName',
    type: 'text',
    value: '',
    name: 'empNameLookup',
    conditionName: 'empNameCondition',
    conditionValue: 'LIKE'
  },
  {
    label: 'City',
    type: 'text',
    value: '',
    name: 'cityLookup',
    conditionName: 'cityCondition',
    conditionValue: 'LIKE'
  },
];


export const gridData = [
  {
    id: '1', options: '1001', epsfId: '207701-TR02', mdb_status: 'created',
    // tslint:disable-next-line:max-line-length
    primaryDcc: '	PW07457', dcc_1: '4Q920 - 4Q920', useType: 'Point of', testType: 'Without Media', testDate: '12/22/2020', SupportingDCC: ''
    , tradeName: '', Part: '', PartDescription: '', SAV: '', Unit: '', MassVgL: ''
  },
  {
    id: '2', options: '1001', epsfId: '207701-TR02', mdb_status: 'created',
    // tslint:disable-next-line:max-line-length
    primaryDcc: '	PW07457', dcc_1: '4Q920 - 4Q920', useType: 'Point of', testType: 'Without Media', testDate: '12/22/2020', SupportingDCC: ''
    , tradeName: '', Part: '', PartDescription: '', SAV: '', Unit: '', MassVgL: ''
  },
  {
    id: '3', options: '1001', epsfId: '207701-TR02', mdb_status: 'created',
    // tslint:disable-next-line:max-line-length
    primaryDcc: '	PW07457', dcc_1: '4Q920 - 4Q920', useType: 'Point of', testType: 'Without Media', testDate: '12/22/2020', SupportingDCC: ''
    , tradeName: '', Part: '', PartDescription: '', SAV: '', Unit: '', MassVgL: ''
  },
  {
    id: '4', options: '1001', epsfId: '207701-TR02', mdb_status: 'created',
    // tslint:disable-next-line:max-line-length
    primaryDcc: '	PW07457', dcc_1: '4Q920 - 4Q920', useType: 'Point of', testType: 'Without Media', testDate: '12/22/2020', SupportingDCC: ''
    , tradeName: '', Part: '', PartDescription: '', SAV: '', Unit: '', MassVgL: ''
  },

];

export const conditionDropdownListData = [
  { text: 'Like', value: 'LIKE' },
  { text: 'Equals', value: 'EQUALS' },
  { text: 'Not Equals', value: 'NOT_EQUALS' },
  { text: 'Is Blank', value: 'IS_BLANK' },
  { text: 'Is Not Blank', value: 'IS_NOT_BLANK' },
  { text: 'Starts with', value: 'STARTS_WITH' },
  { text: 'Ends with', value: 'ENDS_WITH' },
  { text: 'Contains', value: 'CONTAINS' },
  { text: 'Does not Contains', value: 'DOES_NOT_CONTAIN' },
  { text: 'In', value: 'IN' },
];
