import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddMaterialDBComponent } from './add-material-db.component';

describe('AddMaterialDBComponent', () => {
  let component: AddMaterialDBComponent;
  let fixture: ComponentFixture<AddMaterialDBComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddMaterialDBComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddMaterialDBComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
