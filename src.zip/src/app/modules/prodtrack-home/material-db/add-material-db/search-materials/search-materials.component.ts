import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ProdtrackServiceService } from '../../../prodtrack-service.service';
import { ProdtrackBaseService } from '../../../services/prodtrack-base.service';

@Component({
  selector: 'app-search-materials',
  templateUrl: './search-materials.component.html',
  styleUrls: ['./search-materials.component.scss']
})
export class SearchMaterialsComponent {

  searchEPSFID = '';
  dataList: any;
  fieldControls: any = {};
  dataset: any;
  gridData: any;
  columnHeader: any;
  columns: any;
  id = 'viewTable';
  inputSearch: any;
  tableData: any;
  enablebutton = true;
  addMaterialDbInfo: any;
  errormsg: any;
  errormessage = false;
  public loader: any;
  iconvisible = false;
  errorIconvisible = false;
  invalidEpsfId = false;



  constructor(private router: Router, private prodtrackBaseService: ProdtrackBaseService, private dataservice: ProdtrackServiceService) { }


  // search button click
  addMaterial(): void {
    this.loader = true;
    const req = {
      epsfId: this.searchEPSFID
    };
    this.prodtrackBaseService.addMateriaDb(req).subscribe((response: any) => {
      this.errormessage = false;
      if (response.status === 'SUCCESS') {
        this.addMaterialDbInfo = response.results;
        this.dataservice.setEditMaterialData(this.addMaterialDbInfo);
        if (response.results.screenType === 'ADD') {
          this.router.navigate(['prodtrack/addtestedmaterialdb']);
        } else if (response.results.screenType === 'EDIT') {
          this.router.navigate(['prodtrack/editTestedMaterialDb']);
        } else {
          this.errorIconvisible = true;
          this.iconvisible = false;
          this.errormessage = true;
          this.errormsg = 'Please enter a valid EPSF ID';
          this.invalidEpsfId = true;
          this.loader = false;
        }
        this.loader = false;
      } else if (response.status === 'ERROR' || response.status === 'FAILURE') {
        this.errormessage = true;
        this.errormsg = 'Please enter a valid EPSF ID';
        this.loader = false;
      }
    });
  }
  // to search perticular epsf id from handsonTable
  key(event: any): void {
    if (event.target.value) {
      this.enablebutton = false;
      this.iconvisible = true;
      this.errorIconvisible = false;
      this.errormessage = false;
      this.invalidEpsfId = false;
    } else {
      this.enablebutton = true;
      this.iconvisible = false;
      this.invalidEpsfId = true;
    }
    this.inputSearch = event.target.value;
  }

  // Auto capitalizing the first letter in entering the EPSF Id
  forceUppercaseConditionally(event: any): any {
    const first = event.target.value.substr(0, 1).toUpperCase();
    const finalValue = first + event.target.value.substr(1);
    this.searchEPSFID = finalValue;
  }


}
