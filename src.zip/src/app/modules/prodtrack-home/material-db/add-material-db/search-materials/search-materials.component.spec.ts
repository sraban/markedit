import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchMaterialsComponent } from './search-materials.component';

describe('SearchMaterialsComponent', () => {
  let component: SearchMaterialsComponent;
  let fixture: ComponentFixture<SearchMaterialsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SearchMaterialsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchMaterialsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
