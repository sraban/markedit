import { Component, ElementRef, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { ProdtrackBaseService } from '../../services/prodtrack-base.service';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { FormatSettings } from '@progress/kendo-angular-dateinputs';
import { DatePipe } from '@angular/common';
import { Router } from '@angular/router';
import Handsontable from 'handsontable';
import { HotTableRegisterer } from '@handsontable/angular';
import { ProdtrackServiceService } from '../../prodtrack-service.service';


@Component({
  selector: 'app-add-material-db',
  templateUrl: './add-material-db.component.html',
  styleUrls: ['./add-material-db.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class AddMaterialDBComponent implements OnInit {
  espfId: any;
  private isActive = new Subject();
  ht = new HotTableRegisterer();
  addMaterialFormGroup !: FormGroup;
  cplDataset: any;
  showCplDetails = false;
  subCplDataset: any;
  showSubCplDetails = false;
  showCplButton = false;
  showClearButton = false;
  showSaveButton = false;
  [x: string]: any;
  id = 'addTable';
  subid = 'subcplTable';
  notify: any;
  tableNotify: any;
  loader = false;
  subcplrow = 0;
  public format: FormatSettings = {
    displayFormat: 'MM/dd/yyyy',
    inputFormat: 'MM/dd/yyyy',
  };
  public max: Date = new Date();
  public maximum: any = '3';
  public min: Date = new Date('01/01/2000');
  commandIndex: any;
  readonly = false;
  opened = false;
  tradeDialogOpen = false;
  tradeTitle = 'Select Trade Name';
  functionLookUpGridData = false;
  public pageable = {
    pageable: {
      position: 'both',
    },
    pageSize: 5,
  };

  tradeNameHeader: any;
  tradeNameData: any = [];
  tradeDialogWidth = 600;
  tradeDialogHeight = 350;
  newTradeNameSelection: any;
  selectedRow!: number;
  selectedColumn!: number;

  cancelTitle = 'Cancel Add Tested Material';
  @ViewChild('userTypeError') userTypeError!: ElementRef;
  @ViewChild('testTypeError') testTypeError!: ElementRef;
  // Grid header
  columnHeader = [
    'Select', 'Actions', 'Dsp Seq #', 'Item #', 'Alt Ind', 'In Plant',
    'Part DCC', 'Part Trade Name', 'Part #', 'Part_Description_#', 'Supplier', 'Formulator',
    'Qty', 'Color', 'Material_Type', 'Wetted_Area_(Per Part)', 'Wetted_Area_Units', 'Media_Amt',
    'Media_Units', 'Approval Status'
  ];

  // Grid header
  subWplColumnHeader = [
    'Options', 'Dsp Seq #', 'Item #', 'Alt Ind', 'In Plant', 'Part DCC', 'Part Trade Name',
    'Part #', 'Part_Description_#', 'Supplier', 'Formulator', 'Qty', 'Color', 'Material_Type',
    'Wetted_Area_(Per Part)', 'Wetted_Area_Units', 'Media_Amt', 'Media_Units'
  ];
  columns: any;

  subWplColumns = [
    { data: 'dirty', type: 'checkbox' },
    { data: 'dspSeqNbr', readOnly: true },
    { data: 'itmNum', readOnly: true },
    { data: 'altInd', readOnly: true },
    { data: 'inPlant', readOnly: true },
    { data: 'dcc', readOnly: true },
    { data: 'tradeName', readOnly: true },
    { data: 'partNum', readOnly: true },
    { data: 'descr', readOnly: true },
    { data: 'supplier', readOnly: true },
    { data: 'formulator', readOnly: true },
    { data: 'quantity', type: 'numeric' },
    { data: 'Color', readOnly: true },
    { data: 'matType', readOnly: true },
    {
      data: 'areaAmt', type: 'numeric',
      renderer: (instance: any, TD: any, row: number, col: number, prop: any, value: any) => {
        TD.innerHTML = `<span class="alignBeforeSelection">${value ? value : ''}</span> `;
        return TD;
      }
    },
    {
      data: 'areaUnit', type: 'dropdown',
      source: ['NW', 'SQCM', 'SQFT', 'SQIN', 'SQM', 'SQMM', 'UNIT(S)'],
      renderer: (instance: any, TD: any, row: number, col: number, prop: any, value: any) => {
        TD.innerHTML = `<span class="alignBeforeSelection">${value ? value : ''}</span> `;
        return TD;
      }
    },
    {
      data: 'mediaAmt', type: 'numeric',
      renderer: (instance: any, TD: any, row: number, col: number, prop: any, value: any) => {
        TD.innerHTML = `<span class="alignBeforeSelection">${value ? value : ''}</span> `;
        return TD;
      }
    },
    {
      data: 'mediaUnit', type: 'dropdown', source: ['CU_CM', 'CU_FT', 'GRAMS'],
      renderer: (instance: any, TD: any, row: number, col: number, prop: any, value: any) => {
        TD.innerHTML = `<span class="alignBeforeSelection">${value ? value : ''}</span> `;
        return TD;
      }
    },
    {
      renderer:
        (instance: any, TD: any, row: number, col: number, prop: any, value: any, cellProperties: any) => {
          TD.innerHTML = `<div><input type="radio" value="true" kendoRadioButton />Yes<input type="radio" kendoRadioButton />No</div>`;
          return TD;
        }
    }
  ];

  // dropdownList
  public statusList: Array<string> = ['Draft'];

  // add service data
  addTestedMaterial = {
    espfId: '',
    testDate: '',
    expiryDate: '',
    dcc: '',
    coCustomer: '',
    primaryDCCTradeName: '',
    userType: '',
    testType: '',
    volume: '',
    trade_designation: '',
    status: '',

    seq: '',
    code: '',


    status_change_reason: '',
    group_code: '',
    // dccSeq: '2202236'
    dccSeq: '2332172'

  };
  setter = false;

  constructor(
    private router: Router,
    private prodtrackBaseService: ProdtrackBaseService,
    private formBuilder: FormBuilder,
    private dataservice: ProdtrackServiceService,
    private datePipe: DatePipe) {
  }

  ngOnInit(): void {
    const results = this.dataservice.getEditMaterialData();
    this.addTestedMaterial.espfId = results.epsfId;
    this.addTestedMaterial.testDate = results.mHdr.test_date;
    this.addTestedMaterial.expiryDate = results.mHdr.expiry_date;
    this.addMaterialFormGroup = this.formBuilder.group({
      testDate: new FormControl(new Date(this.addTestedMaterial.testDate), [Validators.required]),
      dcc: new FormControl(''),
      userType: new FormControl('', [Validators.required]),
      testType: new FormControl('', [Validators.required]),
      volume: new FormControl('', [Validators.required]),
      status: new FormControl('Draft')
    });
    this.tradeNameHeader = [
      {
        field: 'dspSeqNbr',
        header_title: 'Display Seq No.',
        width: 50,
        type: 'input_text',
      },
      {
        field: 'tradeName',
        header_title: 'Trade Name',
        width: 100,
        type: 'input_text',
      },
    ];

  }
  // To close dialog box
  dialogClose(): void {
    this.showSubCplDetails = false;
  }

  // Done selecting
  doneSelecting(): void {
    const count = this.subCplDataset.filter((data: any) => data.dirty === true).length;
    this.cplDataset[this.subcplrow].numOfSubWplsSelected = count;
    this.showSubCplDetails = false;
    this.ht.getInstance(this.id).render();
  }
  // To cancel popup
  cancelAddMaterial(): void {
    this.opened = true;
    // this.router.navigate(['prodtrack/addtestedmaterials']);
  }
  // Cancel Confirm Popup
  confirmPopup(ev: any): any {
    if (ev === true) {
      this.opened = false;
      this.router.navigate(['prodtrack/addtestedmaterials']);
    } else {
      this.opened = false;
    }
  }

  // To cancel Subwpl Selecting
  cancelSubwplSelecting(): void {
    this.showSubCplDetails = false;
  }
  // search Dcc
  dccSearch(event: any): void {
    if (event.code === 'Enter' || event.keyCode === 9) {
      const req = { dcc: this.addMaterialFormGroup.get('dcc')?.value };
      this.loader = true;
      this.prodtrackBaseService
        .dccSearch(req)
        .pipe(takeUntil(this.isActive))
        .subscribe(
          (response: any) => {
            this.loader = false;
            if (response.status === 'SUCCESS') {
              this.addTestedMaterial.coCustomer = response.results.cus_name;
              this.addTestedMaterial.primaryDCCTradeName = response.results.trade_name;
              this.addTestedMaterial.group_code = response.results.group_code;
              this.showCplButton = true;
            } else {
              this.notify = {
                content: 'Please enter a valid DCC Number',
                style: 'error'
              };
            }
          },
          (): any => {
            this.loader = false;
            alert('Update: API Error');
          }
        );
    }

  }
  // onchange of test date
  onChangeTestDate(value: Date): void {

    const eDate = new Date(value.getFullYear() + 5, 11, 31);
    if (eDate > new Date()) {
      this.notify = {
        content: 'Enter a Valid Date',
        style: 'error'
      };
    } else {
      const expireDate = this.datePipe.transform(eDate, 'MM/dd/yyyy');
      this.addTestedMaterial.expiryDate = expireDate ? expireDate : '';
    }

  }

  // showing wpl details in table onclicking load wpl button
  loadCplDetails(): void {
    this.notify = false;
    this.submitted = true;
    this.addMaterialFormGroup.markAllAsTouched();
    if (this.addMaterialFormGroup.valid) {
      const requestdata = this.addMaterialFormGroup.value;
      const req = {
        epsfId: this.addTestedMaterial.espfId,
        mHdr: {
          epsf_id: this.addTestedMaterial.espfId,
          volume: requestdata.volume,
          dcc: requestdata.dcc,
          use_type: requestdata.userType,
          test_date: this.datePipe.transform(requestdata.testDate, 'MM/dd/yyyy'),
          expiry_date: this.addTestedMaterial.expiryDate,
          test_type: requestdata.testType,
          status_change_reason: this.addTestedMaterial.status_change_reason,
          group_code: this.addTestedMaterial.group_code,
          dccSeq: this.addTestedMaterial.dccSeq
        }
      };
      this.loader = true;
      // Load CPL Data Grid
      this.prodtrackBaseService
        .loadWpl(req)
        .pipe(takeUntil(this.isActive))
        .subscribe(
          (response: any) => {
            this.loader = false;
            if (response.status === 'SUCCESS') {
              this.columns = [
                {
                  renderer: (instance: any, TD: any, row: any, col: any, prop: any, value: any, cellProperties: any) => {
                    TD.innerHTML = `<input type='checkbox' id='checkbox' /> `;
                    return TD;
                  },
                  colHeaders: true, title: 'Select', width: 50, readOnly: true
                },
                {
                  class: 'newStyleFortd', width: 180,
                  renderer: (instance: any, TD: any, row: number, col: number, prop: any, value: any, cellProperties: any) => {
                    TD.innerHTML = `<button id='addInline'  disabled="true" class='k-icon k-i-plus
                      '></button> <button id='copyInline'  disabled="true" class="k-icon k-i-copy"></button>
                       <button id='editInline'   disabled="true" class='k-icon k-i-edit
                      '></button><button style="display: none;" id='deletePopup' (click)="del(instance, row)" class='k-icon k-i-close'></button>`;
                    return TD;
                  }

                },
                {
                  data: 'dspSeqNbr', readonly: true,
                  renderer: (instance: any, TD: any, row: number, col: number, prop: any, value: any) => {
                    TD.innerHTML = `<span class="alignBeforeSelection">${value ? value : ''}</span> `;
                    return TD;
                  }
                },
                {
                  data: 'itmNum',
                  renderer: (instance: any, TD: any, row: number, col: number, prop: any, value: any) => {
                    TD.innerHTML = `<span class="alignBeforeSelection">${value ? value : ''}</span> `;
                    return TD;
                  }
                },
                {
                  data: 'altInd', readOnly: true,
                  renderer: (instance: any, TD: any, row: number, col: number, prop: any, value: any) => {
                    TD.innerHTML = `<span class="alignBeforeSelection">${value ? value : ''}</span> `;
                    return TD;
                  }
                },
                {
                  data: 'inPlant', type: 'checkbox',
                  renderer: (instance: any, TD: any, row: any, col: any, prop: any, value: any, cellProperties: any) => {
                    TD.innerHTML = `<input type='checkbox' id='checkbox' /> `;
                    return TD;
                  },
                },
                {
                  data: 'dcc',
                  renderer:
                    (instance: any, td: any, row: number, col: number, prop: any, value: any) => {
                      let spantag = null;
                      spantag = document.createElement('a');
                      spantag.className = 'subwpl-link';
                      const hasSubWpl = response.results.mainWplDtls[row].hasSubWpl;
                      if (hasSubWpl === 'Y') {
                        const count = response.results.mainWplDtls[row].numOfSubWplsSelected;
                        if (count) {
                          spantag.innerHTML = ' (' + count + ')';
                        }
                        else {
                          spantag.innerHTML = ' ( ' + '0' + ' )';
                        }
                      }

                      Handsontable.dom.addEvent(spantag, 'mousedown', event => {
                        event.preventDefault();
                        this.loadSubCplDetails(response.results.mainWplDtls[row].seq, row);
                      });
                      Handsontable.dom.empty(td);

                      if (value === null) {
                        td.innerHTML = ' ';
                      } else {
                        td.innerHTML = `<span class="alignBeforeSelection getDccValue" >${value ? value : ''} </span>`;
                      }
                      td.appendChild(spantag);
                      return td;
                    }
                },
                {
                  data: 'tradeName', readOnly: true,
                  renderer: (instance: any, TD: any, row: number, col: number, prop: any, value: any) => {
                    let spantag = null;
                    spantag = document.createElement('div');
                    spantag.className = 'k-icon k-i-zoom';

                    Handsontable.dom.addEvent(spantag, 'mousedown', event => {
                      event.preventDefault();
                      this.openTradeDialog(event, row, col);
                    });
                    Handsontable.dom.empty(TD);

                    if (value === null) {
                      TD.innerHTML = ' ';
                    } else {
                      TD.innerHTML = `<span class="alignBeforeSelection getDccValue" >${value ? value : ''} </span>`;
                    }
                    TD.appendChild(spantag);
                    return TD;
                  }
                },
                {
                  data: 'partNum', readOnly: true,
                  renderer: (instance: any, TD: any, row: number, col: number, prop: any, value: any) => {
                    TD.innerHTML = `<span class="alignBeforeSelection">${value ? value : ''}</span> `;
                    return TD;
                  }
                },
                {
                  data: 'descr', readOnly: true,
                  renderer: (instance: any, TD: any, row: number, col: number, prop: any, value: any) => {
                    TD.innerHTML = `<span class="alignBeforeSelection">${value ? value : ''}</span> `;
                    return TD;
                  }
                },
                {
                  data: 'supplier', readOnly: true,
                  renderer: (instance: any, TD: any, row: number, col: number, prop: any, value: any) => {
                    TD.innerHTML = `<span class="alignBeforeSelection">${value ? value : ''}</span> `;
                    return TD;
                  }
                },
                {
                  data: 'formulator', readOnly: true,
                  renderer: (instance: any, TD: any, row: number, col: number, prop: any, value: any) => {
                    TD.innerHTML = `<span class="alignBeforeSelection">${value ? value : ''}</span> `;
                    return TD;
                  }
                },
                {
                  data: 'quantity', type: 'numeric', validator: (value: any, callback: any): any => {
                    setTimeout(() => {
                      if (/^[0-9]$/.test(value)) {
                        callback(true);
                      } else {
                        callback(false);
                        this.tableNotify = {
                          content: 'Quantity should be a number',
                          style: 'error'
                        };
                      }
                    }, 1000);
                  },
                  allowInvalid: true,
                  renderer: (instance: any, TD: any, row: number, col: number, prop: any, value: any, cellProperties: any) => {
                    TD.innerHTML = `<span class="alignBeforeSelection" (click)="getValue()">${value ? value : ''}</span> `;
                    return TD;
                  }
                },
                {
                  data: 'Color', readOnly: true,
                  renderer: (instance: any, TD: any, row: number, col: number, prop: any, value: any) => {
                    TD.innerHTML = `<span class="alignBeforeSelection">${value ? value : ''}</span> `;
                    return TD;
                  }
                },
                {
                  data: 'matType', readOnly: true,
                  renderer: (instance: any, TD: any, row: number, col: number, prop: any, value: any) => {
                    TD.innerHTML = `<span class="alignBeforeSelection">${value ? value : ''}</span> `;
                    return TD;
                  }
                },
                {
                  data: 'areaAmt', type: 'numeric',
                  renderer: (instance: any, TD: any, row: number, col: number, prop: any, value: any) => {
                    TD.innerHTML = `<span class="alignBeforeSelection">${value ? value : ''}</span> `;
                    return TD;
                  }
                },
                {
                  data: 'areaUnit', type: 'dropdown',
                  source: ['NW', 'SQCM', 'SQFT', 'SQIN', 'SQM', 'SQMM', 'UNIT(S)'],
                  renderer: (instance: any, TD: any, row: number, col: number, prop: any, value: any) => {
                    TD.innerHTML = `<span class="alignBeforeSelection">${value ? value : ''}</span> `;
                    return TD;
                  }
                },
                {
                  data: 'mediaAmt', type: 'numeric', readOnly: true,
                  renderer: (instance: any, TD: any, row: number, col: number, prop: any, value: any) => {
                    TD.innerHTML = `<span class="alignBeforeSelection">${value ? value : ''}</span> `;
                    return TD;
                  }
                },
                {
                  data: 'mediaUnit', type: 'dropdown', source: ['CU_CM', 'CU_FT', 'GRAMS'],
                  renderer: (instance: any, TD: any, row: number, col: number, prop: any, value: any) => {
                    TD.innerHTML = `<span class="alignBeforeSelection">${value ? value : ''}</span> `;
                    return TD;
                  }
                },
                {
                  renderer:
                    (instance: any, TD: any, row: number, col: number, prop: any, value: any, cellProperties: any) => {
                      TD.innerHTML = `<div><input type="radio" value="true" kendoRadioButton />Yes<input type="radio" kendoRadioButton />No</div>`;
                      return TD;
                    }
                }
              ];
              if (response.results.mHdr.test_type === 'Both') {
                this.columns.push(
                  {
                    data: 'excludeWithoutMedia', type: 'checkbox',
                    renderer:
                      (instance: any, TD: any, row: number, col: number, prop: any, value: any, cellProperties: any) => {
                        TD.innerHTML = `<input type='checkbox' id='checkbox' /> `;
                        return TD;
                      }
                  }
                );
                this.columnHeader.push('Exclude for Without Media');
              }
              this.commandIndex = { checkbox: 0, options: 1, manageCol: true, deleteBtnIndex: 3, specificCol: [6] };
              this.showSaveButton = true;
              this.cplDataset = response.results.mainWplDtls;
              this.showCplDetails = true;
              this.showCplButton = false;
            } else {
              this.notify = {
                content: response.results[0].message,
                style: 'error'
              };
            }
          },
          (): any => {
            this.loader = false;
            alert('Update: API Error');
          }
        );
    } else {
      this.notify = {
        content: 'Please fill all mandatory fields',
        style: 'error'
      };
    }

  }

  getCellValue(data: any): void {
    this.getTradeNames(data);
  }
  getTradeNames(tradeValues: any): any {
    const req = { dcc: tradeValues[0] };
    this.prodtrackBaseService
      .getTradeNames(req)
      .pipe(takeUntil(this.isActive))
      .subscribe(
        (value: any) => {
          if (value.status === 'SUCCESS') {
            if (value.results.length > 0) {
              this.tradeNameData = value.results;
              this.setTableValues(tradeValues[1], value.results[0].tradeName, value.results[0].supplier,
                value.results[0].formulator, tradeValues[3]);

            } else {
              this.tableNotify = {
                content: 'Enter Valid DCC',
                style: 'error'
              };
            }
          } else {
            this.tableNotify = {
              content: 'Enter Valid DCC',
              style: 'error'
            };
          }
        });
  }

  setTableValues(row: any, tradeName: any, supplier: any, formulator: any, setValue: any): void {
    const instance = this.ht.getInstance(this.id);
    if (setValue === 'edit') {
      instance.setDataAtCell(row, 7, tradeName, 'tradeName');
    }
    if (setValue === 'edit') {
      instance.setDataAtCell(row, 10, supplier, 'supplier');
    }
    if (setValue === 'edit') {
      instance.setDataAtCell(row, 11, formulator, 'formulator');
    }
  }

  openTradeDialog(event: any, row: number, col: number): void {
    this.tradeDialogOpen = true;
    this.functionLookUpGridData = true;
    this.selectedRow = row;
    this.selectedColumn = col;
  }


  /**
   * load SubWpl data
   */
  loadSubCplDetails(seqNumber: number, row: number): void {
    this.subcplrow = row;
    this.notify = false;
    this.loader = true;
    // replace seqNumber once service changes done
    const req = { flag: 'add', seq: seqNumber };
    // Load CPL Data Grid
    this.prodtrackBaseService
      .loadSubWpl(req)
      .pipe(takeUntil(this.isActive))
      .subscribe(
        (response: any) => {
          this.loader = false;
          if (response.status === 'SUCCESS') {
            this.subCplDataset = response.results.subWplDtls;
            this.showSubCplDetails = true;
          } else {
            this.notify = {
              content: response.results[0].message,
              style: 'error'
            };
          }
        },
        (): any => {
          this.loader = false;
          alert('Update: API Error');
        }
      );


  }

  /* Save material data */
  public saveMaterialData(): void {
    this.submitted = true;
    this.addMaterialFormGroup.markAllAsTouched();
    if (this.addMaterialFormGroup.valid) {
      const requestdata = this.addMaterialFormGroup.value;
      const req = {
        epsfId: this.addTestedMaterial.espfId,
        mHdr: {
          seq: this.addTestedMaterial.seq,
          epsf_id: this.addTestedMaterial.espfId,
          dcc: requestdata.dcc ? requestdata.dcc : null,
          code: this.addTestedMaterial.code,
          cus_name: this.addTestedMaterial.coCustomer,
          trade_name: this.addTestedMaterial.primaryDCCTradeName,
          use_type: requestdata.userType,
          test_type: requestdata.testType,
          test_date: this.datePipe.transform(requestdata.testDate, 'MM/dd/yyyy'),
          expiry_date: this.addTestedMaterial.expiryDate,
          volume: requestdata.volume,
          Reviewer_emp_no: null,
          qc_name: null,
          mdb_status: this.addTestedMaterial.status,
          status_change_reason: this.addTestedMaterial.status_change_reason,
          group_code: this.addTestedMaterial.group_code,
          modify_user: null,
          modify_date: null
        },
        mainWplDtls: this.cplDataset
      };

      this.loader = true;
      this.prodtrackBaseService
        .saveMaterial(req)
        .pipe(takeUntil(this.isActive))
        .subscribe(
          (response: any) => {
            this.loader = false;

            if (response.status === 'SUCCESS') {
              this.notify = {
                content: 'Data Saved Successfully',
                style: 'success'
              };

            } else {
              this.notify = {
                content: response.results[0].message,
                style: 'error'
              };
            }
          },
          (): any => {
            this.loader = false;
            alert('Update: API Error');
          }
        );
    }
  }
  omit_special_char(event: any): any {
    const k = event.charCode;
    return ((k > 64 && k < 91) || (k > 96 && k < 123) || k === 8 || k === 32 || (k >= 48 && k <= 57));
  }

  functionSelectedRowData(event: any): any {
    this.newTradeNameSelection = event;
  }

  tradeDialogClose(event: any): any {
    if (event === true) {
      this.ht.getInstance(this.id).setDataAtCell(this.selectedRow, this.selectedColumn, this.newTradeNameSelection.tradeName);
      this.tradeDialogOpen = false;
    } else {
      this.tradeDialogOpen = false;
    }
  }

}

