import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { FormGroup, FormBuilder, FormControl } from '@angular/forms';

@Component({
  selector: 'app-review-saved-search',
  templateUrl: './review-saved-search.component.html',
  styleUrls: ['./review-saved-search.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class ReviewSavedSearchComponent implements OnInit {

  // drop down for slected
  dropDown = [
    'default', '.........', 'Personalize..'
  ];
  showmodel = false;
  selectedValue: any;
  showpopup = false;
  // tslint:disable-next-line:no-inferrable-types
  duplicateFlag: boolean = false;
  // Drop for dialog model
  dropDownSearch = [
    'Default'
  ];
  showTitle = 'Personalize Saved Searches';
  popupTitle = 'Warning';
  public saveForm: FormGroup;
  constructor(private fb: FormBuilder) {
    this.saveForm = this.fb.group({
      savedSearchName: new FormControl('Default copy'),
      setDefault: new FormControl(),
      runAtStart: new FormControl(),
      Searchshowlist: new FormControl(),
      savedSearch: new FormControl(this.selectedValue),
    });
  }

  ngOnInit(): void {

  }
  // adding the field dialog Saved Search
  Duplicate(): any {
    this.duplicateFlag = true;
    this.dropDownSearch.push(this.selectedValue);
  }
  // delete field on popup

  Delete(): any {
    this.showpopup = true;
  }
  // click action dialog eventemiter
  useraction(data: boolean): any {
    // form  for user action

  }
  // drop down at the selected dialog model
  valueChange(ev: any): any {
    if (this.selectedValue === 'Personalize..') {
      this.showmodel = true;
    }
  }
  // after closing event calling dialog purpose
  showDialog(data: any): any {
    this.showmodel = data;
  }
}
