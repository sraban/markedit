import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReviewSavedSearchComponent } from './review-saved-search.component';

describe('ReviewSavedSearchComponent', () => {
  let component: ReviewSavedSearchComponent;
  let fixture: ComponentFixture<ReviewSavedSearchComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ReviewSavedSearchComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ReviewSavedSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
