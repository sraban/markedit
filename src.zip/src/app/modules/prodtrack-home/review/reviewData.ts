export const data = [
];
export const dropDownFields = [
    { text: 'Review Number', disabled: true },
    { text: 'Program Rep', disabled: true },
    { text: 'Reviewer', disabled: true },
    { text: 'City', disabled: false },
    { text: 'Emp #', disabled: false },
    { text: 'DCC #', disabled: true },
    { text: 'Emp Name', disabled: false },
    { text: 'Reviewer Comments', disabled: true },
    { text: 'Customer Name', disabled: true },
    { text: 'Customer', disabled: true }
];
export const empDropDownFields = [
    { text: 'City', disabled: true },
    { text: 'Emp #', disabled: true },
    { text: 'Emp Name', disabled: true },
];
export const searchFilters = [
    {
        label: 'Review Number',
        type: 'text',
        value: '',
        name: 'reviewNumber',
        conditionName: 'reviewNumberCondition',
        conditionValue: 'LIKE',
        show: true
    },
    {
        label: 'Program',
        type: 'multiSelect',
        Value: '',
        values: [
            {
                text: 'All',
                id: 1,
                items: [
                    { text: 'ADD', id: 2 },
                    { text: 'ADDPLUMB', id: 3 },
                    { text: 'ADMIN', id: 4 },
                    { text: 'ARC', id: 5 },
                ],
            }],
        name: 'program',
        conditionName: 'programCondition',
        conditionValue: 'IN',
        show: true
    },
    {
        label: 'DCC #',
        type: 'text',
        value: '',
        name: 'dcc',
        conditionName: 'dccCondition',
        conditionValue: 'LIKE',
        show: true
    },
    {
        label: 'Review Type',
        type: 'multiSelect',
        Value: '',
        values: [
            {
                text: 'All',
                id: 1,
                items: [
                    { text: 'INITIAL', id: 2 },
                    { text: 'REVISION', id: 3 },
                ],
            }],
        name: 'reviewtype',
        conditionName: 'reviewnumberCondition',
        conditionValue: 'IN',
        show: true
    },
    {
        label: 'Customer Name',
        type: 'text',
        value: '',
        name: 'customername',
        conditionName: 'customerCondition',
        conditionValue: 'LIKE',
        show: true
    },
    {
        label: 'Reviewer Comments',
        type: 'text',
        value: '',
        name: 'reviewercomments',
        conditionName: 'reviewercommentsCondition',
        conditionValue: 'LIKE',
        show: true
    },
    {
        label: 'Review Status',
        type: 'multiSelect',
        Value: '',
        values: [
            {
                text: 'All',
                id: 1,
                items: [
                    { text: 'OPEN', id: 2 },
                    { text: 'CLOSED', id: 3 },
                    { text: 'DRAFT', id: 4 },
                    { text: 'ONHOLD', id: 5 },
                ],
            }],
        name: 'status',
        conditionName: 'statusCondition',
        conditionValue: 'IN',
        show: true
    },
     {
        label: 'Customer',
        type: 'text',
        value: '',
        name: 'customer',
        conditionName: 'customerCondition',
        conditionValue: 'LIKE',
        show: true
    },
    {
        label: 'Justification Code',
        type: 'multiSelect',
        Value: '',
        values: [
            {
                text: 'All',
                id: 1,
                items: [
                    { text: 'AYH', id: 2 },
                    { text: 'A21CFR', id: 3 },
                    { text: 'ADMIN', id: 4 },
                    { text: 'AALT', id: 5 },
                ],
            }],
        name: 'justification',
        conditionName: 'justificationCondition',
        conditionValue: 'IN',
        show: true
    },
    {
        label: 'City',
        type: 'textWithDelete',
        value: '',
        name: 'city',
        conditionName: 'cityCondition',
        conditionValue: 'LIKE',
        show: false
    },
    {
        label: 'Emp #',
        type: 'textWithDelete',
        value: '',
        name: 'empNo',
        conditionName: 'empCondition',
        conditionValue: 'LIKE',
        show: false
    },
    {
        label: 'Emp Name',
        type: 'textWithDelete',
        value: '',
        name: 'empName',
        conditionName: 'empNameCondition',
        conditionValue: 'LIKE',
        show: false
    },
];

export const empcolumnHeaders = [
    {
        header_title: 'Review Number',
        width: 150,
        type: 'input_text',
        field: 'reviewnumber'
    },
    {
        header_title: 'Program Rep',
        width: 150,
        type: 'input_text',
        field: 'programrep'
    }];
export const empData = [{ name: 'upendra', empNo: '18' }, { name: 'g', empNo: '12' }];
export const empfieldsets = [
    {
        label: 'Review Number',
        type: 'text',
        value: '',
        name: 'reviewnumber',
        conditionName: 'reviewnumberCondition',
        conditionValue: 'LIKE'
    },
    {
        label: 'Program Rep',
        type: 'text',
        value: '',
        name: 'programrep',
        conditionName: 'programrepCondition',
        conditionValue: 'LIKE'
    },
];
export const viewReviewObj = {
    reviewNumber: '207701-TR02(INITIAL)',
    plant: '26470-26470',
    status: 'OPEN(Project:APPROVED)',
    isRush: 'N',
    reviewInfoTab: {
        programRep: 'Heather 8120',
        reviewer: 'KAMAU 5634',
        qc: 'C2377 G2377',
        openedBy: 'PTCONVERT',
        openedDate: '5/22/2004',
        closedBy: 'PTCONVERT',
        closedDate: '5/22/2004',
        reviewStatus: 'OPEN',
        isRush: 'N',
        isFastTruck: 'N'
    }
};
