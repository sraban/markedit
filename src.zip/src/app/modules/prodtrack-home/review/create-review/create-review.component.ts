import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-review',
  templateUrl: './create-review.component.html',
  styleUrls: ['./create-review.component.scss']
})
export class CreateReviewComponent implements OnInit {

  constructor() {
    // Include dependencies
  }

  ngOnInit(): void {
    // Component initialization
  }

}
