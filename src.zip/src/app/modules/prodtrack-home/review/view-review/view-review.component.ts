import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { viewReviewObj } from '../reviewData';
@Component({
  selector: 'app-view-review',
  templateUrl: './view-review.component.html',
  styleUrls: ['./view-review.component.scss']
})
export class ViewReviewComponent implements OnInit {
  dataset: any;
  columnHeader: any;
  columns: any;
  reviewInfoDataset: any;
  reviewInfocolumnHeader: any;
  reviewInfocolumns: any;
  documentDataset: any;
  documentColumnHeader: any;
  documentColumns: any;
  notesDataset: any;
  notesColumnHeader: any;
  notesColumns: any;
  viewReviewObj = viewReviewObj;
  sampleDataset: any;
  sampleColumnHeader: any;
  sampleColumns: any;
  associateEpsfDataset: any;
  associateEpsfColumnHeader: any;
  associateEpsfeColumns: any;
  otherEpsfDataset: any;
  otherEpsfColumnHeader: any;
  otherEpsfeColumns: any;
  billingInfoDataset: any;
  billingInfoColumnHeader: any;
  billingInfoColumns: any;
  oracleProjectDataset: any;
  oracleProjectColumnHeader: any;
  oracleProjectColumns: any;
  manageReviewDataset: any;
  manageReviewColumnHeader: any;
  manageReviewColumns: any;
  statusHistoryDataset: any;
  statusHistoryColumnHeader: any;
  statusHistoryColumns: any;
  openReview!: boolean;
  reviewInfoId = 'reviewInfoId';
  documentId = 'documentId';
  notesId = 'notesId';
  sampleReqId = 'sampleReqId';
  asscoiateEPSF = 'asscoiateEPSF';
  otherEPSF = 'otherEPSF';
  billingInfo = 'billingInfo';
  oracleProject = 'oracleProject';
  reviewHistory = 'reviewHistory';
  statusHistory = 'statusHistory';
  constructor(
    private http: HttpClient
  ) { }

  ngOnInit(): void {
    // table data for review-info tab from assets folder
    this.http.get('/assets/view-review/review-Info/viewReview.json').subscribe((data: any) => {
      this.reviewInfoDataset = data;
    });
    // table header data for review-info tab from assets folder
    this.http.get('/assets/view-review/review-Info/tableheader.json').subscribe(tableHeader => {
      this.reviewInfocolumnHeader = tableHeader;
    });
    // table column data for review-info tab from assets folder
    this.http.get('/assets/view-review/review-Info/tablecolumns.json').subscribe(tableColumns => {
      this.reviewInfocolumns = tableColumns;
    });
    // table data for document tab from assets folder
    this.http.get('/assets/view-review/documents/viewReview.json').subscribe((data: any) => {
      this.documentDataset = data;
    });
    // table header data for document tab from assets folder
    this.http.get('/assets/view-review/documents/tableheader.json').subscribe(tableHeader => {
      this.documentColumnHeader = tableHeader;
    });
    // table column data for document tab from assets folder
    this.http.get('/assets/view-review/documents/tablecolumns.json').subscribe(tableColumns => {
      this.documentColumns = tableColumns;
    });
    // table data for notes tab from assets folder
    this.http.get('/assets/view-review/notes/viewReview.json').subscribe((data: any) => {
      this.notesDataset = data;
    });
    // table header data for notes tab from assets folder
    this.http.get('/assets/view-review/notes/tableheader.json').subscribe(tableHeader => {
      this.notesColumnHeader = tableHeader;
    });
    // table column data for notes tab from assets folder
    this.http.get('/assets/view-review/notes/tablecolumns.json').subscribe(tableColumns => {
      this.notesColumns = tableColumns;
    });
    // table data for sampleRequest tab from assets folder
    this.http.get('/assets/view-review/sampleRequest/sampleRequestViewReview.json').subscribe((data: any) => {
      this.sampleDataset = data;
    });
    // table header data for sampleRequest tab from assets folder
    this.http.get('/assets/view-review/sampleRequest/sampleRequestTableheader.json').subscribe(tableHeader => {
      this.sampleColumnHeader = tableHeader;
    });
    // table column data for sampleRequest tab from assets folder
    this.http.get('/assets/view-review/sampleRequest/sampleRequestTablecolumns.json').subscribe(tableColumns => {
      this.sampleColumns = tableColumns;
    });
    // Associated EPSF's table data for sampleRequest tab from assets folder
    this.http.get('/assets/view-review/sampleRequest/asscoEpsfViewReview.json').subscribe((data: any) => {
      this.associateEpsfDataset = data;
    });
    // Associated EPSF's table header data for sampleRequest tab from assets folder
    this.http.get('/assets/view-review/sampleRequest/asscoEpsfTableheader.json').subscribe(tableHeader => {
      this.associateEpsfColumnHeader = tableHeader;
    });
    // Associated EPSF's table column data for sampleRequest tab from assets folder
    this.http.get('/assets/view-review/sampleRequest/asscoEpsfTablecolumns.json').subscribe(tableColumns => {
      this.associateEpsfeColumns = tableColumns;
    });
    // Other EPSF's table data for sampleRequest tab from assets folder
    this.http.get('/assets/view-review/sampleRequest/otherEpsfViewReview.json').subscribe((data: any) => {
      this.otherEpsfDataset = data;
    });
    // Other EPSF's table header data for sampleRequest tab from assets folder
    this.http.get('/assets/view-review/sampleRequest/otherEpsfTableheader.json').subscribe(tableHeader => {
      this.otherEpsfColumnHeader = tableHeader;
    });
    // Other EPSF's table column data for sampleRequest tab from assets folder
    this.http.get('/assets/view-review/sampleRequest/otherEpsfTablecolumns.json').subscribe(tableColumns => {
      this.otherEpsfeColumns = tableColumns;
    });
    // Review Billing info table data for billing-info tab from assets folder
    this.http.get('/assets/view-review/billing-info/reviewBillingViewReview.json').subscribe((data: any) => {
      this.billingInfoDataset = data;
    });
    // Review Billing info table header data for billing-info tab from assets folder
    this.http.get('/assets/view-review/billing-info/reviewBillingTableheader.json').subscribe(tableHeader => {
      this.billingInfoColumnHeader = tableHeader;
    });
    // Review Billing info table column data for billing-info tab from assets folder
    this.http.get('/assets/view-review/billing-info/reviewBillingTablecolumns.json').subscribe(tableColumns => {
      this.billingInfoColumns = tableColumns;
    });
    // Oracle Projects table data for billing-info tab from assets folder
    this.http.get('/assets/view-review/billing-info/oracleProjectViewReview.json').subscribe((data: any) => {
      this.oracleProjectDataset = data;
    });
    // Oracle Projects table header data for billing-info tab from assets folder
    this.http.get('/assets/view-review/billing-info/oracleProjectTableheader.json').subscribe(tableHeader => {
      this.oracleProjectColumnHeader = tableHeader;
    });
    // Oracle Projects table column data for billing-info tab from assets folder
    this.http.get('/assets/view-review/billing-info/oracleProjectTablecolumns.json').subscribe(tableColumns => {
      this.oracleProjectColumns = tableColumns;
    });
    // Manage review history table data for history tab from assets folder
    this.http.get('/assets/view-review/history/manageReviewHistoryViewReview.json').subscribe((data: any) => {
      this.manageReviewDataset = data;
    });
    // Manage review history table header data for history tab from assets folder
    this.http.get('/assets/view-review/history/manageReviewHistoryTableheader.json').subscribe(tableHeader => {
      this.manageReviewColumnHeader = tableHeader;
    });
    // Manage review history table column data for history tab from assets folder
    this.http.get('/assets/view-review/history/manageReviewHistoryTablecolumns.json').subscribe(tableColumns => {
      this.manageReviewColumns = tableColumns;
    });
    // Sample request status history table data for history tab from assets folder
    this.http.get('/assets/view-review/history/statusHistoryViewReview.json').subscribe((data: any) => {
      this.statusHistoryDataset = data;
    });
    // Sample request status history table header data for history tab from assets folder
    this.http.get('/assets/view-review/history/statusHistoryTableheader.json').subscribe(tableHeader => {
      this.statusHistoryColumnHeader = tableHeader;
    });
    // Sample request status history table column data for history tab from assets folder
    this.http.get('/assets/view-review/history/statusHistoryTablecolumns.json').subscribe(tableColumns => {
      this.statusHistoryColumns = tableColumns;
    });
  }
// switch between edit review and open review button based o tab selection
  onTabSelect(event: any): void {
    if (event.index === 4 || event.index === 5) {
      this.openReview = true;
    }else{
      this.openReview = false;
    }
  }
}
