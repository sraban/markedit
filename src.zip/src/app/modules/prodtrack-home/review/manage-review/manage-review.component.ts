import { DatePipe } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { ProdtrackServiceService } from '../../prodtrack-service.service';
import { ProdtrackBaseService } from '../../services/prodtrack-base.service';

@Component({
  selector: 'app-manage-review',
  templateUrl: './manage-review.component.html',
  styleUrls: ['./manage-review.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class ManageReviewComponent implements OnInit {
  dataset: any;
  gridData: any = [];
  columnHeader: any;
  columns: any;
  id = 'viewTable';
  public loader: any;
  public listItems: Array<string> = [
    'CLOSED', 'DRAFT'
  ];
  revenueVisible = false;
  reviewData: any;
  public current = 1;
  gridHeaders: any;
  gridOptions = {
    allowToEdit: 'Y',
    allowToAdd: 'Y',
    allowToDelete: 'Y',
  };
  editorCol = {
    title: 'Options',
    width: 150,
    type: 'command',
    openPopUp: true,
    filterable: false
  };
  deletedialogFlag = false;
  deleteTitleLabel: any;
  updateLabel = 'Update document';
  addLabel = 'Add document';
  editdialogFlag = false;
  controlNames: any;
  documentEditForm: FormGroup | any;
  submitted = false;
  notifyPopup: any;
  documentType: any;
  control: any;
  file: any;
  addDialog!: boolean;
  rowIndex: any;
  notesGridHeaders: any;
  notesGridData: any;
  notesFormControl: any;
  noteTypeList: any;
  reviewInfoSectionDetails: any;
  editReviewData: any;
  reviewInfoHeader: any;
  reviewInfoColumns: any;
  reviewInfCommandIndex: any;
  reviewInfoID = 'reviewInfo';
  reviewInfoDataset: any;
  private isActive = new Subject();
  notify: any;
  isDialog = false;
  removeNotesData: any;
  constructor(
    private http: HttpClient, private prodtrackBaseService: ProdtrackBaseService,
    private formBuilder: FormBuilder, private translate: TranslateService,
    private prodtrackService: ProdtrackServiceService,
    private datepipe: DatePipe
  ) { }

  ngOnInit(): void {
    this.editReviewData = this.prodtrackService.getEditReviewData();
    this.reviewInfoTab();
    this.translate.get('editReview').subscribe((text: any) => {
      const trnaslate = text;
      this.updateLabel = trnaslate.documentsTab.editLabel;
      this.addLabel = trnaslate.documentsTab.addLabel;
      this.deleteTitleLabel = trnaslate.documentsTab.deleteConfirmation;
    });
    this.control = new FormGroup({});

    // handson table header data from assets folder
    this.http.get('assets/editMaterialDB/manageReviewHeader.json').subscribe(tableHeader => {
      this.columnHeader = tableHeader;
    });
    // handson table column data from assets folder
    this.http.get('assets/editMaterialDB/managereviewcolumn.json').subscribe(tableColumns => {
      this.columns = tableColumns;
    });
    this.documentType = [{ display_value: 'MISC', value: 1 }, { display_value: 'COMP_DOC', value: 2 },
    { display_value: 'CPL/CFL', value: 3 }, { display_value: 'CRITICAL', value: 4 }, { display_value: 'LIT', value: 5 },
    { display_value: 'MEMO', value: 6 }, { display_value: 'WOREQ', value: 7 }];
    this.manageReviewDetails();
    this.loadTableData();
    this.editDocumentForm();
    this.gridHeaders = [
      { field: 'docType', header_title: 'Doc Type', width: 130, type: 'dropdown', dropdown_list: this.documentType, editable: true },
      { field: 'des', header_title: 'Description', width: 130, type: 'input_text', editable: true },
      { field: 'document', header_title: 'Document', width: 130, type: 'link', editable: true },
      { field: 'formatType', header_title: 'Format Type', width: 130, type: 'input_text', editable: false },
      { field: 'createdBy', header_title: 'Created By', width: 130, type: 'input_text', editable: false },
      { field: 'createdDate', header_title: 'Created Date', width: 130, type: 'input_text', editable: false },
      { field: 'finalBy', header_title: 'Final By', width: 130, type: 'input_text', editable: false },
      { field: 'finalDate', header_title: 'Final Date', width: 130, type: 'input_text', editable: false },
      { field: 'final', header_title: 'Final', width: 130, type: 'checkbox', editable: true },
      { field: 'archived', header_title: 'Archived', width: 130, type: 'checkbox', editable: true },
    ];
    this.gridData = [{
      docType: 'WOREQ', des: 'Updated WOR', document: 'View Document', formatType: 'XLSM',
      createdBy: 'Rprasad', finalBy: '', finalDate: '', final: true, archived: false, link: '/assets/print.png'
    }, {
      docType: 'MEMO', des: 'Updated WOR', document: 'View Document', formatType: 'XLSM',
      createdBy: 'Rprasad', finalBy: '', finalDate: '', final: false, archived: true
    }];

    const formCtrls: any = {};

    this.gridHeaders.forEach((item: any) => {
      if (item.field === 'docType' || item.field === 'des' || item.field === 'document' || item.field === 'final' || item.field === 'archived') {
        formCtrls[item.field] = new FormControl(false);
      }
      else {
        formCtrls[item.field] = new FormControl(true);
      }
      this.control = new FormGroup(formCtrls);
    });

    this.notesTab();
  }

  editDocumentForm(): void {
    this.documentEditForm = this.formBuilder.group({
      document: new FormControl('', [Validators.required]),
      desc: new FormControl(''),
      final: new FormControl(''),
      archived: new FormControl(''),
    });
    this.controlNames = {
      document: 'Doc Type',
      desc: 'Description',
      final: 'Final',
      archived: 'Archived'
    };
  }

  // Load Scope DCC Details
  loadTableData(): any {
    this.loader = true;
    this.prodtrackBaseService.manageReviewTableData().subscribe((tabledata: any) => {
      if (this.reviewData[0].reviewstatus === 'draft') {
        this.dataset = tabledata.find((ele: any) => ele.status === 'open');
        this.revenueVisible = true;
      } else {
        this.dataset = tabledata.find((ele: any) => ele.status === 'draft');
      }
      this.loader = false;
    });
  }
  // Fetching Review Details
  manageReviewDetails(): any {
    this.loader = true;
    this.prodtrackBaseService.manageReviewDetails().subscribe((reviewinfo: any) => {
      this.reviewData = reviewinfo;
      this.loader = false;
    });
  }
  onTabSelect(event: any): void {
    switch (event.title) {
      case 'Notes':
        this.getNotesData();
        break;
      case 'Change Request':

        break;
      case 'Documents':

        break;
    }
  }

  // Handling adding new row in document table
  addHandler(): void {
    this.addDialog = true;
    this.documentEditForm.reset();
    this.editdialogFlag = true;
    this.notifyPopup = {};
    this.submitted = true;
  }

  // Handling edit row in document table
  editHandler(data: any): void {
    this.rowIndex = data.rowIndex;
    this.addDialog = false;
    const documentList = [...this.documentType];
    const selectedDocType = documentList.filter(obj => obj.display_value === data.dataItem.docType);
    this.editdialogFlag = true;
    this.notifyPopup = {};
    this.submitted = true;
    this.documentEditForm.patchValue({
      document: selectedDocType[0].value,
      desc: data.dataItem.des,
      final: data.dataItem.final,
      archived: data.dataItem.archived
    });
  }

  // Update document table while adding and editing
  update(): void {
    // Update API will come here
    const documentList = [...this.documentType];
    const selectedDocType = documentList.filter(obj => obj.value === this.documentEditForm.controls.document.value);
    if (this.addDialog) {
      const obj = {
        docType: selectedDocType[0].display_value, des: this.documentEditForm.controls.desc.value, document: 'View Document', formatType: 'XLSM',
        createdBy: 'Rprasad', finalBy: '', finalDate: '', final: this.documentEditForm.controls.final.value,
        archived: this.documentEditForm.controls.archived.value
      };
      this.gridData.unshift(obj);
    } else {

      this.gridData[this.rowIndex].docType = selectedDocType[0].display_value;
      this.gridData[this.rowIndex].des = this.documentEditForm.controls.desc.value;
      this.gridData[this.rowIndex].final = this.documentEditForm.controls.final.value;
      this.gridData[this.rowIndex].archived = this.documentEditForm.controls.archived.value;
    }
    this.editdialogFlag = false;

  }

  upload(event: any): any {
    this.file = event.target.files[0];
  }

  removeHandler(event: any): void {
    this.deletedialogFlag = true;
  }

  onDeleteDialogClose(data: any): any {
    this.deletedialogFlag = false;
    if (data === 'Yes') {
      this.onAccept();
    }
  }

  onAccept(): any {
    // Delete API Call will come here
  }

  onEditDialogClose(): any {
    this.editdialogFlag = false;
  }

  // Notes Tab section start

  notesTab(): void {
    this.noteTypeList = [
      { display_value: 'Sampling Note', value: 1 }, { display_value: 'Auditor Note', value: 2 },
      { display_value: 'Listing Note', value: 3 },
      { display_value: 'Formulation Note', value: 4 }, { display_value: 'Testing Scheme', value: 5 }];
    this.notesGridHeaders = [
      { field: 'note_type', header_title: 'Note Type', width: 130, type: 'dropdown', dropdown_list: this.noteTypeList, editable: true },
      { field: 'note', header_title: 'Note', width: 130, type: 'input_text', editable: true },
      { field: 'created_by', header_title: 'Created By', width: 130, type: 'input_text', editable: true },
      { field: 'created_date', header_title: 'Created Date', width: 130, type: 'input_text', editable: true },
      { field: 'modify_user', header_title: 'Modified By', width: 130, type: 'input_text', editable: true },
      { field: 'modify_date', header_title: 'Modified Date', width: 130, type: 'input_text', editable: true },
    ];
    const formCtrls: any = {};
    this.notesGridHeaders.forEach((item: any) => {
      formCtrls[item.field] = new FormControl(true, [Validators.required]);
      this.notesFormControl = new FormGroup(formCtrls);
    });
  }

  notesRemoveHandler(event: any): void {
    this.removeNotesData = event;
    this.isDialog = true;
  }

  notesAddEditHandler(data: any): void {
    const obj = {
      itemDocsList: [
        {
          note: data.notesData.note,
          iact_seq: '185298',         // need to check how to get iact_seq
          activity_status: 'OPEN'     // need to check do we need to pass initial activity type?
        }
      ]
    };
    if (data.isAdd) {
      this.prodtrackBaseService.createNotes(obj).pipe(takeUntil(this.isActive))
        .subscribe(
          (response: any) => {
            if (response.status === 'SUCCESS') {
              this.getNotesData();
            } else {
              this.loader = false;
            }
          },
          (err: any) => {
            this.loader = false;
            this.notify =
            {
              style: 'error',
              content: err.statusText
            };
          });
    } else {
        // update API will come here
    }
  }

  // Review Info Tab Section

  reviewInfoTab(): void {
    this.reviewInfCommandIndex = { checkbox: 0, options: 1 };
    this.reviewInfoHeader = [
      'Select All', 'Actions', 'DCC#', 'Trade Name', 'Customer', 'Product', 'Item Type'
    ];
    this.reviewInfoDataset = [
      { dcc: 'PM05539', tradename: '2228610 - TRADE NAME', customer: '11600-11600', product: 'Y', item_type: 'Assembly' },
      { dcc: 'PM05539', tradename: '2228610 - TRADE NAME', customer: '11600-11600', product: 'Y', item_type: 'Assembly' },
      { dcc: 'PM05539', tradename: '2228610 - TRADE NAME', customer: '11600-11600', product: 'Y', item_type: 'Assembly' },
      { dcc: 'PM05539', tradename: '2228610 - TRADE NAME', customer: '11600-11600', product: 'Y', item_type: 'Assembly' }
    ];
    this.reviewInfoColumns = [
      {
        renderer: (instance: any, TD: any, row: any, col: any, prop: any, value: any, cellProperties: any) => {
          TD.innerHTML = `<input type='checkbox' id='checkbox' /> `;
          return TD;
        },
        colHeaders: true, width: 40, readOnly: true
      },
      {
        class: 'newStyleFortd', width: 30,
        renderer:
          (instance: any, TD: any, row: number, col: number, prop: any, value: any, cellProperties: any) => {
            TD.innerHTML = `<button style="cursor: pointer; color: red; border: 2px solid red; border-radius: 4px; background-color: white; width: unset; height: unset" id='deletePopup' class='k-icon k-i-close'></button>`;
            return TD;
          }
      },
      {
        data: 'dcc', readOnly: true,
        renderer:
          (instance: any, td: any, row: number, col: number, prop: any, value: any, cellProperties: any) => {
            const a = document.createElement('a');
            a.innerHTML = value;
            td.appendChild(a);
            td.innerHTML = `<a style="color:blue; textdecoration: underline; cursor: pointer" onclick="viewDCC()" target = "_self" >${value}</a>`;
            return td;
          }
      },
      { data: 'tradename', readOnly: true },
      { data: 'customer', readOnly: true },
      { data: 'product', readOnly: true },
      { data: 'item_type', readOnly: true },
    ];
    this.reviewInfoSectionDetails = {
      programRep: 'N4648 C4648',
      processReview: 'Yes',
      reviewStatus: [],
      reviewer: '',
      rush: 'No',
      openedBy: 'Venittelli',
      qc: '',
      toxReview: 'Yes',
      openDate: '13/01/2014',
      reasonForReview: '',
      reasonForStatusChange: '',
    };
  }

  // Close confirmation pop up
  onCloseDialog(value: any): void {
    if (value) {
      this.removeNote();
    }
    this.isDialog = false;
  }

  getNotesData(): void {
    const obj = {
      reviewNumber: this.editReviewData.reviewNo,
      reviewType: this.editReviewData.actvityType
    };
    this.prodtrackBaseService.getNotesDetails(obj).pipe(takeUntil(this.isActive))
      .subscribe(
        (response: any) => {
          if (response.status === 'SUCCESS') {
            this.notesGridData = response.results;
          } else {
            this.loader = false;
          }
        },
        (err: any) => {
          this.loader = false;
          this.notify =
          {
            style: 'error',
            content: err.statusText
          };
        });
  }

  removeNote(): void {
    const obj = {
      itemDocsList: [
        {
          seq: this.removeNotesData.dataItem.seq,
          operation: 'delete'
        }
      ]
    };
    this.prodtrackBaseService.deleteNote(obj).pipe(takeUntil(this.isActive))
      .subscribe(
        (response: any) => {
          if (response.status === 'SUCCESS') {
            this.notify =
            {
              style: 'success',
              content: response.status
            };
            this.getNotesData();
          } else {
            this.loader = false;
            this.notify =
            {
              style: 'error',
              content: response.results[0].message
            };
          }
        },
        (err: any) => {
          this.loader = false;
          this.notify =
          {
            style: 'error',
            content: err.statusText
          };
        });
  }
}

