import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { data } from './reviewData';
import { searchFilters, dropDownFields } from '../review/reviewData';
import { process } from '@progress/kendo-data-query';
import { ProdtrackServiceService } from '../prodtrack-service.service';
import { ProdtrackBaseService } from '../services/prodtrack-base.service';
import { takeUntil } from 'rxjs/operators';
import { Subject } from 'rxjs';
import { PageChangeEvent } from '@progress/kendo-angular-grid';

@Component({
  selector: 'app-review',
  templateUrl: './review.component.html',
  styleUrls: ['./review.component.scss', '../material-db/material-db.component.scss'],
  encapsulation: ViewEncapsulation.None

})
export class ReviewComponent implements OnInit {
  formGroup!: any;
  fieldControls: any = {};
  public gridView: {
    data: any[],
    total: number
  };
  match = 'match';
  pageSize = 1;
  pageSizeList = [2, 5, 10, 20, 50];
  buttonCount = 5;
  count = 0;
  expanded = true;
  searchKey!: string;
  public searchFilters: any = searchFilters;
  // public conditionDropdownList: Array<any> = conditionDropdownListData;
  public dropDownFields: any = dropDownFields;
  oldResult: any;
  searchButtonDisable = true;
  public dataSet: any = data;
  public loader: any;
  private isActive = new Subject();
  notify: any;
  reviewsearchDetails: any;
  reqObj: any;
  /*To set collapsible open*/
  savepopup = false;
  saveTitle = 'Create Saved Search';
  public saveForm: FormGroup;
  justificationDropdownData: any;
  programDropDownData: any;
  reviewTypeDropDownData: any;
  reviewStatusDropDownData: any;
  data: any[];
  public skip = 0;
  constructor(
    private fb: FormBuilder,
    private prodTrackService: ProdtrackServiceService,
    private prodtrackBaseService: ProdtrackBaseService) {
    this.saveForm = this.fb.group({
      savedSearchName: new FormControl('Default copy'),
      setDefault: new FormControl(),
      runAtStart: new FormControl(),
      savedSearch: new FormControl(),
    });
    this.gridView = {
      data: [],
      total: 0
    };
    this.data = [];
  }
  public pageChange(event: PageChangeEvent): void {
    this.skip = event.skip;
    this.loadProducts();
  }

  private loadProducts(): void {
    this.gridView = {
      data: this.data.slice(this.skip, this.skip + this.pageSize),
      total: this.data.length,
    };
    this.gridView.data = this.data.slice(this.skip, this.skip + this.pageSize);
  }
  ngOnInit(): void {
    this.createFromGroup();
    this.count = this.gridCounter();
    this.oldResult = this.formGroup.value;
    this.prodTrackService.searchObservable.subscribe((res: any) => {
      this.onFilter(res);
    }
    );
    this.prodTrackService.materialSearchFormState.subscribe(response => {
      this.searchButtonDisable = response;
    });
    this.getJustificationDropDown();
    this.programDropDown();
    this.reviewTypeDropDown();
    this.reviewStatusDropDown();
  }
  /*
 * create from Group
 */
  createFromGroup(): void {
    searchFilters.forEach((element: any) => {
      this.fieldControls[element.name] = new FormControl(element.value);
      this.fieldControls[element.conditionName] = new FormControl(element.conditionValue);
    });
    this.fieldControls[this.match] = new FormControl('All');
    this.formGroup = new FormGroup(this.fieldControls);
  }
  // Specific search filter for Review page based on the Review type.
  public onFilter(inputValue: any): void {
    console.log(inputValue);
    if (inputValue) {
      this.gridView.data = process(this.dataSet, {
        filter: {
          logic: 'or',
          filters: [
            {
              field: 'reviewStatus',
              operator: 'contains',
              value: inputValue,
            },
            {
              field: 'programrep',
              operator: 'contains',
              value: inputValue,
            },
          ],
        }
      }).data;
    } else {
      this.gridView = this.dataSet;
    }
    this.count = this.gridCounter();
  }
  // tslint:disable-next-line:typedef
  getStatus(value: any) {
    if (value?.length > 0) {
      const filterValue = value[0].text;
      console.log(filterValue.toLowerCase());
      return filterValue.toLowerCase();

    }
    else {
      return '';
    }

  }
  // tslint:disable-next-line:typedef
  compareSearchTerm(oldValue: any, newValue: any) {
    // tslint:disable-next-line:forin
    let searchKey = '';
    this.reqObj = {
      searchFields: []
    };
    // tslint:disable-next-line:forin
    for (const oldKey in oldValue) {
      const savedValue = oldValue[oldKey];
      let isMatchFound = false;
      // tslint:disable-next-line:forin
      for (const newKey in newValue) {
        const changeValue = newValue[newKey];
        if (!isMatchFound && oldKey === newKey && savedValue !== changeValue) {
          if (Array.isArray(changeValue)) {
            searchKey = changeValue[0].text;
            this.getRequestedSearchFields(this.reqObj, newKey, newValue);
          } else {
            this.getRequestedSearchFields(this.reqObj, newKey, newValue);
            searchKey = changeValue;
          }
          isMatchFound = true;
        }
      }
    }
    this.searchKey = searchKey;
  }
  // Get updated fields of review search
  getRequestedSearchFields(reqObj: any, newKey: any, newValue: any): void {
    if (!newKey.includes('Condition')) {
      const obj = {
        fieldName: '',
        operator: '',
        value: ''
      };
      obj.value = newValue[newKey];
      obj.operator = newValue[newKey + 'Condition'];
      obj.fieldName = newKey;
      reqObj.searchFields.push(obj);
    }
  }
  // Get the count of number of rows in grid.
  gridCounter(): number {
    return this.gridView.data.filter((item: any) => true).length;
  }
  /** * To do Sreach */
  search(): void {
    this.compareSearchTerm(this.oldResult, this.formGroup.value);
    this.prodTrackService.callComponentMethod(this.searchKey);
    this.loader = true;
    this.prodtrackBaseService
      .reviewsearch(this.reqObj)
      .pipe(takeUntil(this.isActive))
      .subscribe(
        (response: any) => {
          if (response.status === 'SUCCESS') {
            this.loader = false;
            this.reviewsearchDetails = response.results;
            this.gridView.data = response.results;
            if (this.reviewsearchDetails === '') {
              this.notify =
              {
                style: 'error',
                content: 'No records found with these search criteria'
              };
            }
          } else {
            this.loader = false;
          }
        },
        (err: any) => {
          this.loader = false;
          this.notify =
          {
            style: 'error',
            content: err.statusText
          };
        }
      );
  }
  /*** add search filter Field
  */
  save(): void {
    // saving form data
    this.savepopup = true;
  }
  /*** To remove added search filter
*/
  valueChange(ev: any): void {
    const index = this.searchFilters.findIndex((item: any) => item.label === ev.text);
    if (this.searchFilters[index].type === 'textWithDelete') {
      this.searchFilters[index].show = true;
      const dropDownIndex = this.dropDownFields.findIndex((x: any) => x.text === ev.text);
      this.dropDownFields[dropDownIndex].disabled = true;
    }
  }
  /** * To remove added search filter */
  removeField(index: any, field: any): void {
    this.searchFilters[index].show = false;
    const dropDownIndex = this.dropDownFields.findIndex((x: any) => x.text === field.label);
    this.dropDownFields[dropDownIndex].disabled = false;
  }
  /**
   * To set all values in the form
   */
  reset(): void {
    this.createFromGroup();
  }
  // To justificationdropdown geting results
  getJustificationDropDown(): void {
    this.prodtrackBaseService
      .getJustificationDropDown(this.reqObj)
      .pipe(takeUntil(this.isActive))
      .subscribe(
        (response: any) => {
          if (response.status === 'SUCCESS') {
            this.justificationDropdownData = response.results;
            if (this.justificationDropdownData === '') {
              this.notify =
              {
                style: 'error',
                content: 'No records found with these search criteria'
              };
            }
          } else {
            this.loader = false;
          }
        },
        (err: any) => {
          this.loader = false;
          this.notify =
          {
            style: 'error',
            content: err.statusText
          };
        }
      );
  }
  // To programDropDown geting results
  programDropDown(): void {
    this.prodtrackBaseService
      .programDropDown(this.reqObj)
      .pipe(takeUntil(this.isActive))
      .subscribe(
        (response: any) => {
          if (response.status === 'SUCCESS') {
            this.programDropDownData = response.results;
            if (this.programDropDownData === '') {
              this.notify =
              {
                style: 'error',
                content: 'No records found with these search criteria'
              };
            }
          } else {
            this.loader = false;
          }
        },
        (err: any) => {
          this.loader = false;
          this.notify =
          {
            style: 'error',
            content: err.statusText
          };
        }
      );
  }
  // To reviewTypeDropDown geting results
  reviewTypeDropDown(): void {
    this.prodtrackBaseService
      .reviewTypeDropDown(this.reqObj)
      .pipe(takeUntil(this.isActive))
      .subscribe(
        (response: any) => {
          if (response.status === 'SUCCESS') {
            this.reviewTypeDropDownData = response.results;
            if (this.reviewTypeDropDownData === '') {
              this.notify =
              {
                style: 'error',
                content: 'No records found with these search criteria'
              };
            }
          } else {
            this.loader = false;
          }
        },
        (err: any) => {
          this.loader = false;
          this.notify =
          {
            style: 'error',
            content: err.statusText
          };
        }
      );
  }
  // To reviewStatusDropDown geting results
  reviewStatusDropDown(): void {
    this.prodtrackBaseService
      .reviewStatusDropDown(this.reqObj)
      .pipe(takeUntil(this.isActive))
      .subscribe(
        (response: any) => {
          if (response.status === 'SUCCESS') {
            this.reviewStatusDropDownData = response.results;
            if (this.reviewStatusDropDownData === '') {
              this.notify =
              {
                style: 'error',
                content: 'No records found with these search criteria'
              };
            }
          } else {
            this.loader = false;
          }
        },
        (err: any) => {
          this.loader = false;
          this.notify =
          {
            style: 'error',
            content: err.statusText
          };
        }
      );
  }

  editReviewDetails(eidtData: any): void {
    this.prodTrackService.setEditReviewData(eidtData);
  }
}
