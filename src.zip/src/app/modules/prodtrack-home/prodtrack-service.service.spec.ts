import { TestBed } from '@angular/core/testing';

import { ProdtrackServiceService } from './prodtrack-service.service';

describe('ProdtrackServiceService', () => {
  let service: ProdtrackServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ProdtrackServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
