import { Component, Input } from '@angular/core';
import { ProdtrackServiceService } from '../../prodtrack-service.service';

@Component({
  selector: 'app-search-filter-text',
  templateUrl: './search-filter-text.component.html',
  styleUrls: ['./search-filter-text.component.scss']
})
export class SearchFilterTextComponent {
  @Input() field: any;
  @Input() formGroup: any;
  @Input() conditionDropdownList: any;
  @Input() searchFilters: any;
  notBlank = true;
  constructor(private prodtrackServiceService: ProdtrackServiceService) { }

  onValueChange(): void {
    let disableSearch = true;
    disableSearch = this.searchFilters.every((ele: any) => {
      if (this.formGroup.value[ele.name] && this.formGroup.value[ele.name].length > 0) {
        return false;
      } else {
        return true;
      }
    });
    this.prodtrackServiceService.materialSearchFormState.next(disableSearch);
  }
  getDropdownValue(event: any): any {
    this.notBlank = event.value === 'IS_BLANK' ? false : true ;
  }
  // Text capitalize automatically when entering the first character only in EPSF ID field.
  forceUppercaseConditionally(formControlName: any, event: any): any {
    if (formControlName === 'epsfId') {
      const first = event.target.value.substr(0, 1).toUpperCase();
      const finalValue =  first + event.target.value.substr(1);
      this.formGroup.get(formControlName).setValue(finalValue);
    }
}
}
