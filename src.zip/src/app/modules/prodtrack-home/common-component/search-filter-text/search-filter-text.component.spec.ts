import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchFilterTextComponent } from './search-filter-text.component';

describe('SearchFilterTextComponent', () => {
  let component: SearchFilterTextComponent;
  let fixture: ComponentFixture<SearchFilterTextComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SearchFilterTextComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchFilterTextComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
