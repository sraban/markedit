import { Component, OnInit, Input } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { empcolumnHeaders, empfieldsets, empData, empDropDownFields } from '../../material-db/data';

@Component({
  selector: 'app-search-filter-textemployee',
  templateUrl: './search-filter-textemployee.component.html',
  styleUrls: ['./search-filter-textemployee.component.scss'],

})
export class SearchFilterTextemployeeComponent implements OnInit {

  @Input() field: any;
  @Input() formGroup: FormGroup = new FormGroup({});
  @Input() conditionDropdownList: any;
  opened = false;
  title = '';
  fieldControls: any = {};
  employeeFormGroup: FormGroup = new FormGroup({});
  gridData: any;
  searchType = 'Advanced search';
  match = 'match';
  showAddField = false;
  columnHeaders: any = empcolumnHeaders;
  fieldsets: any = empfieldsets;
  dataSet: any = [];
  public empDropDownFields: any = empDropDownFields;

  ngOnInit(): void {
    this.fieldsets.forEach((element: any) => {
      this.fieldControls[element.name] = new FormControl(element.value);
      this.fieldControls[element.conditionName] = new FormControl(element.conditionValue);
    });
    this.fieldControls[this.match] = new FormControl('All');
    this.employeeFormGroup = new FormGroup(this.fieldControls);
  }

  /**
   * To change advance and basic search
   */
  toggelSearch(): void {
    if (this.searchType === 'Advanced search') {
      this.searchType = 'Basic';
      this.showAddField = true;
    } else {
      this.searchType = 'Advanced search';
      this.showAddField = false;
    }
  }

  /**
   * To perform search
   */
  search(): void {
    this.gridData = empData;
  }
  /**
   * reset search form value
   */
  reset(): void {
    this.employeeFormGroup.controls.empName.setValue('');
    this.employeeFormGroup.controls.emp.setValue('');
    this.employeeFormGroup.controls.city.setValue('');
  }
  /**
   * To cancel and close popup
   */
  cancel(): void {
    this.formGroup.controls.reviewer.setValue('');
    this.opened = false;
  }

  /**
   * To set value and close popup
   */
  confirm(): void {
    this.opened = false;
  }

  /**
   * To open dialog box
   */
  dialogOpen(): void {
    this.opened = true;
    this.title = this.field.label;
  }

  /**
   * To open close box
   */
  dialogClose(): void {
    this.opened = false;
  }

  /**
   * To select value from grid
   */
  selectedRowData(data: any): void {
    this.formGroup.get(this.field.name)?.setValue(data.name);
  }

}
