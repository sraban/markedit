import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchFilterTextemployeeComponent } from './search-filter-textemployee.component';

describe('SearchFilterTextemployeeComponent', () => {
  let component: SearchFilterTextemployeeComponent;
  let fixture: ComponentFixture<SearchFilterTextemployeeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SearchFilterTextemployeeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchFilterTextemployeeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
