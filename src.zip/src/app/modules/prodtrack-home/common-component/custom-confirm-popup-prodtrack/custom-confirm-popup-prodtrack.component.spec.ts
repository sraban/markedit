import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomConfirmPopupProdtrackComponent } from './custom-confirm-popup-prodtrack.component';

describe('CustomConfirmPopupProdtrackComponent', () => {
  let component: CustomConfirmPopupProdtrackComponent;
  let fixture: ComponentFixture<CustomConfirmPopupProdtrackComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomConfirmPopupProdtrackComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomConfirmPopupProdtrackComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
