import { Component, EventEmitter, Input, Output, ViewEncapsulation } from '@angular/core';
@Component({
  selector: 'app-custom-confirm-popup-prodtrack',
  templateUrl: './custom-confirm-popup-prodtrack.component.html',
  styleUrls: ['./custom-confirm-popup-prodtrack.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class CustomConfirmPopupProdtrackComponent {

  @Input() opened!: boolean;
  @Output() onclose = new EventEmitter();
  @Input() showTitle: any;
  @Input() width: any;
  @Input() height: any;


  dialogClose(): void {
    this.opened = false;
    this.onclose.emit(false);
  }

  onAccept(): void {
    this.onclose.emit(true);
    this.opened = false;
  }

  onDecline(): void {
    this.onclose.emit(false);
    this.opened = false;
  }
}




