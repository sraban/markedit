import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SerachDropdownlistComponent } from './serach-dropdownlist.component';

describe('SerachDropdownlistComponent', () => {
  let component: SerachDropdownlistComponent;
  let fixture: ComponentFixture<SerachDropdownlistComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SerachDropdownlistComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SerachDropdownlistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
