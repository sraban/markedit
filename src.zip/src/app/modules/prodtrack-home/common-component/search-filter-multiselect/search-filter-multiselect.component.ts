import { Component, Input, OnInit } from '@angular/core';
import { PopupSettings } from '@progress/kendo-angular-dropdowns';
import { ProdtrackServiceService } from '../../prodtrack-service.service';

@Component({
  selector: 'app-search-filter-multiselect',
  templateUrl: './search-filter-multiselect.component.html',
  styleUrls: ['./search-filter-multiselect.component.scss']
})
export class SearchFilterMultiselectComponent implements OnInit{
  @Input() field: any;
  @Input() dropdownData: any;
  @Input() formGroup: any;
  @Input() conditionDropdownList: any;
  public get viewContainerSettings(): PopupSettings {
    return {
        width: '10%',
    };
  }

  constructor(private prodtrackServiceService: ProdtrackServiceService) {
   }

  onValueChange(value: any): void {
    let disableSearch;
    if (value === undefined || value === []) {
      disableSearch = true;
    } else {
      disableSearch = false;
    }
    this.prodtrackServiceService.materialSearchFormState.next(disableSearch);
  }
  // tslint:disable-next-line:use-lifecycle-interface
  ngOnChanges(): void{
    if (this.dropdownData) {
      this.dropdownData = this.dropdownData;
  }

  }
  ngOnInit(): void {

  }
}
