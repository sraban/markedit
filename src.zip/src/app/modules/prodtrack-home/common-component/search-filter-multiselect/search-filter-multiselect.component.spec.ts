import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchFilterMultiselectComponent } from './search-filter-multiselect.component';

describe('SearchFilterMultiselectComponent', () => {
  let component: SearchFilterMultiselectComponent;
  let fixture: ComponentFixture<SearchFilterMultiselectComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SearchFilterMultiselectComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchFilterMultiselectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
