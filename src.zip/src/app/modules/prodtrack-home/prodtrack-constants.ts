export const constObj = {

    // Add Material DB
    addMaterialDb: {
        add: 'materialDb/addOrEdit', // Add MaterialDb fetching Material details
        dccSearch : 'materialDb/dccSearch', // Search Dcc in Material details
        save: 'materialDb/save', // Save MaterialDb  details
        loadWpl: 'materialDb/loadWplDtls', // MaterialDb CPL details
        loadSubWpl: 'materialDb/loadWplSubDtls', // MaterialDb CPL details
        tradeName: 'materialDb/getTradeNames'// MaterialDb Trade Name details
    },

    testedMaterialDb: {
        editMaterialdb: {
            edit: 'materialDb/edit', // Edit MaterialDb fetching Material details
            wplDetails: 'materialDb/loadWplDtls', // Edit MaterialDb CPL details
            saveEditMaterial: 'materialDb/save', // Save Edit MaterialDb details
            clearEditMaterial: 'materialDb/delete',  // Clear All Edit MaterialDb details
            cplHeaderDetails: 'assets/editMaterialDB/tableheader.json', // cpl handson table header data from assets folder
            cplColumnDetails: 'assets/editMaterialDB/tablecolumns.json' // handson table column data from assets folder
        }
    },
    // View material DB
    viewMaterialDB: {
        view: 'materialDb/view'
    },
    prodtrackReview: {
        manageReview: {
            manageReviewTableInfo: 'assets/editMaterialDB/manageReviewTable.json',  // Review/Manage Review Table Data
            manageReviewInfo: 'assets/editMaterialDB/editMaterialDb.json' // Review/ManageReview Details
        },
        notes: {
           getNotes: 'review/getNotesDetails',
           delete: 'review/updateNotes',
           createNotes: 'review/createNotes'
        }
    },
    // Search material DB
    searchMaterialDB: {
        search: 'materialDb/search'
    },
    //  Review Search
    reviewsearch: {
        search: 'review/search',
        getJustificationDropDown: 'review/getJustificationDropDown',
        programDropDown: 'review/programDropDown',
        reviewTypeDropDown: 'review/reviewTypeDropDown',
        reviewStatusDropDown : 'review/reviewStatusDropDown'
    }
};

