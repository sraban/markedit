import { Component, ComponentFactoryResolver, EventEmitter, OnInit, Output, ViewEncapsulation } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { DataService } from 'src/app/common/data.service';

@Component({
  selector: 'app-testing-kendo',
  templateUrl: './testing-kendo.component.html',
  styleUrls: ['./testing-kendo.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class TestingKendoComponent implements OnInit {
@Output() lookUpValue = new EventEmitter();
gridData: any[] = [];
formControl: any;
columnHeaders: any[] = [];
colGroupHeader: any;
opened = true;
dataFromChild: any;
showTitle = 'Please Confirm';
height = 450;
selectRowCheckbox = 'CODE';
pageable = {
  pageable: {
    position: 'both'
  },
  pageSize: 2
};
dimension = {
  height: 200,
  width: 200,
  position: 'right'
};
editorCol = {
  title: 'Options',
  width: 150,
  type: 'command',
  openPopUp: false
};
export: {exportto: boolean, fileName: string} = {
  exportto : true,
  fileName : 'TestingKendo'
};
notify!: {content: string, style: string};

  constructor(private service: DataService, private factoryResolvor: ComponentFactoryResolver) {
    this.formControl = new FormGroup({});
   }

  ngOnInit(): void {
    this.getGridData();
  }

getGridData(): void{
  this.service.getTestDecision().subscribe((data: any) => {
this.gridData = data.results;
this.columnHeaders = data.header;
this.colGroupHeader = 'test sample';

this.notify = {
    content: 'Sucessfully fetch data from the server',
    style: 'success',
  };
// {
//   colGroupHeader: true,
//   title: data.type
// };
const formCtrls: any = {};
this.columnHeaders.forEach((item: any) => {
  if (item.field === 'High Value') {
  formCtrls[item.field] = new FormControl(false);
  } else if (item.field === 'Above High AC-Code') {
    formCtrls[item.field] = new FormControl(true);
    }else {
      formCtrls[item.field] = new FormControl(['', Validators.maxLength(3)]);
    }
  this.formControl = new FormGroup(formCtrls);
});
  },
  (err: any) => {
    this.notify = {
        content: '404 error found, please check your Internet Connectivity',
        style: 'error'
      };
  });
}


showpopup(): void {
  this.opened = true;
}

useraction(option: any): void{
  this.opened = false;
}

selectedRowData(data: any): void{
console.log(data);
this.dataFromChild = data.CODE;
if (data[0] === 'openDialog'){
this.opened = true;
}

}

dialogClosed(data: any): void{
this.opened = false;
}
}
