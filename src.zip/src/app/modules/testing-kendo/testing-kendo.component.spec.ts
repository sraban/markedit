import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TestingKendoComponent } from './testing-kendo.component';

describe('TestingKendoComponent', () => {
  let component: TestingKendoComponent;
  let fixture: ComponentFixture<TestingKendoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TestingKendoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TestingKendoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
