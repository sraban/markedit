import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProgramStandardComponent } from './search-prodtrack/program-standard/program-standard.component';
import { PspHomeRoutingModule } from './psp-home-routing.module';
import { PspHomeComponent } from './psp-home.component';
import { SideMenuComponent } from './side-menu/side-menu.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { SearchComponent } from './search-prodtrack/search.component';
import { FacilityComponent } from './search-prodtrack/facility/facility.component';
import { PspBaseService } from './services/psp-base.service';
import { TranslateModule } from '@ngx-translate/core';
import { AppSharedModule } from '../../app-shared/app-shared.module';
import { DietarySupplementsComponent } from './search-prodtrack/dietary-supplements/dietary-supplements.component';
import { FoodMaterialComponent } from './search-prodtrack/food-material/food-material.component';
import { CasChemicalComponent } from './search-prodtrack/cas-chemical/cas-chemical.component';
import { CvvComponent } from './search-prodtrack/cvv/cvv.component';
import { BrakeFrictionComponent } from './search-prodtrack/brake-friction/brake-friction.component';
import { DateInputsModule } from '@progress/kendo-angular-dateinputs';
import { DialogsModule } from '@progress/kendo-angular-dialog';
import { GridModule } from '@progress/kendo-angular-grid';
import { LabelModule } from '@progress/kendo-angular-label';
import { InputsModule, TextBoxModule } from '@progress/kendo-angular-inputs';
import {  PDFModule } from '@progress/kendo-angular-grid';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DropDownsModule } from '@progress/kendo-angular-dropdowns';
import { PanelBarModule } from '@progress/kendo-angular-layout';
import { SubHeaderComponent } from './sub-header/sub-header.component';
import { WaterAssemblyComponent } from './search-prodtrack/water-assembly/water-assembly.component';
import { DatePipe } from '@angular/common';
import { CreateDccComponent } from './create-dcc/create-dcc.component';
import {  ExcelModule } from '@progress/kendo-angular-grid';
import { ClickOusideDirective } from 'src/app/app-shared/directives/click-ouside.directive';
import { NumbersOnlyDirective } from 'src/app/app-shared/directives/numbers-only.directive';
import { DecimalDirective } from 'src/app/app-shared/directives/decimal.directive';

@NgModule({
  declarations: [
    PspHomeComponent,
    SideMenuComponent,
    DashboardComponent,
    SearchComponent,
    FacilityComponent,
    DietarySupplementsComponent,
    FoodMaterialComponent,
    ProgramStandardComponent,
    CasChemicalComponent,
    CvvComponent,
    BrakeFrictionComponent,
    SubHeaderComponent,
    WaterAssemblyComponent,
    CreateDccComponent,
  ],
  imports: [
    CommonModule,
    PspHomeRoutingModule,
    TranslateModule,
    AppSharedModule,
    DateInputsModule,
    GridModule,
    LabelModule,
    InputsModule,
    FormsModule,
    ReactiveFormsModule,
    DropDownsModule,
    DialogsModule,
    TextBoxModule,
    PDFModule,
    PanelBarModule,
    ExcelModule
  ],
  providers: [ PspBaseService, DatePipe, ClickOusideDirective, NumbersOnlyDirective, DecimalDirective
  ],
})
export class PspHomeModule { }
