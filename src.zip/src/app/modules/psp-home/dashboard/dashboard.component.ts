import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { PspBaseService } from '../services/psp-base.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class DashboardComponent implements OnInit {
  public listItemFlag = false;
  public myselfFlag = false;
  private isActive = new Subject();
  public form: FormGroup;
  public listItems: any;
  public showAlertFlag = false;
  public searchAlertsGridData: any;
  public pageable = {
    pageable: false,
    pageSize: 20,
  };
  public searchAlertHeader: any;
  public toggleNvItems = false;
  public selectItemDropdown: any;
  public loader: any;
  notify: any;
  public showLableRecords = false;
  public defaultItem: any = {
    APPFUPD: null,
    al: '',
    code: null,
    dcc_prefix: null,
    default_Item_Type: null,
    descr: null,
    name: null,
    program: ''
  };

  constructor(
    private formBuilder: FormBuilder,
    private pspBaseService: PspBaseService
  ) {
    this.form = this.formBuilder.group({
      name: new FormControl('', [Validators.required]),
      noOfDays: new FormControl('30', [Validators.required]),
      selectOrgDropdown: [''],
    });
  }
  public formGroup = new FormGroup({
    user: new FormControl('Myself'),
  });

  ngOnInit(): void {
    this.gettingProgramsDropdown();
    this.searchAlertHeader = [
      {
        field: 'INITIALS_DCC',
        header_title: 'Supporting DCC',
        width: 150,
        type: 'link',
      },
      {
        field: 'SUPP_NAME',
        header_title: 'Supplier',
        width: 150,
        type: 'input_text',
      },
      {
        field: 'INITIALS_SUPPORTED_DCC',
        header_title: 'Supported DCC',
        width: 150,
        type: 'link',
      },
      {
        field: 'INITIALS_DCC_STATUS',
        header_title: 'DCC Status',
        width: 150,
        type: 'input_text',
      },
      {
        field: 'INITIALS_DCC_STATUS_DATE',
        header_title: 'DCC Status Date',
        width: 150,
        type: 'input_text',
      },
      {
        field: 'TOX_TIME',
        header_title: 'Time in TOX',
        width: 150,
        type: 'input_text',
      },
      {
        field: 'INITIALS_PLANT',
        header_title: 'Facility #',
        width: 150,
        type: 'input_text',
      },
      {
        field: 'INITIALS_PRODUCT_DCC',
        header_title: 'Product DCC',
        width: 150,
        type: 'link',
      },
      {
        field: 'SUPP_NAME',
        header_title: 'Company Name',
        width: 150,
        type: 'input_text',
      },
      {
        field: 'INITIALS_PRODUCT_STATUS',
        header_title: 'Product Status',
        width: 150,
        type: 'input_text',
      },
      {
        field: 'INITIALS_PRODUCT_STATUS_DATE',
        header_title: 'Product Status Date',
        width: 150,
        type: 'input_text',
      },
      {
        field: 'INITIALS_PROJECT_JOB',
        header_title: 'Review #',
        width: 150,
        type: 'input_text',
      },
      {
        field: 'INITIALS_STD',
        header_title: 'Std',
        width: 150,
        type: 'input_text',
      },
      {
        field: 'INITIALS_ROLE',
        header_title: 'Role',
        width: 150,
        type: 'input_text',
      },
      {
        field: 'ACTIVITY_STATUS',
        header_title: 'Review Status',
        width: 150,
        type: 'input_text',
      },
    ];
  }

  /* To show and hide*/
  myselfValues(val: any): any {
    if (val === 'specificUser') {
      this.myselfFlag = true;
      this.listItemFlag = false;
      this.form.controls.noOfDays.setValue('30');

    } else if (val === 'orgUnit') {
      this.listItemFlag = true;
      this.myselfFlag = false;
      // this.form.reset();
    } else {
      this.listItemFlag = false;
      this.myselfFlag = false;
    }
  }

  /* Getting Select Org dropdown values*/
  public gettingProgramsDropdown(): any {
    const reqObj = {};
    this.pspBaseService
      .getProgramsDropdown(reqObj)
      .pipe(takeUntil(this.isActive))
      .subscribe(
        (response: any) => {
          if (response.status === 'SUCCESS') {
            this.listItems = response.results;
          }
        },
        (err: any) => {}
      );
  }
  /*Getting Show Alert grid response */
  public showAlertsGridConfig(): any {
    this.showAlertFlag = true;
    this.loader = true;

    const formValues = this.form.value;
    const reqObj = {
      CODE: formValues.selectOrgDropdown ? formValues.selectOrgDropdown.al : '',
      INITIALS_USERNAME: formValues.name,
      REQDAYS: formValues.noOfDays ? formValues.noOfDays : 30,
    };
    this.pspBaseService
      .getShowSearchViewAlertsDetails(reqObj)
      .pipe(takeUntil(this.isActive))
      .subscribe(
        (response: any) => {
          if (response.status === 'SUCCESS') {
            if (!response.results.length) {
              this.showLableRecords = true;
              this.showAlertFlag = false;
            }else {
              this.searchAlertsGridData = response.results;
              this.showLableRecords = false;
            }
            this.loader = false;
          }else  {
            this.notify = {
              content: response.results[0].message,
              style: 'error'
            };

            this.loader = false;
          }
          // tslint:disable-next-line:no-unused-expression
          // (err: any) => {
          //   this.notify = {
          //       content: response.results[0].message,
          //       style: 'error'
          //     };

          //   this.loader = false;

          // };
        },
      );
  }

  showAlertsGrid(): any {
    this.showAlertsGridConfig();
  }
}
