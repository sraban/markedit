import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PspHomeComponent } from './psp-home.component';

describe('PspHomeComponent', () => {
  let component: PspHomeComponent;
  let fixture: ComponentFixture<PspHomeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PspHomeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PspHomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
