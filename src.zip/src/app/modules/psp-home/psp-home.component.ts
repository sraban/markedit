import { Component, OnInit, OnChanges, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-psp-home',
  templateUrl: './psp-home.component.html',
  styleUrls: ['./psp-home.component.scss'],
})
export class PspHomeComponent implements OnInit {
  routerNavigation: any;
  hideBreadcrumb = false;

  constructor() {
   }
  public isSidebar = false;
  ngOnInit(): void {

    document.body.addEventListener('click', () => {
      const el:any = document.querySelector(".left-menu-hover-dropdown-content");
      if(el){
        let menuClass:any = el.getAttribute("class");
        menuClass = menuClass.replace('left-menu-hover-dropdown-content','dropdown-content');
        el.setAttribute('class', menuClass);
      }
    }, true); 

  }
}
