import { Component, OnInit, ViewChild } from '@angular/core';
import { PspBaseService } from '../services/psp-base.service';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-sub-header',
  templateUrl: './sub-header.component.html',
  styleUrls: ['./sub-header.component.scss'],
})
export class SubHeaderComponent implements OnInit {
  @ViewChild('menu1') menu!: any;
  private isActive = new Subject();
  public dccValue = '';
  listItems: any;
  public dccValueList: string[] = [];
  isMenuOpen!: boolean;
  display: any;
  toggleFlag: any;
  count = 1;
  constructor(
    private pspBaseService: PspBaseService,
  ) {
  }

  ngOnInit(): void {}

  public gettingRecentDcc(): any {
    const reqObj = {};
    this.pspBaseService
      .getRecentDccInfo(reqObj)
      .pipe(takeUntil(this.isActive))
      .subscribe(
        (response: any) => {
          if (response.status === 'SUCCESS') {
            this.listItems = response.results;
            this.searchDcc();
          }
        },
      );
  }
  mouseEnter(): any {
    this.gettingRecentDcc();
  }
  public searchDcc(): any {
    this.listItems.forEach((data: { dcc: any }) => {
      this.dccValueList.push(data.dcc);
    });
  }
  toggleMenu(): any {
    if (this.count === 1){
      this.display = {
        display: 'block'
      };
      this.count++;
    }
     else if (this.count === 2){
      this.display = {
        display: 'none'
      };
      this.count = 1;
    }
    
  }
  clickOutside(data: any): void {
    if (data === "none"){
      this.display = {
        display: 'none'
      };
    }else if (data === 'changeCount') {
      this.display = {
        display: 'none'
      };
      this.count = 1;
    }
   
  }
}
