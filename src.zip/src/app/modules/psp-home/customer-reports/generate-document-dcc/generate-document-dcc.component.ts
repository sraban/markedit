import { Component, OnInit, Renderer2, ViewChild} from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormArray, FormControl } from '@angular/forms';
import { PanelBarItemModel } from '@progress/kendo-angular-layout';
import { PspBaseService } from '../../services/psp-base.service';
import { forkJoin } from 'rxjs';
import { CellClickEvent, GridComponent } from '@progress/kendo-angular-grid';
import { DataService } from '../../../../common/data.service';
import { TranslateService } from '@ngx-translate/core';

const createFormGroup = (dataItem: any) =>
    new FormGroup({
      textCode: new FormControl(dataItem.textCode),
      description: new FormControl(dataItem.description),
      cellID:new FormControl(dataItem?.cellID)
    });
    const matches = (el: any, selector: any) =>
  (el.matches || el.msMatchesSelector).call(el, selector);


@Component({
  selector: 'app-generate-document-dcc',
  templateUrl: './generate-document-dcc.component.html',
  styleUrls: ['./generate-document-dcc.component.scss'],
})

export class GenerateDocumentDccComponent implements OnInit {
  generateDccDropdown: any = [];
  generateDccForm!: FormGroup;
  public submitted = false;
  public documentItems : any;
  public addressItems : any;
  public loader: any;
  public notify: any;
  public defaultDocument:any = 'MEMO';
  public defaultAddress = 'CUS';
  public view : any=[];
  public formGroup: FormGroup| any;
  public isNew: boolean|any;
  private editedRowIndex: any;
  public docClickSubscription: any;
  public counter: any;
  public facilityStd: any;
  public initialReview: any;
  public signingAuthority: any;
  public textCode: any;
  public searchFacilityHeaders: any;
  public searchInitialHeaders: any;
  public searchSignAuthorityHeaders: any;
  public searchTextCodeHeaders: any;
  public openStdFacility!: boolean;
  public openInitialReview!: boolean;
  public openSigningAuthority!: boolean;
  public openTextCode!: boolean;
  facilityStdTitle = '';
  initialReviewTitle = '';
  signingAuthorityTitle= '';
  openTextCodeTitle='';
  public dataFromStdFacility: any;
  public stdCode: any;
  public cusseq: any;
  public clickedCellIndex: any;
  public selectedTitle: any;
  pageable = {
    pageable: true,
    pageSize: 20,
  };
  public cellClickFormgroup: any;
  public cellClickDataItem: any;
  public cellClickData: any;
  public rindes: any = 0;
  public generateDccData: any;
  public generateDccTranslate: any;
  public uploadSaveUrl = '/reports/uploadDocument';
  filename!: string;
  public uploadedFIleName = '';
  public file!: any;

@ViewChild(GridComponent)
private grid: GridComponent |any ;
  constructor(private formBuilder: FormBuilder, private pspBaseService: PspBaseService, private renderer: Renderer2,
     private dataService:DataService, private translate: TranslateService) {
    
  }

  public get newDccNumbers(): any{
    return this.generateDccForm.get('newDccNumber') as FormArray;
  }

  public items: Array<PanelBarItemModel> = [
    { title: 'Paragraph', content: ['content'], expanded: false } as PanelBarItemModel,
  ];
  

  ngOnInit(): void {
    this.translate.get('generateDcc').subscribe( (text: string) => {
      this.generateDccTranslate = text;
      this.facilityStdTitle = this.generateDccTranslate.facilityStdTitle;
      this.initialReviewTitle = this.generateDccTranslate.initialReviewTitle;
      this.signingAuthorityTitle = this.generateDccTranslate.signingAuthorityTitle;
      this.openTextCodeTitle = this.generateDccTranslate.openTextCodeTitle;
    });

    this.generateDccForm = this.formBuilder.group({
      dccNumber: ['', Validators.required],
      facilityStd: ['', Validators.required],
      initialReview: ['', Validators.required],
      documentDescription: ['', Validators.required],
      newDccNumber : this.formBuilder.array([]),
      documentType: [''],
      addressTo: [''],
      cc: [''],
      subject: [''],
      encl: [''],
      signingAuthority: [''],
  });
    this.searchFacilityHeaders = [
      {
          field: 'plantstd',
          header_title: this.generateDccTranslate.facilityStandard,
          width: 200,
          type: 'input_text'
      },     
      {
          field: 'cusseq',
          header_title: this.generateDccTranslate.customerSeq,
          width: 200,
          type: 'input_text'
      }
  ]

    this.searchInitialHeaders = [
      {
          field: 'pa_project_job',
          header_title: this.generateDccTranslate.projectJob,
          width: 200,
          type: 'input_text'
      } 
  ]

    this.searchSignAuthorityHeaders = [
      {
          field: 'name',
          header_title: this.generateDccTranslate.name,
          width: 200,
          type: 'input_text'
      },
      {
          field: 'username',
          header_title: this.generateDccTranslate.userName,
          width: 200,
          type: 'input_text'
      }
  ]

    this.searchTextCodeHeaders = [
    {
        field: 'code',
        header_title: this.generateDccTranslate.textCode,
        width: 200,
        type: 'input_text'
    },
    {
        field: 'doc_text',
        header_title: this.generateDccTranslate.description,
        width: 200,
        type: 'input_text'
    }
];

    this.generateDccDropdown = [
      {DATA_VALUE : null, DISPLAY_VALUE: 'Generate Customer Reports'}
    ];

    // API integration GenerateDcc Dropdown List
    const documentType = this.pspBaseService.getDropdownAPI( 'reports/documentType', {});
    const addressTo = this.pspBaseService.getDropdownAPI ('reports/toAddress', {});

    forkJoin([documentType, addressTo]).subscribe((data: any) => {
      this.documentItems = data[0].results;
      this.addressItems = data[1].results;
    },
    (err: any) => {
      this.loader = false;
      this.notify =
       {
         style : 'error',
        content : err.statusText
       };

      }
    );

    this.dataService.totaltableData().subscribe((data: any) => {
      this.view = data;
    });

    this.docClickSubscription = this.renderer.listen(
      'document',
      'click',
      this.onDocumentClick.bind(this)
    );
  }

  public addHandler(): void {

    this.formGroup = createFormGroup({
        textCode: '',
        description: '',
    });
    this.isNew = true;
    this.grid.addRow(this.formGroup);    

    this.saveCurrent()
    
}

private closeEditor(): void {

  this.grid.closeRow(this.editedRowIndex);
  this.isNew = false;
  this.editedRowIndex = undefined;
  this.formGroup = undefined;

}
calltt({isEdited, dataItem, rowIndex}: {isEdited: any, dataItem: any, rowIndex: any  }){
  // This is intentional
}

public cellClickHandler({isEdited, dataItem, rowIndex}:  CellClickEvent): void{
if (this.isNew) {
    rowIndex += 1;
    this.cellClickData= rowIndex;
}
this.saveCurrent();

this.formGroup = createFormGroup(dataItem);
this.cellClickData= rowIndex;
this.editedRowIndex = rowIndex;

this.grid.editRow(rowIndex, this.formGroup);

}

public removeHandler({dataItem}:{dataItem:any}) {
  this.dataService.remove(dataItem);
}

saveCurrent(){
  if(this.formGroup){
    this.dataService.save(this.formGroup.value, this.isNew);
    this.closeEditor();
  }
}


cancelHandler(){
  this.closeEditor();
}

private onDocumentClick(e: any): void {
  if (
    this.formGroup &&
    !matches(
      e.target,
      '#productsGrid tbody *, #productsGrid .k-grid-toolbar .k-button'
    )
  ) { // This is intentional
  }
}

public ngOnDestroy(): void {
  this.docClickSubscription();
}

  get f(): any {
    return this.generateDccForm.controls;
}

onSubmit(): any {
  this.submitted = true;

  if (this.generateDccForm.invalid) {
      return;
  }
}


// adding and removing input fields
public addNewDccField(event: any): any{
  const ele = document.getElementsByClassName('addGenerateBtn');
  if(event.target === ele[0].children[0]) {
    this.newDccNumbers.push(this.formBuilder.control(''));
  }
}

 public removeDccField(i: number): any{
  this.newDccNumbers.removeAt(i);
}

public cellCloseHandler(args: any): any {
  const { formGroup } = args;
  if (!formGroup.valid) {
      args.preventDefault();
  } else if (formGroup.dirty) {
      this.dataService.save(this.formGroup.value,this.isNew);
      this.closeEditor()
  }
}

openFacilityStd(){
  
  this.getFacilityStdData()
  setTimeout(()=>{// This is intentional
  },5000)

  this.openStdFacility = true;
}

openInitial(){
  this.getInitialData()
  this.openInitialReview = true;
}

openSignAuthority(){
  this.getSignAuthorityData()
  this.openSigningAuthority = true;
}

openTextCodeDes(){
  this.openTextCode = true;
}

getFacilityStdData(){
  const allDccData=  ([].concat(this.generateDccForm.get('dccNumber')?.value,this.generateDccForm.get('newDccNumber')?.value).filter( x => x))
  let dccListObj= allDccData.map((data,index)=>{
    let obj=
  { 
    index:index+1, 
    dcc:data
  }
   return obj;
  })
  this.loader=true;
  const reqObj = {"dccList":dccListObj,"facility":""};
 this.pspBaseService.facilityStdData(reqObj).subscribe(
  (response: any) => {
    if (response.status === 'SUCCESS') {
        this.loader=false;
        this.facilityStd = response.results;
    }
},
 )
}

getInitialData(){
  const reqObj = 
  {cus_seq : this.cusseq,
  std_code: this.stdCode
}
this.loader= true;
this.pspBaseService.initialReviewData(reqObj).subscribe(
(response: any) => {
  if (response.status === 'SUCCESS') {
      this.initialReview = response.results;
      this.loader= false;
  }
},
)
}

getSignAuthorityData(){
  const reqObj = {};
  this.loader= true;
  this.pspBaseService.signingAuthorityData(reqObj).subscribe(
  (response: any) => {
    if (response.status === 'SUCCESS') {
        this.signingAuthority = response.results;
        this.loader= false;
    }
  },
  )
}


public onFacilityStdClose(): void {
  this.openStdFacility = false;
}

public onInitialClose(): void {
  this.openInitialReview = false;
}

public onSignAuthorityClose(): void {
  this.openSigningAuthority = false;
}

public onTextCodeClose(): void {
  this.openTextCode = false;
}

selectedFacilityType(data: any): void {
  if(this.clickedCellIndex==0){
  this.dataFromStdFacility = data.plantstd;
  this.stdCode=data.std_code;
  this.generateDccForm.controls.facilityStd.patchValue(data.plantstd);
  this.openStdFacility = false;
  this.cusseq=data.cusseq
  }
}

selectedInitialType(data: any): void {
  this.generateDccForm.controls.initialReview.patchValue(data.pa_project_job);
  this.openInitialReview = false;
}

lookUpFacilityStd(event: any){
  this.clickedCellIndex=event.target.cellIndex
}

lookUpSigningAuthority(event: any){
  this.clickedCellIndex=event.target.cellIndex
}

selectedSignAuthorityType(data: any): void {
  if(this.clickedCellIndex==1){
  this.generateDccForm.controls.signingAuthority.patchValue(data.username);
  this.openSigningAuthority = false;
  }
}

selectedTextCodeType(data: any): void {
  this.openTextCode = false;

  let val={
    textCode:data.code,
    description:data.doc_text,
    cellID:this.cellClickData
  }
  
  this.formGroup = createFormGroup(val);

  this.editedRowIndex=this.cellClickData
  this.saveCurrent()
}

textCodeLookup(){
  this.openTextCode = true;
  
this.grid.editRow(this.cellClickData, this.formGroup);
  let docType = {document_type: this.generateDccForm.controls.documentType.value};
  this.pspBaseService.getTextCode(docType).subscribe((data: any) => {
    this.textCode= data.results;
  })
}

generateDocDcc(){
  this.submitted= true;
  let pgraphData= this.view.map((d:any)=>{
    let obj={
     code:d.textCode,
      doc_text:d.description
    }
    return obj;
  })
  let qparams={
  address_to: this.generateDccForm.controls.addressTo.value,
  cc: this.generateDccForm.controls.cc.value,
  dccNos:([].concat(this.generateDccForm.controls.dccNumber.value ,this.generateDccForm.controls.newDccNumber.value).filter( x => x)),
  doc_desc: this.generateDccForm.controls.documentDescription.value,
  doc_type: this.generateDccForm.controls.documentType.value,
  encl:  this.generateDccForm.controls.encl.value,
  facility: this.generateDccForm.controls.facilityStd.value,
  option: "DCC",
  paragraphList: pgraphData,
  project_job: this.generateDccForm.controls.initialReview.value,
  revision_project_job: "",
  signing_authority: this.generateDccForm.controls.signingAuthority.value,
  subject: this.generateDccForm.controls.subject.value,
  }
  let dccNos=([].concat(this.generateDccForm.controls.dccNumber.value ,this.generateDccForm.controls.newDccNumber.value).filter( x => x))
  let dccNumbers=dccNos.map((data:any,index:any)=>{
    let obj={
      index:index+1,
      dcc:data,
    }
    return obj
  })
  const reqObj = {"dccList":dccNumbers};
  this.pspBaseService.getValidateDcc(reqObj).subscribe((data:any)=>{
    if(data.status=== 'SUCCESS'){
      this.pspBaseService.getGenerateDccDoc(qparams).subscribe((response:any)=>{
        if(response.status=== 'SUCCESS'){
          const generateDccData = response.results;
          this.pspBaseService.getDownloadDccDoc(generateDccData).subcribe((dataObj:any)=>{ // This is intentional
          })
        }
        else {
          this.notify = {
            content: response.results[0].message,
            style: 'error'
          };
          this.loader = false;
        }
      })
    }
    else {
      this.notify = {
        content: data.results[0].message,
        style: 'error'
      };
      this.loader = false;
    }
    },
    (err: any) => {
      this.loader = false;
      this.notify =
       {
         style : 'error',
        content : err.statusText
       };
  })
}

onTabSelect(val: any): any {
  this.selectedTitle = val.title;
  this.onReset();
}

onReset(): any {
  this.submitted = false;
  this.generateDccForm.reset();
  this.file = '';
  this.uploadedFIleName = '';
  this.generateDccForm.controls.documentType.patchValue("MEMO");
  this.generateDccForm.controls.addressTo.patchValue('CUS');
  this.notify= {};
}

upload(event:any): any{
  this.file= event.target.files[0];
  this.uploadedFIleName= this.file.name;
  
}
finalData:any;
oNclickUpload(){
  const uploadFileDta= new FormData();
  uploadFileDta.append('file',this.file,this.file.name)
  let pgraphData= this.view.map((d:any) => {
    let obj={
     code:d.textCode,
      doc_text:d.description
    }
    return obj;
  })
  let qparams={
    address_to: this.generateDccForm.controls.addressTo.value,
    cc: this.generateDccForm.controls.cc.value,
    dccNos:([].concat(this.generateDccForm.controls.dccNumber.value ,this.generateDccForm.controls.newDccNumber.value).filter( x => x)),
    doc_desc: this.generateDccForm.controls.documentDescription.value,
    doc_type: this.generateDccForm.controls.documentType.value,
    encl:  this.generateDccForm.controls.encl.value,
    facility: this.generateDccForm.controls.facilityStd.value,
    option: "DCC",
    paragraphList: pgraphData,
    project_job: this.generateDccForm.controls.initialReview.value,
    revision_project_job: "",
    signing_authority: this.generateDccForm.controls.signingAuthority.value,
    subject: this.generateDccForm.controls.subject.value,
    }
    let val= Object.entries(qparams).map((element:any) => {
              let data=  element[0] +"="+element[1]+"&"
    return data })
    let fData=(Object.values(val).join(',').replace(/,/g,''))
    uploadFileDta.append('data',fData)
  this.pspBaseService.getUploadDocument(uploadFileDta).subscribe((data:any)=>{ // This is intentional
  });
}
}
