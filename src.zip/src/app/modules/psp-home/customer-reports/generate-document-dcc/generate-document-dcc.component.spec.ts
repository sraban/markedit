import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GenerateDocumentDccComponent } from './generate-document-dcc.component';

describe('GenerateDocumentDccComponent', () => {
  let component: GenerateDocumentDccComponent;
  let fixture: ComponentFixture<GenerateDocumentDccComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GenerateDocumentDccComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GenerateDocumentDccComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
