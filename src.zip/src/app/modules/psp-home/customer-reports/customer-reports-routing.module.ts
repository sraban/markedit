import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { GenerateURFARFComponent } from './generate-urf-arf/generate-urf-arf.component';
import { CustomerReportsComponent } from './customer-reports.component';
import { GenerateDocumentDccComponent } from './generate-document-dcc/generate-document-dcc.component';
const routes: Routes = [
{
  path: '',
  component: CustomerReportsComponent,
  children: [
    { path: '', redirectTo: 'generateARF', pathMatch: 'full' },
    { path: 'generateARF', component: GenerateURFARFComponent },
    { path: 'generateDcc', component: GenerateDocumentDccComponent},
  ]
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CustomerReportsRoutingModule { }
