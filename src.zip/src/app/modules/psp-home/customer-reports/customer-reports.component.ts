import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-customer-reports',
  templateUrl: './customer-reports.component.html',
  styleUrls: ['./customer-reports.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class CustomerReportsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
