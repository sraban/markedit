import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { PspBaseService } from '../../services/psp-base.service';
import { forkJoin } from 'rxjs';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-generate-document-revision',
  templateUrl: './generate-document-revision.component.html',
  styleUrls: ['./generate-document-revision.component.scss']
})
export class GenerateDocumentRevisionComponent implements OnInit {
  generateDccDropdown: any = [];
  generateRevisionForm!: FormGroup;
  public documentItems : any;
  public addressItems : any;
  public revisionInitialReview: any;
  public defaultDocument = 'MEMO';
  public defaultAddress = 'CUS';
  public revisionSigningAuthority: any;
  openRevisionInitialReview!: boolean;
  openRevisionSigningAuthority!: boolean;
  public loader: any;
  public notify: any;
  public controlNames: any;
  public submitted = false;
  revisionInitialReviewTitle = '';
  revisionSigningAuthorityTitle = '';
  public searchRevisionInitialHeaders: any;
  public searchRevisionSignAuthorityHeaders: any;
  public generateRevisionTranslate: any;
  public projectJobData: any;
  public uploadedFIleName='';
  public file!:any;
  public clickedCellIndex: any;
  pageable = {
    pageable: true,
    pageSize: 25,
  };

  constructor(private formBuilder: FormBuilder, private pspBaseService: PspBaseService, private translate: TranslateService) { }

  ngOnInit(): void {
    this.translate.get('generateDcc').subscribe( (text: string) => {
      this.generateRevisionTranslate = text;
      this.revisionInitialReviewTitle = this.generateRevisionTranslate.revisionInitialReviewTitle;
      this.revisionSigningAuthorityTitle = this.generateRevisionTranslate.revisionSigningAuthorityTitle;
    });

    this.generateRevisionForm = this.formBuilder.group({
      revisonInitialReview: ['', Validators.required],
      revisionDocumentType: [''],
      revisionAddressTo: [''],
      revisionCc: [''],
      revisionSubject: [''],
      revisionEncl: [''],
      revisionSigningAuthority: [''],
      revisionDocumentDescription: ['', Validators.required],
  });
  this.controlNames = {
    revisonInitialReview: 'Initial Review',
    revisionDocumentDescription: 'Document Description'
  }

  this.searchRevisionInitialHeaders= [
    {
      field: 'pa_project_job',
      header_title: this.generateRevisionTranslate.revisonProjectJob,
      width: 200,
      type: 'input_text'
  },     
  {
      field: 'ia_seq',
      header_title: this.generateRevisionTranslate.revisonProjectJob,
      width: 200,
      type: 'input_text'
  }
  ]

  this.searchRevisionSignAuthorityHeaders = [
    {
        field: 'name',
        header_title: this.generateRevisionTranslate.revisionName,
        width: 200,
        type: 'input_text'
    },     
    {
        field: 'username',
        header_title: this.generateRevisionTranslate.revisionUserName,
        width: 200,
        type: 'input_text'
    }
]

  this.generateDccDropdown = [
    {DATA_VALUE : null, DISPLAY_VALUE: 'Generate Customer Reports'}
  ];

  // API integration GenerateRevision Dropdown List
  const documentType = this.pspBaseService.getDropdownAPI( 'reports/documentType', {});
  const addressTo = this.pspBaseService.getDropdownAPI ('reports/toAddress', {});

  forkJoin([documentType, addressTo]).subscribe((data: any) => {
    this.documentItems = data[0].results;
    this.addressItems = data[1].results;

  },
  (err: any) => {
    this.loader = false;
    this.notify =
     {
       style : 'error',
      content : err.statusText
     };

    });
  }

  getRevisionInitialData(){
    const reqObj = {};
    this.loader= true;
  this.pspBaseService.getRevisionInitialReview(reqObj).subscribe(
  (response: any) => {
    if (response.status === 'SUCCESS') {
        this.loader= false;
        this.revisionInitialReview = response.results;
    }
  },
  )
  }

  getRevisionSigningAuthData(){
    const reqObj = {};
    this.loader= true;
  this.pspBaseService.signingAuthorityData(reqObj).subscribe(
  (response: any) => {
    if (response.status === 'SUCCESS') {
        this.loader= false;
        this.revisionSigningAuthority = response.results;
    }
  },
  )
  }

  openRevisionInitial(){
    this.getRevisionInitialData()
    this.openRevisionInitialReview = true;
  }

  public onRevisionInitialClose(): void {
    this.openRevisionInitialReview = false;
  }

  lookUpRevisionInitialReview(event: any){
    this.clickedCellIndex=event.target.cellIndex
  }

  selectedRevisionInitialType(data: any): void {
    if(this.clickedCellIndex==1){
      this.generateRevisionForm.controls.revisonInitialReview.patchValue(data.ia_seq);
      this.projectJobData = data.pa_project_job;
      this.openRevisionInitialReview = false;
    }
    else if(this.clickedCellIndex==0){
      this.generateRevisionForm.controls.revisonInitialReview.patchValue(data.pa_project_job);
      this.projectJobData = data.pa_project_job;
      this.openRevisionInitialReview = false;
    }
  }

  openRevisionSigningAuth(){
    this.getRevisionSigningAuthData()
    this.openRevisionSigningAuthority = true;
  }

  public onRevisionSignAuthorityClose(): void {
    this.openRevisionSigningAuthority = false;
  }

  lookUpRevisionSignAuthority(event: any){
    this.clickedCellIndex=event.target.cellIndex
  }
  selectedRevisionSignAuthorityType(data: any): void {
    if(this.clickedCellIndex==1){
    this.generateRevisionForm.controls.revisionSigningAuthority.patchValue(data.username);
    this.openRevisionSigningAuthority = false;
    }
  }

  generateDocDcc(){
    this.submitted= true;
      const qparams={
      address_to: this.generateRevisionForm.controls.revisionAddressTo.value,
      cc: this.generateRevisionForm.controls.revisionCc.value,
      doc_desc: this.generateRevisionForm.controls.revisionDocumentDescription.value,
      doc_type: this.generateRevisionForm.controls.revisionDocumentType.value,
      encl:  this.generateRevisionForm.controls.revisionEncl.value,
      option: "REVISION",
      // paragraphList: "",
      revision_project_job: this.projectJobData,
      signing_authority: this.generateRevisionForm.controls.revisionSigningAuthority.value,
      subject: this.generateRevisionForm.controls.revisionSubject.value,
      }

    this.pspBaseService.getGenerateDccDoc(qparams).subscribe((response:any)=>{
      if(response.status=== 'SUCCESS'){ // This is intentional
      }
      else {
        this.notify = {
          content: response.results[0].message,
          style: 'error'
        };
        this.loader = false;
      }      
    },
    (err: any) => {
      this.loader = false;
      this.notify =
       {
         style : 'error',
        content : err.statusText
       };
    })
  }

  onReset(): any {
    this.submitted = false;
    this.generateRevisionForm.reset();
    this.file = '';
    this.uploadedFIleName = '';
    this.notify= {};
    this.generateRevisionForm.controls.revisionDocumentType.patchValue("MEMO");
    this.generateRevisionForm.controls.revisionAddressTo.patchValue('CUS');
  }

  upload(event:any): any{
    this.file= event.target.files[0];
    this.uploadedFIleName= this.file.name;
    
  }

  finalData:any;
  oNclickUpload(){
  const uploadFileDta= new FormData();
  uploadFileDta.append('file',this.file,this.file.name)
    const qparams={
    address_to: this.generateRevisionForm.controls.revisionAddressTo.value,
    cc: this.generateRevisionForm.controls.revisionCc.value,
    doc_desc: this.generateRevisionForm.controls.revisionDocumentDescription.value,
    doc_type: this.generateRevisionForm.controls.revisionDocumentType.value,
    encl:  this.generateRevisionForm.controls.revisionEncl.value,
    option: "REVISION",
    paragraphList: "",
    revision_project_job: this.projectJobData,
    signing_authority: this.generateRevisionForm.controls.revisionSigningAuthority.value,
    subject: this.generateRevisionForm.controls.revisionSubject.value,
    }
    let val= Object.entries(qparams).map((element:any) => {
              let data=  element[0] +"="+element[1]+"&"
    return data })
    let fData=(Object.values(val).join(',').replace(/,/g,''))
    uploadFileDta.append('data',fData)
    this.pspBaseService.getUploadDocument(uploadFileDta).subscribe((data:any)=>{
      if(data.status=== 'SUCCESS'){ // This is intentional
      }
      else {
        this.notify = {
          content: data.results[0].message,
          style: 'error'
        };
        this.loader = false;
      } 
    },
    (err: any) => {
    this.loader = false;
    this.notify =
     {
       style : 'error',
      content : err.statusText
     };
  })
}

}
