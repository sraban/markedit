import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GenerateDocumentRevisionComponent } from './generate-document-revision.component';

describe('GenerateDocumentRevisionComponent', () => {
  let component: GenerateDocumentRevisionComponent;
  let fixture: ComponentFixture<GenerateDocumentRevisionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GenerateDocumentRevisionComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GenerateDocumentRevisionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
