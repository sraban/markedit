import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GenerateURFARFComponent } from './generate-urf-arf.component';

describe('GenerateURFARFComponent', () => {
  let component: GenerateURFARFComponent;
  let fixture: ComponentFixture<GenerateURFARFComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GenerateURFARFComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GenerateURFARFComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
