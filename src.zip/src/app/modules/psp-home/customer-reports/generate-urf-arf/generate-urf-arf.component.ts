import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { PspBaseService } from '../../services/psp-base.service';
import { FormGroup, FormBuilder } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';


@Component({
  selector: 'app-generate-urf-arf',
  templateUrl: './generate-urf-arf.component.html',
  styleUrls: ['./generate-urf-arf.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class GenerateURFARFComponent implements OnInit {
  reportsDropdown: any = [];
  showGrid = false;
  gridData: any = [];
  gridHeaders: any = [];
  public defaultItem: any = {
    DISPLAY_VALUE: 'Generate Customer Reports',
    DATA_VALUE: null,
  };
  dccForm!: FormGroup;
  pagination = false;
  pageSize: any = 20;
  selectorCheckBox = true;
  private rowsSelected: number[] = [];
  allRowsSelected = false;
  notify: any;
  public generateForm!: FormGroup;
   // preview report declartion
   itemSeq: any;
   cusSeq: any;
   seq: any;
   iactSeq: any;
   dcc: any;
   matDcc: any;
   matDccSeq: any;
   public loader = false;
   systemFlag: any;
   public checkAll = {
    value: false,
  };
  // tslint:disable-next-line:ban-types
  checkCondition: any = 'Check All';
  successMsg = '';
  opened = false;
  showTitle = '';
  reportsTranslate: any;
  constructor(private formBuilder: FormBuilder, private pspBaseService: PspBaseService, private translate: TranslateService) { }

  ngOnInit(): void {
    this.reportsDropdown = [
      {DATA_VALUE : null, DISPLAY_VALUE: 'Generate Customer Reports'}
    ];
    this.dccForm = this.formBuilder.group({
      dccVal: ['']
    });
    this.generateForm = this.formBuilder.group({
      letters: [''],
      partList: [''],
      formulation: [''],
      summary: [''],
      foodZone: ['']
    });
    this.gridHeaders = [
      {field: 'plant', header_title: 'Facility #', width: 130, type: 'input_text' },
      {field: 'standards', header_title: 'Std', width: 130,  type: 'input_text'},
      {field: 'product_status', header_title: 'Product Status', width: 130, type: 'input_text'},
      {field: 'projectjob', header_title: 'ProdTrack Review #', width: 130,  type: 'input_text'},
      {field: 'revision_reason', header_title: 'Reason for Revision', width: 130, type: 'input_text'},
      {field: 'mat_dcc', header_title: 'Material Dcc', width: 130,  type: 'input_text'},
      {field: 'generate_flg', header_title: 'Generate', width: 130,  type: 'checkbox'},
    ];
    this.translate.get('reports').subscribe( (text: string) => {
      this.reportsTranslate = text;
    });
  }
  checkAllFunc(): any {
    const val = this.checkAll.value;
    if (val) {
      this.gridData.forEach((element: any) => {
       element.generate_flg = true;
       this.checkCondition = this.reportsTranslate.uncheckAll;
      });
    }
    else {
      this.gridData.forEach((element: any) => {
        element.generate_flg = false;
        this.checkCondition = this.reportsTranslate.checkAll;
       });
    }
  }
  generateArfUrf(): any {
    const reqObj = {
      dcc_number: this.dccForm.value.dccVal
    };
    this.pspBaseService.getCustomerReports(reqObj).subscribe((response: any) => {
      if (response.status === 'SUCCESS') {
        this.checkAll.value = false;
        this.gridData = response.results;
        const gridDetails = this.gridData[0];
        this.itemSeq = gridDetails.itm_seq;
        this.cusSeq = gridDetails.cus_seq;
        this.seq = gridDetails.seq;
        this.iactSeq = gridDetails.iact_seq;
        this.dcc = gridDetails.dcc;
        this.matDcc = gridDetails.mat_dcc;
        this.matDccSeq = gridDetails.mat_dcc_seq;
        this.systemFlag = gridDetails.system_flg;
        (gridDetails.inhletters === 'N') ? this.generateForm.controls.letters.setValue(false)
          : this.generateForm.controls.letters.setValue(true);
        (gridDetails.inhwetted === 'N') ? this.generateForm.controls.partList.setValue(false)
          : this.generateForm.controls.partList.setValue(true);
        (gridDetails.inhformulation === 'N') ? this.generateForm.controls.formulation.setValue(false)
          : this.generateForm.controls.formulation.setValue(true);
        (gridDetails.inhperformancesummary === 'N') ? this.generateForm.controls.summary.setValue(false)
          : this.generateForm.controls.summary.setValue(true);
        (gridDetails.inhfzpl === 'N') ? this.generateForm.controls.foodZone.setValue(false)
          : this.generateForm.controls.foodZone.setValue(true);

        if (gridDetails.inhletters === 'N') {
          this.generateForm.controls.letters.disable();
        }
        else {
          this.generateForm.controls.letters.enable();
        }
        if (gridDetails.inhwetted === 'N') {
          this.generateForm.controls.partList.disable();
        }
        else {
          this.generateForm.controls.partList.enable();
        }
        if (gridDetails.inhformulation === 'N') {
          this.generateForm.controls.formulation.disable();
        }
        else {
          this.generateForm.controls.formulation.enable();
        }
        if (gridDetails.inhperformancesummary === 'N') {
          this.generateForm.controls.summary.disable();
        }
        else {
          this.generateForm.controls.summary.enable();
        }
        if (gridDetails.inhfzpl === 'N') {
          this.generateForm.controls.foodZone.disable();
        }
        else {
          this.generateForm.controls.foodZone.enable();
        }
        this.showGrid = true;
        if (this.gridData.length > 10 ) {
          this.pagination = true;
        }
        this.notify = {};
      }
      else {
        this.notify = {
          content: response.results[0].message,
          style: 'error'
        };
        this.showGrid = false;
      }
      // (err: any) => {
      //   this.notify = {
      //       content: response.results[0].message,
      //       style: 'error'
      //     };
      // };
    });
  }

  selectRow(): void {
     const gridCount = this.gridData.length;
     const gridChecked: any = [];
     this.gridData.forEach((element: any, index: number) => {
       if (element.generate_flg === true || element.generate_flg === 'Y') {
         gridChecked.push(element);
       }
       if (gridCount === gridChecked.length) {
          this.checkAll.value = true;
          this.checkCondition = this.reportsTranslate.uncheckAll;
       }
       else {
          this.checkAll.value = false;
          this.checkCondition = this.reportsTranslate.checkAll;
       }
     });
  }
  public get getf(): any {
    return this.generateForm.value;
  }
  clearDcc(): any {
      this.dccForm.reset();
      this.notify = {};
      this.showGrid = false;
  }
  generateChange(event: any): any {
  console.log(event);
  }
  generateReport(): any {
    const resultList: any = [];
    this.gridData.forEach((element: any) => {
      if (element.generate_flg === true || element.generate_flg === 'Y') {
        element.generate_flg = 'Y';
        resultList.push(element);
      }
    });
    const reqObj = {
      resultList
    };
    this.loader = true;
    this.pspBaseService.generateReport(reqObj).subscribe((response: any) => {
      if (response.status === 'SUCCESS') {
        this.merge(response.results[0], 'generate');
      }
      else {
        this.notify = {
          content: response.results[0].message,
          style: 'error'
        };
      }
    });
  }
  previewReport(i: any): any {
    const formData = this.generateForm.controls;
    if (this.dcc.toUpperCase().indexOf('FA') >= 0 && (this.matDcc === '' || this.matDcc === null)){
      this.notify = {
        content: this.reportsTranslate.materialDccNotSelected,
        style: 'error'
      };
    }
    const reqObj = {
      seq: this.seq,
      itm_seq: this.itemSeq,
      cus_seq: this.cusSeq,
      iact_seq: this.iactSeq,
      plant: this.gridData[i].plant,
      standards: this.gridData[i].standards,
      dcc: this.dcc,
      mat_dcc: this.matDcc,
      mat_dcc_seq: this.matDccSeq,
      system_flg: this.systemFlag,
      chkletters: formData.letters.value === false ? 'N' : 'Y',
      chkwetted: formData.partList.value === false ? 'N' : 'Y',
      chkformulation: formData.formulation.value === false ? 'N' : 'Y',
      chkperformancesummary: formData.summary.value === false ? 'N' : 'Y',
      chkfzpl: formData.foodZone.value === false ? 'N' : 'Y',
    };
    this.loader = true;
    this.pspBaseService.previewReport(reqObj).subscribe((response: any) => {
      if (response.status === 'SUCCESS') {
        this.merge(response.results, 'preview');
      }
      else {
        this.notify = {
          content: response.results[0].message,
          style: 'error'
        };
      }
    });
  }

    merge(responseReport: any, reportType: string): any {
      const req = {
        repId : responseReport,
        generateOrPreview: reportType
      };
      if (reportType === 'preview') {
        this.pspBaseService.merge(req).subscribe((response: any) => {
          if (response) {
            this.loader = false;
            const file = new Blob([response], {
              type: 'application/pdf'
          });
            const fileURL = URL.createObjectURL(file);
            window.open(fileURL);
          }
          // else if (response.status === 'ERROR') {
          //   this.notify = {
          //     content: response.results[0].message,
          //     style: 'error'
          //   };
          // }
      });
    }
    else if (reportType === 'generate') {
      this.pspBaseService.mergeGenerate(req).subscribe((response: any) => {
        if (response.status === 'SUCCESS') {
          this.loader = false;
          this.opened = true;
          this.showTitle = 'Success';
          this.successMsg = this.reportsTranslate.recordInsertedSuccessfully;
        }
        else {
          this.loader = false;
          this.notify = {
            content: response.results[0].message,
            style: 'error'
          };
        }
      });
    }
  }

  dialogClose(): any {
    this.opened = false;
  }
}
