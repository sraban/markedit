import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CustomerReportsRoutingModule } from './customer-reports-routing.module';
import { GenerateURFARFComponent } from './generate-urf-arf/generate-urf-arf.component';
import { GenerateDocumentDccComponent } from './generate-document-dcc/generate-document-dcc.component';
import { GenerateDocumentRevisionComponent } from './generate-document-revision/generate-document-revision.component';
import { TranslateModule } from '@ngx-translate/core';
import { LabelModule } from '@progress/kendo-angular-label';
import { InputsModule } from '@progress/kendo-angular-inputs';
import { CustomerReportsComponent } from './customer-reports.component';
import { DropDownsModule } from '@progress/kendo-angular-dropdowns';
import { GridModule } from '@progress/kendo-angular-grid';
import { AppSharedModule } from '../../../app-shared/app-shared.module';
import { PspBaseService } from '../services/psp-base.service';
import { DialogsModule } from '@progress/kendo-angular-dialog';



@NgModule({
  declarations: [
    GenerateURFARFComponent,
    GenerateDocumentDccComponent,
    GenerateDocumentRevisionComponent,
    CustomerReportsComponent,
  ],
  imports: [
    CommonModule,
    CustomerReportsRoutingModule,
    TranslateModule,
    InputsModule,
    LabelModule,
    DropDownsModule,
    GridModule,
    AppSharedModule,
    DialogsModule
    
  ],
  providers: [ PspBaseService ],
})
export class CustomerReportsModule { }
