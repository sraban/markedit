export const constObj = {
    // customer Reports
    reports: {
        getCustomerReport: 'reports/getCustomerReport',
        generateCustomerReport: 'reports/generateCustomerReport',
        previewReport: 'reports/previewReport',
        mergeReport: 'reports/merge',
        bracketingDCC: 'reports/BracketingDCC',
        getStatusBracketingTool: 'reports/getStatusBracketingTool',
        bracketingTool: 'reports/bracketingTool',
        fetchOrderByValuesProdDcc: 'reports/fetchOrderByValuesProdDcc',
        ProductDcc: 'reports/ProductDcc',
        filename: 'reports/filename',
        generateDcc: {
            facilityStdLookup: 'reports/facilityAndStandardLookup',
            initialReviewLookup: 'reports/projectJobLookup',
            signingAuthorityLookup: 'reports/signingAuthorityLookup',
            textCodeLookup: 'reports/textCodeLookup',
            validateDcc: 'reports/validateDcc',
            generateDccDoc: 'reports/generateDocument',
            downloadDccDoc: 'reports/downloadDocument',
            revisionInitialReview: 'reports/revisionProjectJobLookup',
            uploadDocument: 'reports/uploadDocument'
        }
    },
    // Header
    getRecentDcc: 'dcc/getRecentDccInfo',
    // dashboard
    programsDropdown: 'dashboard/programsDropdown',
    searchViewAlerts: 'dashboard/searchViewAlerts',

    // Create DCC
    ProductDccPrefix: 'dcc/prefixLookup',
    ProductInitialReview: 'dcc/initialReviewLookup',
    NonProductDccPrefix: 'dcc/nonProductPrefixLookup',
    ProductFacilityLookup: 'dcc/facilityLookup',
    ProductStandardLookup: 'dcc/standardLookup',
    NonProductSupportDcc: 'dcc/checkSupportedDCCStatus',

    // LookupNames with variable request
    lookupNames: 'lookupNames',
    // Search Prodtrack section API's
    searchProdtrack: {
        programStandard: {
            standardLookup: 'dcc/searchTool/standardLookup',
            programsLookup: 'dcc/searchTool/programsLookup',
        },
        dietarySupplements: {
            classificationLookup: 'dcc/dietarySupplements/classificationDetails/codeLookUp',
        },
    },
    // Masters screen CRUD API's
    masters: {
        analytes: {
            search: 'master/analyteType/search',
            create: 'master/analyteType/create',
            update: 'master/analyteType/update',
            delete: 'master/analyteType/delete',
            analysisLookup: 'master/analyteType/analysisLookUp',
            prepcodeLookup: 'master/analyteType/prepCodeLookUp',
        },
        assessmentCodes: {
            search: 'master/assessmentCodeType/search',
            create: 'master/assessmentCodeType/create',
            update: 'master/assessmentCodeType/update',
            delete: 'master/assessmentCodeType/delete',
            dropdownLookup: 'master/assessmentCodeType/typeLookUp',
        },
        functionMaster: {
            search: 'master/functionMaster/search',
            create: 'master/functionMaster/create',
            update: 'master/functionMaster/update',
            delete: 'master/functionMaster/delete',
        },
        categoryMaster: {
            search: 'master/categoryType/search',
            create: 'master/categoryType/create',
            update: 'master/categoryType/update',
            delete: 'master/categoryType/delete'
        },
        chemicalMaster: {
            search: 'master/chemicals/search',
            save: 'master/chemicals/save',
            delete: 'master/chemicals/delete',
            get: 'master/chemicals/get',
            getdecisionCode: 'master/testDecisions/search'
        },
        systemType: {
            search: 'master/systemType/search',
            create: 'master/systemType/create',
            update: 'master/systemType/update',
            delete: 'master/systemType/delete'
        },
        nonfoodCategory: {
            search: 'master/nonFoodCategory/search',
            create: 'master/nonFoodCategory/create',
            update: 'master/nonFoodCategory/update',
            delete: 'master/nonFoodCategory/delete'
        },
        enduseMaster: {
            search: 'master/euMasterType/search',
            create: 'master/euMasterType/create',
            update: 'master/euMasterType/update',
            delete: 'master/euMasterType/delete'
        },
        performanceStandard: {
            search: 'master/performanceStandardType/search',
            create: 'master/performanceStandardType/create',
            update: 'master/performanceStandardType/update',
            delete: 'master/performanceStandardType/delete',
        },
        documentText: {
            search: 'master/documentText/search',
            create: 'master/documentText/create',
            update: 'master/documentText/update',
            delete: 'master/documentText/delete',
            dropdown: 'lookupNames'
        },
        materialType: {
            search: 'master/materialType/search',
            create: 'master/materialType/create',
            update: 'master/materialType/update',
            delete: 'master/materialType/delete'
        },
        foodMaterial: {
            search: 'master/reductionClaimType/search',
            create: 'master/reductionClaimType/create',
            update: 'master/reductionClaimType/update',
            delete: 'master/reductionClaimType/delete'
        },
        reductionClaim: {
            search: 'master/reductionClaimType/search',
            create: 'master/reductionClaimType/create',
            update: 'master/reductionClaimType/update',
            delete: 'master/reductionClaimType/delete'
        },
        testDecisions: {
            search: 'master/testDecisions/search',
            create: 'master/testDecisions/save',
            update: 'master/testDecisions/save',
            delete: 'master/testDecisions/delete',
            get: 'master/testDecisions/get',
            searchAssementCodeType: 'master/assessmentCodeType/search',
            testingTypeDropdown: 'lookupNames',
            analyteCodeDescription: 'master/analyteType/search'
        },
        rawMaterialNumber: {
            search: 'master/rawMaterialNumber/search',
            corporate: 'master/rawMaterialNumber/getCorporateAndProgramValidation',
            create: 'master/rawMaterialNumber/save',
            update: 'master/rawMaterialNumber/update',
            delete: 'master/rawMaterialNumber/delete',
            addRow: 'master/rawMaterialNumber/searchRmWithCorporate'
        },
        foodContactType: {
            search: 'master/foodContactType/search',
            create: 'master/foodContactType/create',
            update: 'master/foodContactType/update',
            delete: 'master/foodContactType/delete'
        },
        resinTypes: {
            search: 'master/resinType/search',
            create: 'master/resinType/create',
            update: 'master/resinType/update',
            delete: 'master/resinType/delete'
        },
        noteMaster: {
            search: 'master/noteMasterType/search',
            create: 'master/noteMasterType/create',
            update: 'master/noteMasterType/update',
            delete: 'master/noteMasterType/delete',
            noteType: 'master/noteMasterType/noteType',
            noteStandardGroup: 'master/noteMasterType/noteStandardGroup',
            noteStandard: 'master/noteMasterType/noteStandard'
        }
    },
    // Admin screen
    admin: {
        dccstatuschange: {
            searchDcc: 'admin/dccstatuschange/searchDcc',
            searchFacility: 'admin/dccstatuschange/searchFacility',
            searchInitialReview: 'admin/dccstatuschange/searchInitialReview',
            save: 'admin/dccstatuschange/save'
        },
        changeCorporate: {
            searchCorporate: 'customer/searchCorporate',
            getAssociatedDccByCorporate: 'dcc/admin/getAssociatedDccByCorporate',
            updateAssociatedDccByCorporate: 'dcc/admin/updateAssociatedDccByCorporate'
        },
        changeItemType :{
            getDccInfo :'dcc/itemInfo/getDCCInfo',
            dccChangeItemType: 'dcc/admin/dccChangeItemType/get',
            getItemTypeDropDown:'dcc/admin/dccChangeItemType/getItemTypeDropDown',
            save:'dcc/admin/dccChangeItemType/save'
        },
        exportFormulation:{
            isValidDcc:'isValidDcc',
            export:'export',
            getDspSeqNos:'getDspSeqNos'
        }
    },
    trackingReports:{
        nonFoodReviewLog:{
            programDropdown:'reports/programDropDown',
            programStatus:'reports/programStatus',
            revisionStatus:'reports/revisionStatus',
            dccStatus:'reports/dccStatus',
            nonFood:'reports/nonFood'
        }
    },




};

