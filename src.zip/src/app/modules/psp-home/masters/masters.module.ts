import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MastersRoutingModule } from './masters-routing.module';
import { AnalytesComponent } from './analytes/analytes.component';
import { AssessmentCodesComponent } from './assessment-codes/assessment-codes.component';
import { CategoryMasterComponent } from './category-master/category-master.component';
import { ChemicalsComponent } from './chemicals/chemicals.component';
import { DocumentTextComponent } from './document-text/document-text.component';
import { EnduseMasterComponent } from './enduse-master/enduse-master.component';
import { FoodcontactTypeComponent } from './foodcontact-type/foodcontact-type.component';
import { FunctionMasterComponent } from './function-master/function-master.component';
import { MaterialTypesComponent } from './material-types/material-types.component';
import { NonfoodCategoryComponent } from './nonfood-category/nonfood-category.component';
import { PerformanceStandardComponent } from './performance-standard/performance-standard.component';
import { RawmaterialNumbersComponent } from './rawmaterial-numbers/rawmaterial-numbers.component';
import { ReductionClaimComponent } from './reduction-claim/reduction-claim.component';
import { ResinTypesComponent } from './resin-types/resin-types.component';
import { SystemTypesComponent } from './system-types/system-types.component';
import { TestDecisionsComponent } from './test-decisions/test-decisions.component';
import { TranslateModule } from '@ngx-translate/core';
import { MastersComponent } from './masters.component';
import { PspBaseService } from '../services/psp-base.service';
import { InputsModule } from '@progress/kendo-angular-inputs';
import { LabelModule } from '@progress/kendo-angular-label';
import { DropDownsModule } from '@progress/kendo-angular-dropdowns';
import { ExcelModule, GridModule } from '@progress/kendo-angular-grid';
import { AppSharedModule } from '../../../app-shared/app-shared.module';
import {  PDFModule } from '@progress/kendo-angular-grid';
import { PopupModule } from '@progress/kendo-angular-popup';


@NgModule({
  declarations: [
    AnalytesComponent,
    AssessmentCodesComponent,
    CategoryMasterComponent,
    ChemicalsComponent,
    DocumentTextComponent,
    EnduseMasterComponent,
    FoodcontactTypeComponent,
    FunctionMasterComponent,
    MaterialTypesComponent,
    NonfoodCategoryComponent,
    PerformanceStandardComponent,
    RawmaterialNumbersComponent,
    ReductionClaimComponent,
    ResinTypesComponent,
    SystemTypesComponent,
    TestDecisionsComponent,
    MastersComponent,
  ],
  imports: [
    CommonModule,
    MastersRoutingModule,
    TranslateModule,
    InputsModule,
    LabelModule,
    DropDownsModule,
    GridModule,
    PDFModule,
    AppSharedModule,
   ExcelModule,
   PopupModule
  ],
  providers: [ PspBaseService ],
})
export class MastersModule { }
