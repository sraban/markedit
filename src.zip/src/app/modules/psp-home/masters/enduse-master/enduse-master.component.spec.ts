import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EnduseMasterComponent } from './enduse-master.component';

describe('EnduseMasterComponent', () => {
  let component: EnduseMasterComponent;
  let fixture: ComponentFixture<EnduseMasterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EnduseMasterComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EnduseMasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
