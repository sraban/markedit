import { Component, OnInit, ViewChildren } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { PspBaseService } from '../../services/psp-base.service';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { TranslateService } from '@ngx-translate/core';
import { DataStateChangeEvent, GridComponent, GridDataResult } from '@progress/kendo-angular-grid';
import { exportPDF, Group } from '@progress/kendo-drawing';
import { ExcelExportData } from '@progress/kendo-angular-excel-export';
import { SortDescriptor, State, process } from '@progress/kendo-data-query';
import { ValidationComponent } from '../../../../app-shared/validation/validation.component'
const spaceValidator = new ValidationComponent();


@Component({
  selector: 'app-enduse-master',
  templateUrl: './enduse-master.component.html',
  styleUrls: ['./enduse-master.component.scss']
})
export class EnduseMasterComponent implements OnInit {
  public endUserForm: FormGroup | any;
  showGrid = false;
  public loader: any;
  public notify: any;
  public notifyPopup: any;
  fromSaveDialog = false;
  private isActive = new Subject();
  public pageable = {
    pageable: {
      position: 'both',
    },
    pageSize: 25,
  };
  gridData: any = [];
  gridHeaders: any;
  opened = false;
  gridDataEnable = false;
  public deleteTitleLabel = '';
  createEndUserLabel = '';
  masterTranslate: any;
  commonTranslate: any;
  deletedialogFlag!: boolean;
  dialogFlag = false;
  endUserCreateForm: FormGroup | any;
  submitted = false;
  controlNames: any;
  public deleteCode: any;
  requestDataForDelete: any;
  public isDialog: any = false;
  public handler: any;
  public editedRowIndex: any = null;
  public showLableRecords = true;
  savedialogFlag = false;
  public saveTitleLabel: any;
  public state: State = {
    skip: 0,
    take: 5,
  };
  @ViewChildren(GridComponent)
  public grids: any;
  editorCol = {
    title: 'Actions',
    width: 50,
    type: 'command',
    openPopUp: false,
  };
  export: { exportto: boolean; fileName: string } = {
    exportto: true,
    fileName: 'End Use Master',
  };
  public control: any;
  public allDataSet: GridDataResult = process(this.gridData, this.state);
  public dataStateChange(state: DataStateChangeEvent): void {
    this.state = state;
    this.allDataSet = process(this.gridData, this.state);
  }
  constructor(private pspBaseService: PspBaseService, private formBuilder: FormBuilder,
              private translate: TranslateService) {
  }

  ngOnInit(): void {
    this.initializeForm();
    this.initializeCreateForm();
    this.translate.get('masters').subscribe((text: string) => {
      this.masterTranslate = text;
      this.deleteTitleLabel = this.masterTranslate.deleteConfirmation;
      this.saveTitleLabel = this.masterTranslate.saveConfirmation;
      this.createEndUserLabel = this.masterTranslate.enduser.createEndUser;
    });
    this.translate.get('common').subscribe((text: string) => {
      this.commonTranslate = text;
    });
  }

  initializeForm(): any {
    this.endUserForm = this.formBuilder.group({
      code: new FormControl('', [Validators.required]),
      descr: new FormControl('', [Validators.required]),
    });
    this.controlNames = {
      code: 'Code',
      descr: 'Description'
    };
    this.control = new FormGroup({});
    this.gridHeaders = [
      { field: 'code', header_title: 'Code', width: 150, type: 'input_text', editable: false, maxlength: '20' },
      { field: 'descr', header_title: 'Description', width: 350, type: 'input_text', editable: true, maxlength: '80' },
    ];
  }
  public create(): void {
    (document as any).querySelectorAll('.k-grid-cancel-command').forEach((el: any) => { el.click(); });
    this.dialogFlag = true;
    this.submitted = false;
    this.savedialogFlag = false;
    this.notify = {};
    this.notifyPopup = {};
    this.endUserCreateForm.reset();
  }
  public search(): any {
    (document as any).querySelectorAll('.k-grid-cancel-command').forEach((el: any) => { el.click(); });
    this.showGrid = true;
    const reqObj = {
      code: this.endUserForm.controls.code.value,
      descr: this.endUserForm.controls.descr.value
    };
    this.searchEndUser(reqObj);
  }
  // Search End User
  public searchEndUser(reqObj: any): any {
    this.loader = true;
    this.notify = {};
    this.pspBaseService
      .searchEndUser(reqObj)
      .pipe(takeUntil(this.isActive))
      .subscribe(
        (response: any) => {
          if (response.status === 'SUCCESS') {
            this.gridData = response.results;
            this.loader = false;
            if (this.gridData.length === 0) {
              this.notify = {
                style: 'info',
                content: this.masterTranslate.noRecordsFoundWithTheSearchcriteria
              };
            }
            this.gridDataEnable = true;
          }
          const formCtrls: any = {};
          this.gridHeaders.forEach((item: any) => {
            if (item.field === 'descr') {
              formCtrls[item.field] = new FormControl('',[Validators.required,spaceValidator.noWhitespaceValidator]);
            }
            else {
              formCtrls[item.field] = new FormControl(false);
            }
            this.control = new FormGroup(formCtrls);
          });
        },
        (err: any) => {
          this.loader = false;
          this.notify = {
            style: 'error',
            content: this.commonTranslate.noRecordsFoundWithTheSearchcriteria
          };
        }
      );
  }
  public createEndUser(reqObj: any): any {
    this.submitted = true;
    if (this.endUserCreateForm.valid) {
      this.loader = true;
      this.pspBaseService
        .createEndUser(reqObj)
        .pipe(takeUntil(this.isActive))
        .subscribe(
          (response: any) => {
            this.loader = false;
            if (response.status === 'SUCCESS') {
              this.dialogFlag = false;
              this.submitted = false;
              this.search();
              this.notify = {
                style: 'success',
                content: this.masterTranslate.dataSavedSuccessfully
              };
            } else {
              if (this.fromSaveDialog) {
                this.notifyPopup = {
                  style: 'error',
                  content: response.results[0].message
                };
                this.dialogFlag = true;
                this.submitted = false;
                this.fromSaveDialog = false;
              }
              else {
                this.notifyPopup = {
                  style: 'error',
                  content: response.results[0].message
                };
                this.dialogFlag = true;
              }
            }
          }
        );
    }
  }
  public clear(): any {
    this.endUserForm.reset();
    this.showGrid = false;
    this.notify = {};
  }
  public save(): void {
    this.submitted = true;
    this.endUserCreateForm.markAllAsTouched();
    const reqObj = {
      code: this.endUserCreateForm.controls.code.value,
      descr: this.endUserCreateForm.controls.descr.value,
    };
    this.createEndUser(reqObj);
  }

  initializeCreateForm(): any {
    this.endUserCreateForm = this.formBuilder.group({
      code: new FormControl('', [Validators.required,spaceValidator.noWhitespaceValidator]),
      descr: new FormControl('', [Validators.required,spaceValidator.noWhitespaceValidator]),
    });
    this.controlNames = {
      code: 'Code',
      descr: 'Description'
    };
  }

  public onsaveDialogClose(data: any): any {
    this.savedialogFlag = false;
    if (data === 'Yes') {
      this.save();
      this.fromSaveDialog = true;
      this.dialogFlag = false;
    } else if(data === "No"){
      this.dialogFlag = false;
    }else if(data === "Close"){
      this.dialogFlag = true;
    }
  }

  onDeleteDialogClose(data: any): any {
    this.deletedialogFlag = false;
    if (data === 'Yes') {
      this.onAccept();
    }
  }
  onAccept(): any {
    this.loader = true;
    this.pspBaseService
      .deleteEndUser(this.requestDataForDelete)
      .pipe(takeUntil(this.isActive))
      .subscribe(
        (response: any) => {
          this.loader = false;
          if (response.status === 'SUCCESS') {
            this.deletedialogFlag = false;
            this.notify = {
              content: this.masterTranslate.recordDeletedSuccessfully,
              style: 'success'
            };
            this.gridData = this.gridData.filter((row: any) => {
              if (row.code !== this.requestDataForDelete.code) {
                return row;
              }
            });
          } else {
            this.notify = {
              content: response.results[0].message,
              style: 'error'
            };
            this.deletedialogFlag = false;
          }
        }
      );
  }
  public editHandler(data: any): any {
    if (data[0] === 'editData') {
      this.saveHandler(data[1]);
    } else if (data[0] === 'removeData') {
      this.deletedialogFlag = true;
      this.requestDataForDelete = data[1];
      this.deleteCode = data[1].code;
    }
  }
  // for cancel operation in main grid
  public cancelHandler(handler: any): any {
    this.closeEditor(handler.sender, handler.rowIndex);
  }
  // for saving data in main grid
  public saveHandler(data: any): void {
    this.loader = true;
    this.pspBaseService
      .updateEndUser(data)
      .pipe(takeUntil(this.isActive))
      .subscribe(
        (response: any) => {
          this.loader = false;
          if (response.status === 'SUCCESS') {
            this.search();
            this.showLableRecords = true;
            this.notify = {
              content: this.masterTranslate.dataSavedSuccessfully,
              style: 'success'
            };
          } else {
            this.notify = {
              style: 'error',
              content: response.results[0].message
            };
          }
        },
        (err: any) => {
          this.notify = {
            style: 'error',
            content: err
          };
        }
      );
  }
  // for remove record from main grid
  public removeHandler(handler: any, isDialog?: any): any {
    if (handler && isDialog) {
      this.isDialog = isDialog;
      this.handler = handler;
      return false;
    }
    const product = handler.dataItem;
    this.loader = true;
    this.pspBaseService
      .deleteEndUser(product)
      .pipe(takeUntil(this.isActive))
      .subscribe(
        (response: any) => {
          this.loader = false;
          if (response.status === 'SUCCESS') {
            this.gridData = this.gridData.filter((row: any) => {
              if (row.code !== product.code) {
                return row;
              }
            });
            this.notify = {
              content: 'Record deleted successfully',
              style: 'error'
            };
          } else {
            this.notify = {
              style: 'error',
              content: response.results[0].message
            };
          }
        },
        (err: any) => {
          this.notify =
          {
            style: 'error',
            content: err.statusText
          };
        }
      );
    this.isDialog = false;
  }

  private closeEditor(grid: any, rowIndex = this.editedRowIndex): any {
    grid.closeRow(rowIndex);
  }
  public closeConfirmDialog(status: any): void {
    if (status === 'cancel' || status === 'no') {
      this.isDialog = false;
    }
    if (status === 'yes') {
      this.removeHandler(this.handler);
    }
  }
  public allData(): ExcelExportData {
    const myState: State = this.state;
    myState.skip = 0;
    myState.take = this.allDataSet.total;
    const result: ExcelExportData = {
      data: process(this.gridData, this.state).data
    };
    return result;
  }
  public onDialogClose(): void {
    this.notify = {};
    
    if (this.endUserCreateForm.controls.code.value
      || this.endUserCreateForm.controls.descr.value){
      this.savedialogFlag = true;
    }
    else {
      this.submitted = false;
      this.dialogFlag = false;
    }
  }

}

