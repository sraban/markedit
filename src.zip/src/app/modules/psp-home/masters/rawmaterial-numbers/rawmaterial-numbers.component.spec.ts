import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RawmaterialNumbersComponent } from './rawmaterial-numbers.component';

describe('RawmaterialNumbersComponent', () => {
  let component: RawmaterialNumbersComponent;
  let fixture: ComponentFixture<RawmaterialNumbersComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RawmaterialNumbersComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RawmaterialNumbersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
