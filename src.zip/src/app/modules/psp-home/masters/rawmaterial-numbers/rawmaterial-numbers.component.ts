import { Component, OnInit, ViewChildren } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { PspBaseService } from '../../services/psp-base.service';
import { takeUntil } from 'rxjs/operators';
import { Subject } from 'rxjs';
import { DataStateChangeEvent, GridComponent, GridDataResult } from '@progress/kendo-angular-grid';
import { State, process } from '@progress/kendo-data-query';
import { TranslateService } from '@ngx-translate/core';
import { ValidationComponent } from '../../../../app-shared/validation/validation.component'
const spaceValidator = new ValidationComponent();

@Component({
  selector: 'app-rawmaterial-numbers',
  templateUrl: './rawmaterial-numbers.component.html',
  styleUrls: ['./rawmaterial-numbers.component.scss']
})
export class RawmaterialNumbersComponent implements OnInit {
  public rawMaterialsForm: FormGroup;
  public createRawMaterialForm: FormGroup;
  public showSearch = false;
  public searchData: any[] = [];
  public loader: any;
  private isActive = new Subject();
  notify: any;
  dialogFlag = false;
  createTitleLabel = '';
  public submitted = false;
  public showSearchData = false;
  public pageable = {
    pageable: {
      position: 'both',
    },
    pageSize: 25,
  };
  public createGridpageable = {
    pageable: {
      position: 'single',
    },
    pageSize: 25,
  };
  public newRowData: any[] = [];
  public deleteRawMaterialData :any[] = [];
  newRaMaterialHeader: any;
  lookUpHeader: any = [];
  deletedialogFlag!: boolean;
  savedialogFlag = false;
  requestDataForDelete: any;
  public deleteTitleLabel = '';
  public saveTitleLabel = '';
  fromSaveDialog = false;
  public deleteCode: any;
  dialogFlagEdit = false;
  public editedRowIndex: any = null;
  controlNames: any;
  formControl1: any;
  formControl2: any;
  is_popup = false;
  filterable = true;
  is_new_gird = false;
  cus_seq: any;
  @ViewChildren(GridComponent)
  public grids: any;
   editorCol = {
    title: 'Actions',
    width: 50,
    type: 'command',
    openPopUp: false
  };
  newCol = {
    title: 'Actions',
    width: 30,
    type: 'onlyDelete',
    openPopUp: false
  };
  public state: State = {
    skip: 0,
    take: 5,
  };
  export: { exportto: boolean, fileName: string } = {
    exportto: true,
    fileName: 'Raw Material Numbers'
  };
  masterTranslate: any;
  commonErr = '';
  public gridData: GridDataResult = process(this.newRowData, this.state);
  public dataStateChange(state: DataStateChangeEvent): void {
    this.state = state;
    this.gridData = process(this.newRowData, this.state);
  }

  constructor(private pspBaseService: PspBaseService, private formBuilder: FormBuilder, private translate: TranslateService) {
    this.rawMaterialsForm = this.formBuilder.group({
      co: new FormControl(''),
      co_name: new FormControl(''),
      rm: new FormControl('')
    });
    this.createRawMaterialForm = this.formBuilder.group({
      code: new FormControl('', [Validators.required, Validators.maxLength(8),spaceValidator.noWhitespaceValidator]),
      code_name: new FormControl('')
    });
    this.controlNames = {
      code : 'Corporate Number'
    };
    this.formControl1 = new FormGroup({});
    this.formControl2 = new FormGroup({});
  }

  ngOnInit(): void {
    this.translate.get('masters').subscribe( (text: string) => {
      this.masterTranslate = text;
      this.deleteTitleLabel = this.masterTranslate.deleteConfirmation;
      this.createTitleLabel = this.masterTranslate.rawmaterial.createRawMaterialNumber;
      this.commonErr = this.masterTranslate.rawmaterial.commonErr;
      this.saveTitleLabel = this.masterTranslate.rawmaterial.saveFoodContactType;
    });
    this.lookUpHeader = [
      {
        field: 'cus_seq',
        header_title: 'cus_seq',
        width: 40,
        editable: false
      },
      {
        field: 'code',
        header_title: 'CO#',
        width: 40,
        maxlength: '8',
        type: 'input_text',
        editable: false
      },
      {
        field: 'name',
        header_title: 'CO Name',
        width: 100,
        maxlength: '80',
        type: 'input_text',
        editable: false
      },
      {
        field: 'mfr_ref_num',
        header_title: 'RM#',
        width: 40,
        maxlength: '40',
        type: 'input_text',
        editable: false
      },
      {
        field: 'ingredient_name',
        header_title: 'Ingredient Name',
        width: 100,
        maxlength: '240',
        type: 'input_text',
        editable: true
      },
      {
        field: 'supplier',
        header_title: 'Supplier Name(s)',
        width: 100,
        maxlength: '240',
        type: 'input_text',
        editable: true
      },
      {
        field: 'internal_flg',
        header_title: 'Internal',
        width: 30,
        type: 'raw_material',
        editable: true
      },
    ];

    this.newRaMaterialHeader = [
      {
        field: 'mfr_ref_num',
        header_title: 'RM#',
        width: 80,
        maxlength: '40',
        type: 'no_filterable',
        err_msg: 'Raw Material Number'
      },
      {
        field: 'ingredient_name',
        header_title: 'Ingredient Name',
        width: 100,
        maxlength: '240',
        type: 'no_filterable',
        err_msg: 'Ingredient Name'
      },
      {
        field: 'supplier',
        header_title: 'Supplier Name(s)',
        width: 100,
        maxlength: '240',
        type: 'no_filterable'
      },
      {
        field: 'internal_flg',
        header_title: 'Internal',
        width: 30,
        type: 'is_checbox',
      }
    ];
  }
  public clearSearch(): void {
    this.rawMaterialsForm.reset();
    this.showSearch = false;
  }
  public open(): any {
    this.notify={};
    (document as any).querySelectorAll('.k-grid-cancel-command').forEach((el: any) => { el.click(); });
    this.dialogFlag = true;
    this.savedialogFlag = false;
    this.is_popup = true;
    this.submitted = false;
    this.showSearchData = false;
    this.createRawMaterialForm.reset();
    this.newRowData = [];
    this.deleteRawMaterialData=[];
  }
  public search(): void {
    (document as any).querySelectorAll('.k-grid-cancel-command').forEach((el: any) => { el.click(); });
    this.showSearch = true;
    const reqObj = {
      code: this.rawMaterialsForm.value.co,
      name: this.rawMaterialsForm.value.co_name,
      mfr_ref_num: this.rawMaterialsForm.value.rm,
    };
    this.searchingRawMaterialNumbers(reqObj,"search");
  }
  public searchingRawMaterialNumbers(reqObj: any,type:any): any {
    this.loader = true;
    this.notify = {};
    this.pspBaseService
      .searchRawMaterialNumbersMaster(reqObj)
      .pipe(takeUntil(this.isActive))
      .subscribe(
        (response: any) => {
          this.loader = false;
          if (response.status === 'SUCCESS') {
            this.handleResponseData(response,type);
          }
          const formCtrls: any = {};
          this.lookUpHeader.forEach((item: any) => {
            if (item.field === 'internal_flg'){
              formCtrls[item.field] = new FormControl(false);
            }else  if (item.field === 'name'){
              formCtrls[item.field] = new FormControl('', [Validators.required, Validators.maxLength(80),spaceValidator.noWhitespaceValidator]);
            }else if (item.field === 'mfr_ref_num'){
              formCtrls[item.field] = new FormControl('', [Validators.required, Validators.maxLength(40),spaceValidator.noWhitespaceValidator]);
            }else if (item.field === 'ingredient_name'){
              formCtrls[item.field] = new FormControl('', [Validators.required, Validators.maxLength(240),spaceValidator.noWhitespaceValidator]);
            }else if (item.field === 'supplier'){
              formCtrls[item.field] = new FormControl('', [Validators.maxLength(240)]);
            }

            else{
              formCtrls[item.field] = new FormControl('');
            }
            this.formControl1 = new FormGroup(formCtrls);
          });
        },
        (err: any) => {
          this.loader = false;
          this.notify =
          {
            style: 'error',
            content: err.statusText
          };
         }
      );
  }
  public handleResponseData(response:any,type:any){
    if(type === "create"){
      this.newRowData = response.results;
      this.showSearchData = true;
      if (this.newRowData.length === 0) {
        this.notify =
        {
          style: 'info',
          content: this.masterTranslate.noRecordsFoundWithTheSearchcriteria
        };
      }
    }else{
      this.searchData = response.results;
      if (this.searchData.length === 0) {
        this.notify =
        {
          style: 'info',
          content: this.masterTranslate.noRecordsFoundWithTheSearchcriteria
        };
      }
    }
  }
  public onDialogClose(): void {
    this.notify = {};
    if (this.createRawMaterialForm.valid){
      this.savedialogFlag = true;
      this.dialogFlag = true;
    }else{
      this.dialogFlag = false;
      this.submitted = false;
      this.showSearchData = false;
      this.is_popup = false;
      this.filterable = true;
    }
  }
  public onsaveDialogClose(data: any): any {
    this.savedialogFlag = false;
    if (data === 'Yes') {
      this.saveAndClose();
      this.fromSaveDialog = true;
      this.dialogFlag = true;
    }else if(data === "No"){
      this.dialogFlag = false;
      this.is_popup = false;
    }else if(data === "Close"){
      this.dialogFlag = true;
    }
  }
  public openSearchCode(): any {
    this.createRawMaterialForm.markAllAsTouched();
    if (this.createRawMaterialForm.valid){
      const reqObj = {
        code: this.createRawMaterialForm.controls.code.value,
      };
      this.CodeRawMaterialNumberMaster(reqObj);
    }
  }
  public CodeRawMaterialNumberMaster(reqObj: any): any {
    this.loader = true;
    this.notify = {};
    this.pspBaseService.getCorporateAndProgramRawMaterialNumber(reqObj).pipe(takeUntil(this.isActive)).subscribe(
      (response: any) => {
        this.loader = false;
        if (response.status === 'SUCCESS') {
          this.filterable = false;
          this.submitted = false;
          const resData = response.results;
          this.cus_seq = resData.cus_seq;
          this.createRawMaterialForm.controls.code_name.setValue(resData.name);
          const reqData = {
            code: resData.code,
          };
          this.searchingRawMaterialNumbers(reqData,"create");
        } else {
          this.submitted = true;
          this.notify = {
            style: 'error',
            content: response.results[0].message
          };
        }
        const formCtrls: any = {};
        this.newRaMaterialHeader.forEach((item: any) => {
          if (item.field === 'internal_flg'){
            formCtrls[item.field] = new FormControl(false);
          }else if (item.field === 'mfr_ref_num'){
            formCtrls[item.field] = new FormControl('', [Validators.required, Validators.maxLength(40),spaceValidator.noWhitespaceValidator]);
          }else if (item.field === 'ingredient_name'){
            formCtrls[item.field] = new FormControl('', [Validators.required, Validators.maxLength(240),spaceValidator.noWhitespaceValidator]);
          }
          else{
            formCtrls[item.field] = new FormControl('');
          }
          this.formControl2 = new FormGroup(formCtrls);
        });
      }
    );
  }
  public saveAndClose(): void {
    this.submitted = true;
    this.notify = {};
    this.createRawMaterialForm.markAllAsTouched();
    if (this.newRowData.length > 0){
      if(this.deleteRawMaterialData.length > 0){
        this.deleteRawMaterialData.forEach((value:any) => {
          this.newRowData.push(value);
        })
      }
      this.loader = true;
      this.pspBaseService
      .rawMaterialNumberCreate(this.newRowData)
      .pipe(takeUntil(this.isActive))
      .subscribe(
        (response: any) => {
          this.loader = false;
          if (response.status === 'SUCCESS') {
            this.dialogFlag = false;
            this.submitted = false;
            this.showSearchData = false;
            this.is_popup = false;
            this.filterable = true;
            this.newRowData = [];
            this.deleteRawMaterialData=[];
            this.search();
            this.notify = {
              style: 'success',
              content: this.masterTranslate.dataSavedSuccessfully
            };
          } else {
            if (this.fromSaveDialog) {
              this.notify = {
                style: 'error',
                content: response.results[0].message
              };
              this.dialogFlag = true;
              this.submitted = true;
              this.fromSaveDialog = false;
            }else{
              this.notify = {
                style: 'error',
                content: response.results[0].message
              };
            }
          }
        }
      );
    }else{
      this.openSearchCode();
    }
  }
  public editHandler(data: any): any {
    if (data[0] === 'editData') {
      if (this.is_popup){
        const index = data[2];
        data[1].code = this.createRawMaterialForm.value.code;
        data[1].cus_seq = this.cus_seq;
        data[1].name = this.createRawMaterialForm.value.code_name;
        this.newRowData[index] = data[1];
      }else{
        if (data[1].internal_flg === true){
          data[1].internal_flg = 'Y';
        }else{
          data[1].internal_flg = 'N';
        }
        this.saveHandler(data[1]);
      }
    }else if (data[0] === 'newData'){
      this.addnewRow(data);
    }else if (data[0] === 'removeData'){
      if (this.is_popup){
        this.deletedialogFlag = true;
        this.deleteCode = data[1].mfr_ref_num;
      }else{
        this.deletedialogFlag = true;
        const product = data[1];
        delete product.doc_text;
        this.requestDataForDelete = product;
        this.deleteCode = product.code;
      }
    }
  }
  public saveHandler(data: any): void {
    this.loader = true;
    this.notify = {};
    this.pspBaseService
      .rawMaterialNumberUpdate(data)
      .pipe(takeUntil(this.isActive))
      .subscribe(
        (response: any) => {
          this.loader = false;
          if (response.status === 'SUCCESS') {
            Object.assign(this.searchData.find((row: any) => row.mfr_ref_num === data.mfr_ref_num), data);
            this.submitted=false;
            this.notify = {
              style: 'success',
              content: this.masterTranslate.dataSavedSuccessfully
            };
          } else {
            this.notify = {
              style: 'error',
              content: response.results[0].message
            };
          }
        },
        (err: any) => {
          this.notify = {
            style: 'error',
            content: err
          };
        }
      );
  }
  addnewRow(data: any): any{
    this.loader = true;
    this.showSearchData =  false;
    this.notify = {};
    if (data[1].internal_flg === true){
      data[1].internal_flg = 'Y';
    }else{
      data[1].internal_flg = 'N';
    }
    data[1].code = this.createRawMaterialForm.value.code;
    data[1].cus_seq = this.cus_seq;
    data[1].name = this.createRawMaterialForm.value.code_name;
    data[1].operation = 'create';
    this.pspBaseService
    .addNewRow(data[1])
    .pipe(takeUntil(this.isActive))
    .subscribe(
      (response: any) => {
        this.loader = false;
        this.showSearchData = true;
        this.submitted = true;
        if (response.status === 'SUCCESS') {
          if (response.results.length ===  0){
            if (this.newRowData.length > 0){
              this.checkDuplicateRm(data[1]);
            }else{
              this.newRowData.push(data[1]);
            }
            this.gridData = process(this.newRowData, this.state);
          }else{
            this.notify = {
              style: 'error',
              content: this.commonErr,
            };
          }
        }else{
          this.notify = {
            style: 'error',
            content: response.results[0].message,
          };
        }
      }
    );
  }
  checkDuplicateRm(data: any): any{
    const isDuplicate = this.newRowData.some(u => u.mfr_ref_num === data.mfr_ref_num);
    if (!isDuplicate){
      this.newRowData.splice(0, 0, data);
    }else{
      this.notify = {
        style: 'error',
        content: this.commonErr,
      };
    }
  }
  onDeleteDialogClose(data: any): any {
    this.deletedialogFlag = false;
    if (data === 'Yes') {
      this.onAccept();
    }
  }
  deleteRaMaterial(){
    this.newRowData.forEach((value:any) => {
      if(value.mfr_ref_num === this.deleteCode){
         value.operation = "delete";
         this.deleteRawMaterialData.push(value)
      }
  });
  }
  onAccept(): any {
    if (this.is_popup){
      this.deleteRaMaterial();
      this.newRowData = this.newRowData.filter((row: any) => {
        if (row.mfr_ref_num !== this.deleteCode) {
          return row;
        }
      });
    }else{
      this.loader=true;
      this.notify = {};
      this.pspBaseService
      .deleteRawMaterialNumberMaster(this.requestDataForDelete)
      .pipe(takeUntil(this.isActive))
      .subscribe(
        (response: any) => {
          this.loader=false;
          if (response.status === 'SUCCESS') {
            this.deletedialogFlag = false;
            this.notify = {
              style: 'success',
              content: this.masterTranslate.recordDeletedSuccessfully
            };
            this.searchData = this.searchData.filter((row: any) => {
              if (row.code !== this.requestDataForDelete.code) {
                return row;
              }
            });
          } else {
            this.notify = {
              style: 'error',
              content: response.results[0].message
            };
            this.deletedialogFlag = false;
          }
        },
        (err: any) => {
          this.notify = {
            style: 'error',
            content: err.statusText
          };
        }
      );
    }
  }

}
