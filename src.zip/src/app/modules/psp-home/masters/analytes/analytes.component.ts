import { Component, OnInit, ViewChildren } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { SortDescriptor, State, process } from '@progress/kendo-data-query';
import { PspBaseService } from '../../services/psp-base.service';
import { Router } from '@angular/router';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { TranslateService } from '@ngx-translate/core';
import { DataStateChangeEvent, GridDataResult, GridComponent } from '@progress/kendo-angular-grid';
import { ExcelExportData } from '@progress/kendo-angular-excel-export';
import { exportPDF, Group } from '@progress/kendo-drawing';
import { saveAs } from '@progress/kendo-file-saver';
import { ValidationComponent } from '../../../../app-shared/validation/validation.component'
const spaceValidator = new ValidationComponent();

const createFormGroup = (dataItem: any) =>
  new FormGroup({
    code: new FormControl(dataItem.code, [Validators.required,spaceValidator.noWhitespaceValidator]),
    descr: new FormControl(dataItem.descr, [Validators.required,spaceValidator.noWhitespaceValidator]),
    cas: new FormControl(dataItem.cas),
    analysis_id: new FormControl(dataItem.analysis_id, [Validators.required,spaceValidator.noWhitespaceValidator]),
    prep_code: new FormControl(dataItem.prep_code)
  });



@Component({
  selector: 'app-analytes',
  templateUrl: './analytes.component.html',
  styleUrls: ['./analytes.component.scss']
})


export class AnalytesComponent implements OnInit {
  public analytesForm: FormGroup;
  public createAnalyteForm: FormGroup;
  public editAnalyteForm: FormGroup;
  public listItems: any;
  private isActive = new Subject();
  editDialogFlag = false;
  dialogFlag = false;
  dialogFlagEdit = false;
  saveEditFlag = false;
  titleLabel = '';
  editButtonLabel = '';
  public saveTitleLabel: any;
  public deleteTitleLabel: any;
  masterTranslate: any;
  commonTranslate: any;
  public updatedData: any;
  lookUpTestGridData: any;
  lookUpHeader: any = [];
  testCodeHeader: any;
  prepCodeHeader: any;
  public loader: any;
  public submitted = false;
  public editSubmitted = false;
  public editedRowIndex: any = null;
  saveNClose = false;
  deletedialogFlag!: boolean;
  requestDataForDelete: any;
  public DeleteTitleLabel = '';
  public pageable = {
    pageable: {
      position: 'single',
    },
    pageSize: 25,
  };
  public mainGrodPageable = {
    pageable: {
      position: 'both',
    },
    pageSize: 25,
  };
  public state: State = {
    skip: 0,
    take: 5,
  };
  controlNames: any;
  public testCodeData: any[] = [];
  public showSearch = false;
  public showSearchTest = false;
  public showSearchPrep = false;
  searchingData: any;
  public searchData: any[] = [];
  prepCodeData: any;
  public opened = false;
  public showAlertFlag = false;
  CreatedData: any;
  public editDataItem: any;
  public isNew = false;
  public editDialogDataItem: any;
  public formControl: any;
  notify: any;
  public isDialog = false;
  public handler: any;
  functionTestDataFromChild: any;
  functionPrepDataFromChild: any;
  public sort: SortDescriptor[] = [
    {
      field: 'code',
      dir: 'asc',
    },
    {
      field: 'descr',
      dir: 'asc',
    }
  ];
  dimension = {
    height: 200,
    width: 200,
    position: 'right'
  };
  editorCol = {
    title: 'Actions',
    width: 100,
    type: 'command',
    openPopUp: true
  };
  export: { exportto: boolean, fileName: string } = {
    exportto: true,
    fileName: 'Analytes'
  };
  @ViewChildren(GridComponent)
  public grids: any;
  public deleteCode: any;
  public gridData: GridDataResult = process(this.searchData, this.state);
  public dataStateChange(state: DataStateChangeEvent): void {
    this.state = state;
    this.gridData = process(this.searchData, this.state);
  }
  public notifyPopup: any;
  analyteCode :any;
  constructor(private pspBaseService: PspBaseService, private formBuilder: FormBuilder,
              private translate: TranslateService) {
    this.analytesForm = this.formBuilder.group({
      code_Init: new FormControl('', [Validators.required, Validators.maxLength(9)]),
      descr_Init: new FormControl('', [
        Validators.required,
        Validators.maxLength(110),
      ]),
      cas_Init: new FormControl('', [Validators.required, Validators.maxLength(9)]),
      analysis_id_Init: new FormControl('', [Validators.required, Validators.maxLength(9)]),
      prep_code_Init: new FormControl('', [Validators.required, Validators.maxLength(9)]),
    });
    this.createAnalyteForm = new FormGroup({
      code: new FormControl('', [Validators.required,spaceValidator.noWhitespaceValidator]),
      descr: new FormControl('', [Validators.required,spaceValidator.noWhitespaceValidator]),
      cas: new FormControl(),
      analysis_id: new FormControl('', [Validators.required,spaceValidator.noWhitespaceValidator]),
      prep_code: new FormControl(),
    });
    this.editAnalyteForm = new FormGroup({
      code: new FormControl('',[Validators.required,spaceValidator.noWhitespaceValidator]),
      descr: new FormControl('', [Validators.required,spaceValidator.noWhitespaceValidator]),
      cas: new FormControl(),
      analysis_id: new FormControl('', [Validators.required,spaceValidator.noWhitespaceValidator]),
      prep_code: new FormControl(),
    });
    this.controlNames = {
      code: 'Code',
      descr: 'Description',
      analysis_id: 'TestCode'
    };
    this.allData = this.allData.bind(this);
    this.formControl = new FormGroup({});
  }
  ngOnInit(): void {
    this.translate.get('masters').subscribe((text: string) => {
      this.masterTranslate = text;
      this.deleteTitleLabel = this.masterTranslate.deleteConfirmation;
      this.saveTitleLabel = this.masterTranslate.saveConfirmation;
      this.titleLabel = this.masterTranslate.analytes.createAnalytes;
      this.editButtonLabel = this.masterTranslate.analytes.editAnalytes;
    });
    this.translate.get('common').subscribe((text: string) => {
      this.commonTranslate = text;
    });

    this.lookUpHeader = [
      {
        field: 'code',
        header_title: 'Code',
        width: 150,
        type: 'input_text'
      },
      {
        field: 'descr',
        header_title: 'Description',
        width: 300,
        type: 'input_text'
      },
      {
        field: 'cas',
        header_title: 'CAS#',
        width: 150,
        type: 'input_text'
      },
      {
        field: 'analysis_id',
        header_title: 'Test Code',
        width: 150,
        type: 'input_text'
      },
      {
        field: 'prep_code',
        header_title: 'Prep Code',
        width: 150,
        type: 'input_text'
      },
    ];
    this.testCodeHeader = [
      {
        field: 'identity',
        header_title: 'Test Code',
        width: 200,
        type: 'input_text'
      },
      {
        field: 'description',
        header_title: 'Description',
        width: 400,
        type: 'input_text'
      }

    ];
    this.prepCodeHeader = [
      {
        field: 'identity',
        header_title: 'Prep Code',
        width: 200,
        type: 'input_text'
      },
      {
        field: 'description',
        header_title: 'Description',
        width: 400,
        type: 'input_text'
      }

    ];
  }
  /* command for search API */
  public searchingAnalytesMaster(reqObj: any): any {
    this.notify = {};
    this.loader = true;
    this.pspBaseService
      .searchAnalytesMaster(reqObj)
      .pipe(takeUntil(this.isActive))
      .subscribe(
        (response: any) => {
          if (response.status === 'SUCCESS') {
            this.searchData = response.results;
            this.loader = false;
            if (this.searchData.length === 0) {
              this.notify =
              {
                style: 'info',
                content: this.masterTranslate.noRecordsFoundWithTheSearchcriteria
              };
            }
          }
        },
        (err: any) => {
          this.loader = false;
          this.notify =
          {
            style: 'error',
            content: this.commonTranslate.noRecordsFoundWithTheSearchcriteria
          };
        }
      );
  }
  public editHandler(data: any): any {
    if (data[0] === 'openDialog') {
      this.notifyPopup= {};
      this.notify={};
      this.dialogFlagEdit = true;
      this.editSubmitted = false;
      this.editAnalyteForm = createFormGroup(data[1]);
      this.editedRowIndex = data.rowIndex;
      this.analyteCode = data[1]["code"];
      this.showSearchTest = false;
      this.showSearchPrep = false;
    } else if (data[0] === 'removeData') {
      this.deletedialogFlag = true;
      const product = data[1];
      delete product.doc_text;
      this.requestDataForDelete = product;
      this.deleteCode = product.code;
    }
  }
  // for update
  public saveGridOption(): void {
    this.notify={};
    this.notifyPopup={};
    this.editSubmitted = true;
    this.editAnalyteForm.markAllAsTouched();
    if (this.editAnalyteForm.valid) {
      this.loader = true;
      const req = this.editAnalyteForm.value;
      this.pspBaseService
        .getAnalytesUpdate(req)
        .pipe(takeUntil(this.isActive))
        .subscribe(
          (response: any) => {
            this.loader = false;
            if (response.status === 'SUCCESS') {
              this.dialogFlagEdit = false;
              this.notify = {
                style: 'success',
                content: this.masterTranslate.dataSavedSuccessfully

              };
              Object.assign(
                this.searchData.find(({ code }) => code === req.code),
                req
              );
            } else {
              this.dialogFlagEdit = true;
              this.notifyPopup = {
                content: response.results ? response.results[0].message : response.status,
                style: 'error',
              };
            }
          },
        );
    }
  }
  /* for create form data in dialogbox */
  public saveAndClose(): void {
    this.submitted = true;
    this.notify = {};
    this.notifyPopup = {};
    this.createAnalyteForm.markAllAsTouched();
    if (this.createAnalyteForm.valid) {
      this.loader = true;
      const requestdata = this.createAnalyteForm.value;
      const req = {
        code: requestdata.code ? requestdata.code : null,
        descr: requestdata.descr ? requestdata.descr : null,
        cas: requestdata.cas ? requestdata.cas : null,
        analysis_id: requestdata.analysis_id ? requestdata.analysis_id : null,
        prep_code: requestdata.prep_code ? requestdata.prep_code : null,
      };
      this.pspBaseService
        .getAnalytesCreate(req)
        .pipe(takeUntil(this.isActive))
        .subscribe(
          (response: any) => {
            this.loader = false;
            if (response.status === 'SUCCESS') {
              this.dialogFlag = false;
              this.search();
              this.notify = {
                style: 'success',
                content: this.masterTranslate.dataSavedSuccessfully
              };
            } else {
              this.dialogFlag = true;
              this.notifyPopup = {
                content: response.results ? response.results[0].message : response.status,
                style: 'error',
              };
            }
          },
        );
    }else{
      this.dialogFlag = true;
    }
  }
  /*  for Analytes Master TestCode */
  public testCodeAnalyteMaster(): any {
    const reqObj = {};
    this.loader = true;
    this.pspBaseService.getAnalytesTestCode(reqObj).pipe(takeUntil(this.isActive)).subscribe(
      (response: any) => {
        if (response.status === 'SUCCESS') {
          this.loader = false;
          this.testCodeData = response.results;
        }
      },
      (err: any) => {
      });
  }
  /*  for Analytes Master PrepCode */
  public prepCodeAnalyteMaster(): any {
    this.loader = true;
    const reqObj = {};
    this.pspBaseService.getAnalytesPrepCode(reqObj).pipe(takeUntil(this.isActive)).subscribe(
      (response: any) => {
        if (response.status === 'SUCCESS') {
          this.loader = false;
          this.prepCodeData = response.results;
        }
      },
      (err: any) => {

      });
  }
  /* Remove command for main grid */
  onDeleteDialogClose(data: any): any {
    this.deletedialogFlag = false;
    if (data === 'Yes') {
      this.onAccept();
    }
  }
  onAccept(): any {
    this.loader = true;
    this.notify = {};
    this.pspBaseService
      .deleteAnalyteMaster(this.requestDataForDelete)
      .pipe(takeUntil(this.isActive))
      .subscribe(
        (response: any) => {
          this.loader = false;
          if (response.status === 'SUCCESS') {
            this.deletedialogFlag = false;
            this.notify = {
              content: this.masterTranslate.recordDeletedSuccessfully,
              style: 'success'
            };
            this.searchData = this.searchData.filter((row: any) => {
              if (row.code !== this.requestDataForDelete.code) {
                return row;
              }
            });
          } else {
            this.notify = {
              content: response.results[0].message,
              style: 'error'
            };
            this.deletedialogFlag = false;
          }
        }
      );
  }
  public onDialogClose(): any {
     this.submitted = false;
     this.notify = {};
     this.editSubmitted = false;
     if (this.createAnalyteForm.valid || this.createAnalyteForm.dirty) {
      this.saveNClose = true;
    }else{
      this.dialogFlag = false;
    }
  }

  public onDialogEditClose(): any{
    if (this.editAnalyteForm.dirty){
      this.saveEditFlag = true;
    }else{
      this.dialogFlagEdit = false;
    }
  }

  saveEditdata(val: any): any{
    this.saveEditFlag = false;
    if (val === 'Yes'){
      this.update();
    }else if (val === 'No'){
      this.dialogFlagEdit = false;
      this.editAnalyteForm.reset();
      this.editSubmitted=false;
    }else{
      this.dialogFlagEdit = true;
    }
  }

  public openDialog(): any {
    this.notify={};
    this.submitted=false;
    this.notifyPopup= {};
    this.dialogFlag = true;
    this.showSearchTest = false;
    this.showSearchPrep = false;
    this.createAnalyteForm.reset();
  }
  public search(): any {
    this.showSearch = true;
    const reqObj = {
      code: this.analytesForm.controls.code_Init.value,
      descr: this.analytesForm.controls.descr_Init.value,
      cas: this.analytesForm.controls.cas_Init.value,
      analysis_id: this.analytesForm.controls.analysis_id_Init.value,
      prep_code: this.analytesForm.controls.prep_code_Init.value
    };
    this.searchingAnalytesMaster(reqObj);
  }
  public openSearchTest(): any {
    this.showSearchTest = true;
    this.testCodeAnalyteMaster();
    this.showSearchPrep = false;
  }
  public openSearchPrep(): any {
    this.showSearchPrep = true;
    this.prepCodeAnalyteMaster();
    this.showSearchTest = false;
  }
  public update(): any {
    this.saveGridOption();
  }
  public delete(): any {
    this.opened = true;
  }
  public clearSearch(): void {
    this.analytesForm.reset();
    this.showSearch = false;
    this.notify = {};
  }
  public lookUpEditPrepCode(event: any): any {
    const name = event.target.closest('tr').cells[0].innerText;
    if (name && !(event.target.closest('thead') )) {
      this.editAnalyteForm.controls.prep_code.patchValue(name);
      this.showSearchPrep = false;
    }
  }
  public lookUpCreatePrepCode(event: any): any {
    const name = event.target.closest('tr').cells[0].innerText;
    if (name && !(event.target.closest('thead') )) {
      this.createAnalyteForm.controls.prep_code.patchValue(name);
      this.showSearchPrep = false;
    }
  }
  public lookUpEditTestCode(event: any): any {
    const name = event.target.closest('tr').cells[0].innerText;
    if (name && !(event.target.closest('thead') )) {
      this.editAnalyteForm.controls.analysis_id.patchValue(name);
      this.showSearchTest = false;
    }
  }
  public lookUpCreateTestCode(event: any): any {
    const name = event.target.closest('tr').cells[0].innerText;
    if (name && !(event.target.closest('thead') )) {
      this.createAnalyteForm.controls.analysis_id.patchValue(name);
      this.showSearchTest = false;

    }
  }
  public exportGrids(): void {
    const promises = this.grids.map((grid: any) => grid.drawPDF());
    Promise.all(promises)
      .then((groups) => {
        const rootGroup = new Group({
          pdf: {
            multiPage: true,
          },
        });
        groups.forEach((group: any) => {
          rootGroup.append(...group.children);
        });
        return exportPDF(rootGroup, { paperSize: 'A4' });
      })
      .then((dataUri) => {
        saveAs(dataUri, 'CategoryMaster.pdf');
      });
  }
  public allData(): ExcelExportData {
    const myState: State = this.state;
    myState.skip = 0;
    myState.take = this.gridData.total;
    const result: ExcelExportData = {
      data: process(this.searchData, this.state).data
    };
    return result;
  }
  public sortChange(sort: SortDescriptor[]): void {
    this.sort = sort;
    this.search();
  }

  savedata(val: any): any{
    console.log(val);
    this.saveNClose = false;
    if (val === 'Yes') {
        this.saveAndClose();
    }else if (val === 'No'){
        this.dialogFlag = false;
        this.submitted = false;
        this.createAnalyteForm.reset();
    }else{
      this.dialogFlag = true;
    }
  }

  createAnalyte(req: any): void {
    this.notify = {};
      this.pspBaseService
        .getAnalytesCreate(req)
        .pipe(takeUntil(this.isActive))
        .subscribe(
          (response: any) => {
            this.loader = false;
            if (response.status === 'SUCCESS') {
              this.dialogFlag = false;
              this.search();
              this.notify = {
                style: 'success',
                content: this.masterTranslate.dataSavedSuccessfully
              };
              Object.assign(
                this.searchData.find(({ code }) => code === req.code),
                req
              );
              this.dialogFlag = false;
            } else {
              this.dialogFlag = false;
              this.notify = {
                content: response.results[0].message,
                style: 'error'
              };
            }
          },
        );
  }

}


