import { Component, OnInit, ViewChildren, Renderer2, ViewChild } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators, FormArray } from '@angular/forms';
import { Subject } from 'rxjs';
import { DataStateChangeEvent, GridComponent, GridDataResult } from '@progress/kendo-angular-grid';
import { SortDescriptor, State, process } from '@progress/kendo-data-query';
import { takeUntil } from 'rxjs/operators';
import { PspBaseService } from '../../services/psp-base.service';
import { TranslateService } from '@ngx-translate/core';
import { ValidationComponent } from '../../../../app-shared/validation/validation.component';
import { ConstantPool } from '@angular/compiler';
const spaceValidator = new ValidationComponent();

const matches = (el: any, selector: any) =>
  (el.matches || el.msMatchesSelector).call(el, selector);

@Component({
  selector: 'app-test-decisions',
  templateUrl: './test-decisions.component.html',
  styleUrls: ['./test-decisions.component.scss']
})

export class TestDecisionsComponent implements OnInit {
  public testDeciForm: FormGroup;
  public createTestDecisionForm: FormGroup;
  public searchGrid: any[] = [];
  public showAdd = false;
  public showSearch = false;
  public editfunctiondialogFlag = false;
  lookUpHeader: any = [];
  showCol = false;
  controlNames: any;
  public showHide = false;
  public submitted = false;
  public listItems: any;
  public loader: any;
  dialogFlag = false;
  saveDialoFlag = false;
  createTestDecisionLabel = '';
  notify: any;
  testCodeHeader: any;
  public testCodeData: any[] = [];
  deletedialogFlag = false;
  ConfirmdeletedialogFlag = false;
  public searchData: any[] = [];
  public editDialogFlag!: boolean;
  public editLookUpGridData: any;
  public editfunctionDataFromChild: any;
  public functionDataFromChild: any;
  public functiondialogFlag!: boolean;
  public functionLookUpGridData: any;
  public functionLookupHeader: any;
  public height = 430;
  public functionTitleLabel = '';
  public state: State = {
    skip: 0,
    take: 5,
  };
  editorCol = {
    title: 'Actions',
    width: 70,
    type: 'command',
    openPopUp: true
  };
  export: { exportto: boolean, fileName: string } = {
    exportto: true,
    fileName: 'Test Decision'
  };
  public mainGridPageable = {
    pageable: {
      position: 'both',
    },
    pageSize: 25,
  };
  public pageable = {
    pageable: {
      position: 'single',
    },
    pageSize: 25,
  };
  @ViewChild(GridComponent) public grid!: GridComponent;

  public gridData: GridDataResult = process(this.searchData, this.state);
  requestDataForDelete: any;
  deleteCode: any;
  dataFromChild: any;
  formControl: any;
  testDecisionTranslate: any;
  lookUpTitleLabel: any;
  gridLookUpTitleLable: any;
  deleteTitleLabel: any;
  columnHeaders: any;
  analyteTestlookupDataFromChild: any;
  anayteDescriptionLookupValue: any;
  belowTestlookUpdialogFlag!: boolean;
  belowtestlookupDataFromChild: any;
  analytelookUpdialogFlag!: boolean;
  inRangelookUpdialogFlag!: boolean;
  inRangelookupDataFromChild: any;
  testingTypeDropdownlistItems: any;
  aboveHighlookUpdialogFlag!: boolean;
  analyteLookUpGridData: any;
  aBILookUpGridData: any;
  commonlookupHeader: any;
  abovelookupDataFromChild: any;
  saveButtonAddItemFlag = true;
  createEditReadOnlyCode!: boolean;
  docClickSubscription: any;
  saveTitleLabel: any;
  private editedRowIndex: any;
  viewGrid: any;
  status = '';
  defaultItemValue: any;
  filterInRange: any;
  rowIndexValue!: number;
  dataItemValue: any;
  private isActive = new Subject();
  public sort: SortDescriptor[] = [
    {
      field: 'code',
      dir: 'asc',
    },
    {
      field: 'descr',
      dir: 'asc',
    },
  ];
  public notifyPopup: any;
  public view: any[] = [];
  updateGridView: any = [];
  public formGroup: any;
  private isNew!: boolean;
  // displayError!: boolean;
  public dataStateChange(state: DataStateChangeEvent): void {
    this.state = state;
    this.gridData = process(this.searchData, this.state);
  }
  testDesCode: any;
  testDesDescr: any;
  lowVal: any;
  highVal: any;
  belowLowTest: any;
  inRangeTestData: any;
  aboveHighTest: any;
  is_edit = false;
  errors = [];
  highValue: any;
  lowValue: any;
  isHighValue = false;
  isLowValue = false;
  highValErrMsg = '';
  lowValErrMsg = '';
  constructor(private pspBaseService: PspBaseService, private formBuilder: FormBuilder,
    private renderer: Renderer2, private translate: TranslateService) {
    this.formGroup = undefined;
    this.testDeciForm = new FormGroup({
      code: new FormControl(''),
      descr: new FormControl(''),
    });
    this.createTestDecisionForm = new FormGroup({
      code: new FormControl('', [Validators.required, Validators.maxLength(30), spaceValidator.noWhitespaceValidator]),
      descr: new FormControl('', [Validators.required, Validators.maxLength(80), spaceValidator.noWhitespaceValidator]),
      belowLowTest: new FormControl('', [Validators.required, Validators.maxLength(30), spaceValidator.noWhitespaceValidator]),
      inRangeTest: new FormControl('', [Validators.required, Validators.maxLength(30), spaceValidator.noWhitespaceValidator]),
      aboveHighTest: new FormControl('', [Validators.required, Validators.maxLength(30), spaceValidator.noWhitespaceValidator]),
      lowValue: new FormControl('', [Validators.maxLength(4)]),
      highValue: new FormControl('', [Validators.maxLength(4)]),
      operation: new FormControl('create'),
      testDecisionDtlsDTOList: new FormArray([
      ]),
    });
    this.controlNames = {
      code: 'Code ',
      descr: 'Description',
      belowLowTest: 'Below Low Test',
      inRangeTest: 'In Range Test',
      aboveHighTest: 'Above High Test'
    };
  }

  public createFormGroup = (dataItem: any) =>
    new FormGroup({
      TESTING_TYPE: new FormControl(dataItem.TESTING_TYPE),
      ANLM_CODE: new FormControl(dataItem.ANLM_CODE, [Validators.required, spaceValidator.noWhitespaceValidator]),
      ANLM_DESCR: new FormControl(dataItem.ANLM_DESCR),
      operation: new FormControl(dataItem.operation),
      type: new FormControl(dataItem.type)

    })

  ngOnInit(): void {
    // this.viewGrid = [];

    this.docClickSubscription = this.renderer.listen(
      'document',
      'click',
      this.onDocumentClick.bind(this)
    );
    this.translate.get('masters').subscribe((text: string) => {
      this.testDecisionTranslate = text;
      this.lookUpTitleLabel = this.testDecisionTranslate.testDecision.lookUpTitleLabel;
      this.gridLookUpTitleLable = this.testDecisionTranslate.testDecision.gridLookUpTitleLable;
      this.deleteTitleLabel = this.testDecisionTranslate.deleteConfirmation;
      this.saveTitleLabel = this.testDecisionTranslate.saveConfirmation;
      this.functionTitleLabel = this.testDecisionTranslate.testDecision.functionTitleLabel;
      this.functionLookupHeader = [
        {
          field: 'CODE',
          header_title: 'TestCode',
          width: 200,
          type: 'input_text'
        },
        {
          field: 'DESCR',
          header_title: 'Description',
          width: 400,
          type: 'input_text'
        }
      ];
      this.lookUpHeader = [
        {
          header_title: this.testDecisionTranslate.code,
          width: 90,
          type: 'underline',
          field: 'CODE',
          editable: false
        },
        {
          header_title: this.testDecisionTranslate.description,
          width: 200,
          type: 'input_text',
          field: 'DESCR',
          editable: false
        },
        {
          header_title: this.testDecisionTranslate.testDecision.lowValue,
          width: 100,
          type: 'input_text',
          field: 'LOW_VALUE',
          editable: false
        },
        {
          header_title: this.testDecisionTranslate.testDecision.highValue,
          width: 100,
          type: 'input_text',
          field: 'HIGH_VALUE',
          editable: false
        },
        {
          header_title: this.testDecisionTranslate.testDecision.belowLowTest,
          width: 110,
          type: 'input_text',
          field: 'BELOW_LOW_AC_CODE',
          editable: false
        },
        {
          header_title: this.testDecisionTranslate.testDecision.inRangeTest,
          width: 110,
          type: 'input_text',
          field: 'IN_RANGE_AC_CODE',
          editable: false
        },
        {
          header_title: this.testDecisionTranslate.testDecision.aboveHighTest,
          width: 120,
          type: 'input_text',
          field: 'ABOVE_HIGH_AC_CODE',
          editable: false
        },
      ];
      this.commonlookupHeader = [
        {
          field: 'code',
          header_title: this.testDecisionTranslate.code,
          width: 200,
          type: 'input_text'
        },
        {
          field: 'descr',
          header_title: this.testDecisionTranslate.description,
          width: 400,
          type: 'input_text'
        }
      ];
    });
    this.createFormGroup = this.createFormGroup.bind(this);
  }

  public addHandler(): void {
    this.closeEditor();
    this.isNew = true;
    this.formGroup = this.createFormGroup({
      TESTING_TYPE: '',
      ANLM_CODE: '',
      ANLM_DESCR: '',
      operation: 'create',
      type:'new'
    });

    this.grid.addRow(this.formGroup);
  }
  private closeEditor(): void {
    this.grid.closeRow(this.editedRowIndex);

    this.isNew = false;
    this.editedRowIndex = undefined;
    this.formGroup = undefined;
  }
  public removeHandler({ dataItem, rowIndex }: any): void {
    this.ConfirmdeletedialogFlag = true;
    this.dataItemValue = dataItem;
    this.rowIndexValue = rowIndex;
  }
  public cancelHandler({ sender, rowIndex, dataItem }: { sender: any, rowIndex: number, dataItem: any }): void {
    this.closeEditor();
  }
  private onDocumentClick(e: any): void {
    if (
      this.formGroup?.valid &&
      !matches(
        e.target,
        '#productsGrid tbody *, #productsGrid .k-grid-toolbar .k-button'
      )
    ) {
      this.saveCurrent();
    }
  }

  private saveCurrent(): void {
    if (this.formGroup) {
      this.view.push(this.formGroup.value);
      this.closeEditor();
    }
  }
  // for chemical search for main grid
  public searchTestDecision(reqObj: any): any {
    this.loader = true;
    this.pspBaseService
      .searchTestDecisionMaster(reqObj)
      .pipe(takeUntil(this.isActive))
      .subscribe(
        (response: any) => {
          if (response.status === 'SUCCESS') {
            this.searchData = response.results;
            if (this.searchData.length === 0) {
              this.loader = false;
              this.notify =
              {
                style: 'info',
                content: this.testDecisionTranslate.noRecordsFoundWithTheSearchcriteria
              };
            } else {
              this.loader = false;
              // this.notify = false;
            }
          }
        },
        (err: any) => {
          this.loader = false;
          this.notify =
          {
            style: 'error',
            content: err.statusText
          };
        }
      );
  }
  public open(): void {
    this.dialogFlag = true;
    this.createTestDecisionForm.reset();
    this.functionDataFromChild = [];
    this.view = [];
    this.updateGridView = [];
  }
  public clearSearch(): void {
    this.testDeciForm.reset();
    this.createTestDecisionForm.reset();
    this.showSearch = false;
    this.notify = {};
  }
  public saveCreateForm(data?: any): void {
    if (!this.formGroup || this.formGroup.valid){
    }else{
      this.notifyPopup = {
            content: 'Please enter valid Analyte code.',
            style: 'error',
      };
    }
    if (!this.isHighValue && !this.isLowValue && !this.formGroup || this.formGroup.valid) {
      this.saveCurrent();
      this.submitted = true;
      this.createTestDecisionForm.markAllAsTouched();
      if (this.createTestDecisionForm.valid) {
        const views: any = [];
        this.view.forEach((row: any) => {
          views.push({
            TESTING_TYPE: row.TESTING_TYPE,
            ANLM_CODE: row.ANLM_CODE,
            ANLM_DESCR: row.ANLM_DESCR,
            operation: row.operation
          });
        });
        if (this.updateGridView.length > 0) {
          this.updateGridView.forEach((row: any) => {
            views.push({
              TESTING_TYPE: row.TESTING_TYPE,
              ANLM_CODE: row.ANLM_CODE,
              ANLM_DESCR: row.ANLM_DESCR,
              operation: row.operation
            });
          });
        }
        const requestdata = this.createTestDecisionForm.value;
        const request = {
          CODE: requestdata.code ? requestdata.code : null,
          DESCR: requestdata.descr ? requestdata.descr : null,
          LOW_VALUE: requestdata.lowValue ? requestdata.lowValue : null,
          HIGH_VALUE: requestdata.highValue ? requestdata.highValue : null,
          BELOW_LOW_AC_CODE: requestdata.belowLowTest ? requestdata.belowLowTest : null,
          IN_RANGE_AC_CODE: requestdata.inRangeTest ? requestdata.inRangeTest : null,
          ABOVE_HIGH_AC_CODE: requestdata.aboveHighTest ? requestdata.aboveHighTest : null,
          testDecisionDtlsDTOList: views.length > 0 ? views : null,
          operation: this.status === 'update' ? 'update' : 'create',
        };
        this.loader = true;
        this.pspBaseService
          .saveCloseTestDecisionMaster(request)
          .pipe(takeUntil(this.isActive))
          .subscribe(
            (response: any) => {
              this.loader = false;
              this.isHighValue = false;
              this.isLowValue = false;
              if (response.status === 'SUCCESS') {
                if (data === 'cancel') {
                  this.dialogFlag = true;
                } else {
                  this.dialogFlag = false;
                }
                this.search();
                this.notify = {
                  content: this.testDecisionTranslate.dataSavedSuccessfully,
                  style: 'success',
                };
              } else {
                this.notifyPopup = {
                  content: response.results ? response.results[0].message : response.status,
                  style: 'error',
                };
                this.dialogFlag = true;
                // this.updateGridView.length = 0;
              }
            }

          );
      }
    }
    //  else {
    //   this.notify = {
    //     content: 'please enter high value greater than lower value',
    //     style: 'error',
    //   };
    //  }
  }
  onDeleteDialogClose(data: any): any {
    this.deletedialogFlag = false;
    if (data === 'Yes') {
      this.onAccept();
    }
  }
  onAccept(): any {
    this.loader = true;
    this.pspBaseService
      .deleteTestDecision(this.requestDataForDelete)
      .pipe(takeUntil(this.isActive))
      .subscribe(
        (response: any) => {
          this.loader = false;
          if (response.status === 'SUCCESS') {
            this.search();
            this.deletedialogFlag = false;
            this.notify = {
              content: this.testDecisionTranslate.recordDeletedSuccessfully,
              style: 'success'
            };
          } else {
            this.notify = {
              content: response.results[0].message,
              style: 'error'
            };
            this.deletedialogFlag = false;
          }
        },
      );
  }
  public Add(): void {
    this.showAdd = true;
  }
  public search(): void {
    this.notify = {};
    this.notifyPopup = {};
    this.showSearch = true;
    const reqObj: any = {
      CODE: this.testDeciForm.controls.code.value ? this.testDeciForm.controls.code.value : '',
      DESCR: this.testDeciForm.controls.descr.value ? this.testDeciForm.controls.descr.value : ''

    };
    this.searchTestDecision(reqObj);
  }

  public onDialogClose(): any {
    // this.closeEditor();
    this.submitted = false;
    this.notify = {};
    this.notifyPopup = {};

    if (this.createTestDecisionForm.controls.code.dirty ||
      this.createTestDecisionForm.controls.descr.dirty ||
      this.createTestDecisionForm.controls.lowValue.dirty ||
      this.createTestDecisionForm.controls.highValue.dirty ||
      this.createTestDecisionForm.controls.belowLowTest.dirty ||
      this.createTestDecisionForm.controls.inRangeTest.dirty ||
      this.createTestDecisionForm.controls.aboveHighTest.dirty
    ) {
      this.saveDialoFlag = true;
    } else {
      this.dialogFlag = false;
    }
  }

  savedata(val: any): any {
    this.saveDialoFlag = false;
    if (val === 'Yes') {
      this.saveCreateForm();
    } else if (val === 'No') {
      this.dialogFlag = false;
    } else if (val === "Close") {
      this.dialogFlag = true;
    }
  }
  public createDialog(): any {
    this.isHighValue = false;
    this.isLowValue = false;
    this.is_edit = false;
    this.submitted = false;
    this.notify = {};
    this.notifyPopup = {};
    this.translate.get('masters').subscribe((text: string) => {
      this.createTestDecisionLabel = this.testDecisionTranslate.testDecision.createTestDecisionLabel;
    });
    this.dialogFlag = true;
    this.status = 'create';
    this.saveButtonAddItemFlag = true;
    this.createEditReadOnlyCode = true;
    this.createTestDecisionForm.reset();
    this.view = [];
    this.updateGridView = [];
    this.gettingTestingTypeDropdown();
    this.notifyPopup = {};
  }

  public editTestDecision(data: any): any {
    if (data[0] === 'openDialog') {
      // this.displayError = false;
      this.notifyPopup = {};
      this.notify = {};
      this.submitted = false;
      this.isHighValue = false;
      this.isLowValue = false;
      this.closeEditor();
      this.saveButtonAddItemFlag = true;
      this.is_edit = true;
      this.testDesCode = data[1]["CODE"];
      this.createEditReadOnlyCode = false;
      this.updateGridView=[];
      this.translate.get('masters').subscribe((text: string) => {
        this.createTestDecisionLabel = this.testDecisionTranslate.testDecision.editTestDecisionLabel;
      });
      this.status = 'update';
      this.isNew = false;
      this.highValue = data[1].HIGH_VALUE;
      this.lowValue = data[1].LOW_VALUE;
      this.editFormGroup(data[1], this.status);
      this.dialogFlag = true;
      this.gettingTestingTypeDropdown();

    } else if (data[0] === 'removeData') {
      this.deletedialogFlag = true;
      this.requestDataForDelete = data[1];
      this.deleteCode = data[1].CODE;
    }
  }
  public editFormGroup(args: any, status: any): void {
    let rowArr;
    this.pspBaseService.getCodeTestDecision({ CODE: args.CODE }).pipe(takeUntil(this.isActive))
      .subscribe(
        (response: any) => {
          rowArr = response.results;
          this.view = [];
          this.updateGridView = [];
          rowArr[0].testDecisionDtlsDTOList.forEach((row: any) => {
            this.view.push({
              TESTING_TYPE: row.TESTING_TYPE,
              ANLM_CODE: row.ANLM_CODE,
              ANLM_DESCR: row.ANLM_DESCR,
              operation: 'update',
              type:'update'
            });
          });
          //   this.createTestDecisionForm.controls.testDecisionDtlsDTOList.patchValue(this.view);
          this.dialogFlag = true;
        });
    this.createTestDecisionForm = new FormGroup({
      code: new FormControl(args.CODE, [Validators.required, Validators.maxLength(30), spaceValidator.noWhitespaceValidator]),
      descr: new FormControl(args.DESCR, [Validators.required, Validators.maxLength(80), spaceValidator.noWhitespaceValidator]),
      belowLowTest: new FormControl(args.BELOW_LOW_AC_CODE, [Validators.required, Validators.maxLength(30), spaceValidator.noWhitespaceValidator]),
      inRangeTest: new FormControl(args.IN_RANGE_AC_CODE, [Validators.required, Validators.maxLength(30), spaceValidator.noWhitespaceValidator]),
      aboveHighTest: new FormControl(args.ABOVE_HIGH_AC_CODE, [Validators.required, Validators.maxLength(30), spaceValidator.noWhitespaceValidator]),
      lowValue: new FormControl(args.LOW_VALUE, [Validators.maxLength(4)]),
      highValue: new FormControl(args.HIGH_VALUE, [Validators.maxLength(4)]),
      operation: new FormControl('update'),
    });
  }

  public detailFormCode(args: any): void {
    this.createTestDecisionForm = new FormGroup({
      code: new FormControl(args.CODE, [Validators.required, Validators.maxLength(30), spaceValidator.noWhitespaceValidator]),
      descr: new FormControl(args.DESCR, [Validators.required, Validators.maxLength(80), spaceValidator.noWhitespaceValidator]),
      belowLowTest: new FormControl(args.BELOW_LOW_AC_CODE, [Validators.required, Validators.maxLength(30), spaceValidator.noWhitespaceValidator]),
      inRangeTest: new FormControl(args.IN_RANGE_AC_CODE, [Validators.required, Validators.maxLength(30), spaceValidator.noWhitespaceValidator]),
      aboveHighTest: new FormControl(args.ABOVE_HIGH_AC_CODE, [Validators.required, Validators.maxLength(30), spaceValidator.noWhitespaceValidator]),
      lowValue: new FormControl(args.LOW_VALUE, [Validators.maxLength(4)]),
      highValue: new FormControl(args.HIGH_VALUE, [Validators.maxLength(4)]),
      operation: new FormControl(''),
      testDecisionDtlsDTOList: new FormControl(''),
    });
  }
  // for edit scenario clicking on code in main grid
  public openWindow(event: any): void {
    this.isHighValue = false;
    this.isLowValue = false;
    this.notifyPopup = {};
    this.notify = {};
    this.submitted = false;
    let rowArr = []; let code: any = null;
    if (event.target.closest('tr')) {
      code = event.target.closest('tr').cells[0].innerText;
      if (code && code === event.target.innerText) {
        rowArr = this.searchData.filter(row => {
          if (row.CODE === code) { return row; }
        });
        if (rowArr[0]) {
          this.pspBaseService.getCodeTestDecision({ CODE: rowArr[0].CODE }).pipe(takeUntil(this.isActive))
            .subscribe(
              (response: any) => {
                this.translate.get('masters').subscribe((text: string) => {
                  this.createTestDecisionLabel = this.testDecisionTranslate.testDecision.infoTestDecisionLabel;
                });
                rowArr = response.results;
                this.saveButtonAddItemFlag = false;
                this.createEditReadOnlyCode = false;
                this.is_edit = false;
                this.detailFormCode(rowArr[0]);

                this.testDesCode = rowArr[0]['CODE'];
                this.testDesDescr = rowArr[0]['DESCR'];
                this.lowVal = rowArr[0]['LOW_VALUE'];
                this.highVal = rowArr[0]['HIGH_VALUE'];
                this.belowLowTest = rowArr[0]['BELOW_LOW_AC_CODE'];
                this.inRangeTestData = rowArr[0]['IN_RANGE_AC_CODE'];
                this.aboveHighTest = rowArr[0]['ABOVE_HIGH_AC_CODE'];

                this.view = [];
                this.updateGridView = [];
                rowArr[0].testDecisionDtlsDTOList.forEach((row: any) => {
                  this.view.push({
                    TESTING_TYPE: row.TESTING_TYPE,
                    ANLM_CODE: row.ANLM_CODE,
                    ANLM_DESCR: row.ANLM_DESCR,
                    operation: 'update'
                  });
                });
                this.createTestDecisionForm.controls.testDecisionDtlsDTOList.patchValue(this.view);
                this.dialogFlag = true;
              });
        }
      }
    }
  }


  public aboveHighLookupAssementCodeType(data: any): any {
    this.aboveHighlookUpdialogFlag = true;
    this.getLookupGrid(data);
  }
  public inRangeLookupAssementCodeType(data: any): any {
    this.inRangelookUpdialogFlag = true;
    this.getLookupGrid(data);
  }
  public belowTestRangeLookupAssementCodeType(data: any): any {
    this.belowTestlookUpdialogFlag = true;
    this.getLookupGrid(data);
  }
  public analyteCodeLookup(data: any): any {
    if (data.value !== '') {
      this.saveCurrent();
    } else {
      this.analytelookUpdialogFlag = true;
      this.getAnalyteLookupGrid();
    }

  }

  /* To get Below , Above High test and In Range test lookup grid Response*/
  public getLookupGrid(data: any): any {
    const req = data.control.control.value;
    const reqObj = {
      code: req,
    };
    this.pspBaseService
      .searchAssementCodeTypeLookup(reqObj)
      .pipe(takeUntil(this.isActive))
      .subscribe((response: any) => {
        if (response.status === 'SUCCESS') {
          this.aBILookUpGridData = response.results;

          // const items = response.results.filter((item: { code: any; }) => item.code == dataVal)

          // if(dataVal == null || dataVal == ''){
          //   this.aBILookUpGridData = response.results;
          // }else {
          //   this.aBILookUpGridData = items;

          // }
        }
      });
  }

  /* To get Below , Above High test and In Range test lookup grid Response*/
  public getAnalyteLookupGrid(): any {
    const reqObj = {
      code: ''
    };
    this.pspBaseService
      .analyteCodeDescription(reqObj)
      .pipe(takeUntil(this.isActive))
      .subscribe((response: any) => {
        if (response.status === 'SUCCESS') {
          this.analyteLookUpGridData = response.results;
        }
      });
  }
  public abovelookUpClose(): void {
    this.aboveHighlookUpdialogFlag = false;
    this.submitted = false;
  }
  aboveHighSelectedRowData(data: any): void {
    this.abovelookupDataFromChild = data.code;
    this.createTestDecisionForm.controls.aboveHighTest.patchValue(data.code);
    this.aboveHighlookUpdialogFlag = false;
  }
  public inRangelookUpClose(): void {
    this.inRangelookUpdialogFlag = false;
    this.submitted = false;
  }
  inRangeSelectedRowData(data: any): void {
    this.inRangelookupDataFromChild = data.code;
    this.createTestDecisionForm.controls.inRangeTest.patchValue(data.code);
    this.inRangelookUpdialogFlag = false;
  }
  public belowTestlookUpClose(): void {
    this.belowTestlookUpdialogFlag = false;
    this.submitted = false;
  }
  public analyteTypelookUpClose(): void {
    this.analytelookUpdialogFlag = false;
    this.submitted = false;
  }
  belowTestSelectedRowData(data: any): void {
    this.belowtestlookupDataFromChild = data.code;
    this.createTestDecisionForm.controls.belowLowTest.patchValue(data.code);
    this.belowTestlookUpdialogFlag = false;
  }
  analyteTestSelectedRowData(data: any): void {
    this.analyteTestlookupDataFromChild = data.code;
    this.anayteDescriptionLookupValue = data.descr;
    this.formGroup.controls.ANLM_CODE.setValue(this.analyteTestlookupDataFromChild);
    this.formGroup.controls.ANLM_DESCR.setValue(this.anayteDescriptionLookupValue);
    this.saveCurrent();
    // this.createFormGroup('ANLM_DESCR').setValue(this.anayteDescriptionLookupValue);
    // this.createTestDecisionForm.controls.ANLM_CODE.patchValue(data.code);
    // this.createTestDecisionForm.controls.ANLM_DESCR.patchValue(data.descr);
    this.analytelookUpdialogFlag = false;
  }
  /* Getting Testing Type dropdown values*/
  public gettingTestingTypeDropdown(): any {
    const reqObj = {
      VALUE_SET_NAME: 'PT_TESTING_TYPE'
    };
    this.pspBaseService
      .testingTypeDropdown(reqObj)
      .pipe(takeUntil(this.isActive))
      .subscribe(
        (response: any) => {
          if (response.status === 'SUCCESS') {
            this.testingTypeDropdownlistItems = response.results;
            this.defaultItemValue = this.testingTypeDropdownlistItems[0].DISPLAY_VALUE;
          }
        },
      );
  }
  onConfirmDeleteDialogClose(data: any): any {
    this.ConfirmdeletedialogFlag = false;
    if (data === 'Yes') {
      if (typeof this.dataItemValue === 'object') {
        this.view.forEach((row, i) => {
          if (i === this.rowIndexValue) {
            if(row.type !== 'new'){
              row.operation = 'delete';
              this.updateGridView.push(row);
            }
           
          }
        })
        // this.saveCreateForm('cancel')
        this.view.splice(this.rowIndexValue, 1);
      } else {
        this.closeEditor();
      }
    }
  }

  public checkHighValue(event: any): any {
    if (event.target.value) {
      this.highValue = Number(event.target.value);
      if (this.highValue > 100) {
        this.isHighValue = true;
        this.highValErrMsg = 'Please enter high value less than 100';
        return;
      } else {
        this.isHighValue = false;
      }
      if (this.lowValue) {
        this.lowValue = Number(this.lowValue);
        if (this.lowValue > 100) {
          this.isLowValue = true;
          this.lowValErrMsg = 'Please enter low value less than 100';
        } else {
          this.isLowValue = false;
        }
        if (this.lowValue > this.highValue) {
          this.isHighValue = true;
          this.highValErrMsg = 'Please enter high value greater than low value';
          return;
        } else {
          this.isHighValue = false;
        }
      }
    } else {
      this.isHighValue = false;
    }
  }

  public checkLowValue(event: any): any {
    if (event.target.value) {
      this.lowValue = Number(event.target.value);
      if (this.lowValue > 100) {
        this.isLowValue = true;
        this.lowValErrMsg = 'Please enter low value less than 100';
        return;
      } else {
        this.isLowValue = false;
      }
      if (this.highValue) {
        this.highValue = Number(this.highValue);
        if (this.highValue > 100) {
          this.isHighValue = true;
          this.highValErrMsg = 'Please enter high value less than 100';
        } else {
          this.isHighValue = false;
        }
        if (this.highValue < this.lowValue) {
          this.isLowValue = true;
          this.lowValErrMsg = 'Please enter low value less than high value';
          return;
        } else {
          this.isLowValue = false;
        }
      }
    } else {
      this.isLowValue = false;
    }
  }
}

