import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TestDecisionsComponent } from './test-decisions.component';

describe('TestDecisionsComponent', () => {
  let component: TestDecisionsComponent;
  let fixture: ComponentFixture<TestDecisionsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TestDecisionsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TestDecisionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
