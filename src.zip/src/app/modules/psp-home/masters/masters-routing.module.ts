import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AnalytesComponent } from './analytes/analytes.component';
import { MastersComponent } from './masters.component';
import { CategoryMasterComponent } from './category-master/category-master.component';
import { NonfoodCategoryComponent } from './nonfood-category/nonfood-category.component';
import { ChemicalsComponent } from './chemicals/chemicals.component';
import { DocumentTextComponent } from './document-text/document-text.component';
import { EnduseMasterComponent } from './enduse-master/enduse-master.component';
import { FoodcontactTypeComponent } from './foodcontact-type/foodcontact-type.component';
import { AssessmentCodesComponent } from './assessment-codes/assessment-codes.component';
import { FunctionMasterComponent } from './function-master/function-master.component';
import { MaterialTypesComponent } from './material-types/material-types.component';
import { NoteMasterComponent } from './note-master/note-master.component';
import { PerformanceStandardComponent } from './performance-standard/performance-standard.component';
import { RawmaterialNumbersComponent } from './rawmaterial-numbers/rawmaterial-numbers.component';
import { ReductionClaimComponent } from './reduction-claim/reduction-claim.component';
import { ResinTypesComponent } from './resin-types/resin-types.component';
import { SystemTypesComponent } from './system-types/system-types.component';
import { TestDecisionsComponent } from './test-decisions/test-decisions.component';
const routes: Routes = [
  {
    path: '',
    component: MastersComponent,
    children: [
      { path: '', redirectTo: 'analytes', pathMatch: 'full' },
      { path: 'analytes', component: AnalytesComponent },
      { path: 'categoryMaster', component: CategoryMasterComponent },
      { path: 'nonfoodCategoryMaster', component: NonfoodCategoryComponent },
      { path: 'chemicals', component: ChemicalsComponent },
      { path: 'documentText', component: DocumentTextComponent },
      { path: 'endUseMaster', component: EnduseMasterComponent },
      { path: 'foodContactType', component: FoodcontactTypeComponent },
      { path: 'assessmentCodes', component: AssessmentCodesComponent },
      { path: 'functionMaster', component: FunctionMasterComponent },
      { path: 'materialTypes', component: MaterialTypesComponent },
      { path: 'noteMaster', component: NoteMasterComponent },
      { path: 'performanceStandard', component: PerformanceStandardComponent },
      { path: 'rawMaterialNumbers', component: RawmaterialNumbersComponent },
      { path: 'reductionClaimMaster', component: ReductionClaimComponent },
      { path: 'resinTypes', component: ResinTypesComponent },
      { path: 'systemTypesMaster', component: SystemTypesComponent },
      { path: 'testDecisions', component: TestDecisionsComponent },
    ]
  }];
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MastersRoutingModule { }
