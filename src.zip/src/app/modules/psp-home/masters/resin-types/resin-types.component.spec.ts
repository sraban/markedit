import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ResinTypesComponent } from './resin-types.component';

describe('ResinTypesComponent', () => {
  let component: ResinTypesComponent;
  let fixture: ComponentFixture<ResinTypesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ResinTypesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ResinTypesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
