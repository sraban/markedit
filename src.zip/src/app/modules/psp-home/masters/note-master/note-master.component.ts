import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { PspBaseService } from '../../services/psp-base.service';
import { ValidationComponent } from '../../../../app-shared/validation/validation.component'
const spaceValidator = new ValidationComponent();

@Component({
  selector: 'app-note-master',
  templateUrl: './note-master.component.html',
  styleUrls: ['./note-master.component.scss']
})
export class NoteMasterComponent implements OnInit {
  public noteMasterForm: FormGroup | any;
  controlNames: any;
  control: any;
  gridHeaders: any;
  public notify: any;
  submitted = false;
  showGrid = false;
  gridData: any = [];
  saveTitleLabel: any;
  deletedialogFlag!: boolean;
  requestDataForDelete: any;
  deleteCode: any;
  fromUpdateWindow = false;
  public pageable = {
    pageable: {
      position: 'both',
    },
    pageSize: 25,
  };
  export: { exportto: boolean; fileName: string } = {
    exportto: true,
    fileName: 'Note Master',
  };
  editorCol = {
    title: 'Actions',
    width: 50,
    type: 'command',
    openPopUp: true,
  };
  loader!: boolean;
  private isActive = new Subject();
  masterTranslate: any;
  commonTranslate: any;
  public deleteTitleLabel = '';
  createNoteLabel = '';
  updateNoteLabel = '';
  gridDataEnable = false;
  dialogFlag = false;
  saveAndClose = false;
  public notifyPopup: any;
  noteCreateForm: FormGroup | any;
  noteStandard: any;
  closeConfirmationFlag = false;
  closeConfirmation: any;
  confirmMessage: any;
  noteStandardGroupData: any;
  noteStandardData: any;
  noteTypeData: any;
  noteEditCreateForm: FormGroup | any;
  editdialogFlag!: boolean;
  fromSaveDialog = false;
  
  constructor(
    private formBuilder: FormBuilder,
    private pspBaseService: PspBaseService,
    private translate: TranslateService) { }

  ngOnInit(): void {
    this.initializeForm();
    this.translate.get('masters').subscribe((text: string) => {
      this.masterTranslate = text;
      this.deleteTitleLabel = this.masterTranslate.deleteConfirmation;
      this.createNoteLabel = this.masterTranslate.noteMaster.createNoteMaster;
      this.closeConfirmation = this.masterTranslate.noteMaster.closeConfirmation;
      this.confirmMessage = this.masterTranslate.noteMaster.confirmMessage;
      this.updateNoteLabel = this.masterTranslate.noteMaster.editNoteMaster;
      this.saveTitleLabel = this.masterTranslate.saveConfirmation;
    });
    this.translate.get('common').subscribe((text: string) => {
      this.commonTranslate = text;
    });
    this.initializeCreateNoteForm();
    this.noteType();
    this.noteStandardGroup();
    this.editNoteMasterForm();
  }

  initializeForm(): any {
    this.noteMasterForm = this.formBuilder.group({
      code: new FormControl('', [Validators.required]),
      note: new FormControl('', [Validators.required]),
    });
    this.controlNames = {
      code: 'Code',
      note: 'Note Text'
    };
    this.control = new FormGroup({});
    this.gridHeaders = [
      { field: 'code', header_title: 'Code', width: 50, type: 'input_text', editable: false },
      { field: 'note', header_title: 'Note Text', width: 200, type: 'input_text', editable: true },
      { field: 'display_value', header_title: 'Note Type', width: 150, type: 'input_text', editable: true },
      { field: 'sg_display_value', header_title: 'Standard Group', width: 150, type: 'input_text', editable: true }
    ];
  }

  initializeCreateNoteForm(): any {
    this.noteCreateForm = this.formBuilder.group({
      code: new FormControl('', [Validators.required,spaceValidator.noWhitespaceValidator]),
      note: new FormControl('', [Validators.required,spaceValidator.noWhitespaceValidator]),
      standardGroup: new FormControl(''),
      noteType: new FormControl('', [Validators.required]),
    });
    this.controlNames = {
      code: 'Code',
      note: 'Note Text',
      noteType: 'Note Type',
      standardGroup: 'Standard Group'
    };
  }

  editNoteMasterForm(): void {
    this.noteEditCreateForm = this.formBuilder.group({
      code: new FormControl({ value: '', disabled: true }, [Validators.required,spaceValidator.noWhitespaceValidator]),
      note: new FormControl('', [Validators.required,spaceValidator.noWhitespaceValidator]),
      standardGroup: new FormControl(''),
      noteType: new FormControl('', [Validators.required]),
    });
    this.controlNames = {
      code: 'Code',
      note: 'Note Text',
      noteType: 'Note Type',
      standardGroup: 'Standard Group'
    };
  }
  public clear(): any {
    this.noteMasterForm.reset();
    this.showGrid = false;
    this.notify = {};
  }

  public create(): void {
    this.dialogFlag = true;
    this.submitted = false;
    this.notify = {};
    this.notifyPopup = {};
    this.noteCreateForm.reset();
  }

  public search(): any {
    this.showGrid = true;
    const reqObj = {
      code: this.noteMasterForm.controls.code.value,
      note: this.noteMasterForm.controls.note.value
    };
    this.searchNoteMaster(reqObj);
  }

  // get note standard dropdown data
  noteType(): void {
    const reqParams = {};
    this.pspBaseService
      .noteType(reqParams)
      .pipe(takeUntil(this.isActive))
      .subscribe(
        (response: any) => {
          if (response.status === 'SUCCESS') {
            this.noteTypeData = response.results;
          }
        },
        (err: any) => {
          this.notify = {
            style: 'error',
            content: err
          };
        }
      );
  }

  // get note standard group dropdown data
  noteStandardGroup(): void {
    const reqParams = {};
    this.pspBaseService
      .noteStandardGroup(reqParams)
      .pipe(takeUntil(this.isActive))
      .subscribe((response: any) => {
        if (response.status === 'SUCCESS') {
          this.noteStandardGroupData = response.results;
        }
      },
        (err: any) => {
          this.notify = {
            style: 'error',
            content: err
          };
        });
  }


  // Search note master
  public searchNoteMaster(reqObj: any): any {
    this.loader = true;
    this.notify = {};
    this.pspBaseService
      .searchNoteMaster(reqObj)
      .pipe(takeUntil(this.isActive))
      .subscribe(
        (response: any) => {
          if (response.status === 'SUCCESS') {
            this.gridData = response.results;
            this.loader = false;
            if (this.gridData.length === 0) {
              this.notify = {
                style: 'info',
                content: this.masterTranslate.noRecordsFoundWithTheSearchcriteria
              };
            }
            this.gridDataEnable = true;
          }
          const formCtrls: any = {};
          this.gridHeaders.forEach((item: any) => {
            if (item.field === 'note') {
              formCtrls[item.field] = new FormControl(true);
            }
            else {
              formCtrls[item.field] = new FormControl(false);
            }
            this.control = new FormGroup(formCtrls);
          });
        },
        (err: any) => {
          this.loader = false;
          this.notify = {
            style: 'error',
            content: this.commonTranslate.noRecordsFoundWithTheSearchcriteria
          };
        }
      );
  }

  public editHandler(data: any): any {
    if (data[0] === 'openDialog') {
      this.notifyPopup = {};
      this.submitted = true;
      this.noteCreateForm.markAllAsTouched();
      this.editdialogFlag = true;
      this.noteEditCreateForm.reset();
      this.noteEditCreateForm.patchValue({
        code: data[1].code,
        note: data[1].note,
        standardGroup: data[1].evsd_sg_seq?Number(data[1].evsd_sg_seq):'',
        noteType: Number(data[1].evsd_typ_seq)
      });
      this.onValueChange(Number(data[1].evsd_sg_seq));
    } else if (data[0] === 'removeData') {
      this.deletedialogFlag = true;
      this.requestDataForDelete = data[1];
      this.deleteCode = data[1].code;
    }
  }

  // for saving data in main grid
  public update(): void {
    const reqObj = {
      code: this.noteEditCreateForm.controls.code.value,
      note: this.noteEditCreateForm.controls.note.value,
      evsd_typ_seq: this.noteEditCreateForm.controls.noteType.value,
      evsd_sg_seq: this.noteEditCreateForm.controls.standardGroup.value,
    };
    this.loader = true;
    this.pspBaseService
      .updateNoteMaster(reqObj)
      .pipe(takeUntil(this.isActive))
      .subscribe(
        (response: any) => {
          this.loader = false;
          this.editdialogFlag = false;
          if (response.status === 'SUCCESS') {
            this.onEditDialogClose();
            this.submitted = false;
            this.search();
            this.notify = {
              content: this.masterTranslate.dataSavedSuccessfully,
              style: 'success'
            };
            this.saveAndClose = false;
          } else {
            if (this.fromSaveDialog) {
              this.notifyPopup = {
                style: 'error',
                content: response.results[0].message
              };
              this.editdialogFlag = true;
              this.submitted = false;
              this.fromSaveDialog = false;
            }
            else {
              this.notifyPopup = {
                style: 'error',
                content: response.results[0].message
              };
              this.editdialogFlag = true;
            }
          }
        },
        (err: any) => {
          this.notify = {
            style: 'error',
            content: err
          };
        }
      );
  }



  // deleting note master record
  onDeleteDialogClose(data: any): any {
    this.deletedialogFlag = false;
    if (data === 'Yes') {
      this.onAccept();
    }
  }

  onAccept(): any {
    this.loader = true;
    this.pspBaseService
      .deleteNoteMaster(this.requestDataForDelete)
      .pipe(takeUntil(this.isActive))
      .subscribe(
        (response: any) => {
          this.loader = false;
          if (response.status === 'SUCCESS') {
            this.deletedialogFlag = false;
            this.notify = {
              content: this.masterTranslate.recordDeletedSuccessfully,
              style: 'success'
            };
            this.gridData = this.gridData.filter((row: any) => {
              if (row.code !== this.requestDataForDelete.code) {
                return row;
              }
            });
          } else {
            this.notify = {
              content: response.results[0].message,
              style: 'error'
            };
            this.deletedialogFlag = false;
          }
        }
      );
  }
  // create new note master record
  public save(): void {
    this.submitted = true;
    this.noteCreateForm.markAllAsTouched();
    const reqObj = {
      code: this.noteCreateForm.controls.code.value,
      note: this.noteCreateForm.controls.note.value,
      evsd_typ_seq: this.noteCreateForm.controls.noteType.value,
      evsd_sg_seq: this.noteCreateForm.controls.standardGroup.value,
    };
    this.createNoteMaster(reqObj);
  }

  public createNoteMaster(reqObj: any): any {
    this.submitted = true;
    if (this.noteCreateForm.valid) {
      this.loader = true;
      this.pspBaseService
        .createNoteMaster(reqObj)
        .pipe(takeUntil(this.isActive))
        .subscribe(
          (response: any) => {
            this.loader = false;
            if (response.status === 'SUCCESS') {
              this.dialogFlag = false;
              this.submitted = false;
              this.search();
              this.notify = {
                style: 'success',
                content: this.masterTranslate.dataSavedSuccessfully
              };
            } else {
              if (this.fromSaveDialog) {
                this.notifyPopup = {
                  style: 'error',
                  content: response.results[0].message
                };
                this.dialogFlag = true;
                this.submitted = false;
                this.fromSaveDialog = false;
              }
              else {
                this.notifyPopup = {
                  style: 'error',
                  content: response.results[0].message
                };
                this.dialogFlag = true;
              }
            }
          }
        );
    }
  }

  public onDialogClose(): void {
    this.notify = {};
    this.noteStandardData = [];
    if (this.noteCreateForm.valid){
      this.saveAndClose = true;
    }else{
      this.submitted = false;
      this.dialogFlag = false;
    }
  }
  onEditDialogClose(): void {
    this.notify = {};
    this.noteStandardData = [];
    if (this.noteEditCreateForm.valid){
      this.saveAndClose = true;
      this.fromUpdateWindow = true;
    }else{
      this.submitted = false;
      this.editdialogFlag = false;
    }
  }
  savedata(val: any): any {
    this.saveAndClose = false;
    if (val === 'Yes'){
      this.fromSaveDialog = true;
      this.dialogFlag = false;
      if (this.fromUpdateWindow) {
        this.update();
        this.fromUpdateWindow = false;
      }
      else {
        this.save();
      }
    }else if(val === 'No'){
      this.dialogFlag = false;
      this.editdialogFlag = false;
    }else if(val === 'Close'){
      this.dialogFlag = true;
    }
  }
  // Get note standard data on selecting note standard group
  onValueChange(event: any): void {
    this.loader = true;
    const reqParams = { std_code: event };
    this.pspBaseService
      .noteStandard(reqParams)
      .pipe(takeUntil(this.isActive))
      .subscribe((response: any) => {
        if (response.status === 'SUCCESS') {
          this.loader = false;
          this.noteStandardData = response.results;
        } else {
          this.loader = false;
        }
      },
        (err: any) => {
          this.loader = false;

          this.notify = {
            style: 'error',
            content: err
          };
        });
  }
}
