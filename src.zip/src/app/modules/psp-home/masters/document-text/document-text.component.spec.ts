import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DocumentTextComponent } from './document-text.component';

describe('DocumentTextComponent', () => {
  let component: DocumentTextComponent;
  let fixture: ComponentFixture<DocumentTextComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DocumentTextComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DocumentTextComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
