import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { DataStateChangeEvent, GridDataResult } from '@progress/kendo-angular-grid';
import { State, process } from '@progress/kendo-data-query';
import { PspBaseService } from '../../services/psp-base.service';
import { TranslateService } from '@ngx-translate/core';
import { takeUntil } from 'rxjs/operators';
import { Subject } from 'rxjs';
import { ValidationComponent } from '../../../../app-shared/validation/validation.component'
const spaceValidator = new ValidationComponent();

const createFormGroup = (dataItem: any) =>
  new FormGroup({
    code: new FormControl(dataItem.code, [Validators.required,spaceValidator.noWhitespaceValidator]),
    doc_text: new FormControl(dataItem.doc_text, [Validators.required,spaceValidator.noWhitespaceValidator]),
    doc_type: new FormControl(dataItem.doc_type)
  });

@Component({
  selector: 'app-document-text',
  templateUrl: './document-text.component.html',
  styleUrls: ['./document-text.component.scss']
})
export class DocumentTextComponent implements OnInit {
  public dropItems: Array<string> = [];
  public textAreaWithRowsValue = 'Initial rows 5';
  submitted: any;
  documentText: FormGroup | any;
  public createForm: FormGroup;
  controlNames: any;
  public state: State = {};
  deleteCode: any;
  commonTranslate: any;
  public deleteTitleLabel = '';
  lastAction = '';
  saveAndClose = false;
  lookUpHeader: any = [];
  public handler: any;
  public isDialog: any = false;
  deletedialogFlag = false;
  public editDialogFlag!: boolean;
  savepop = '';
  fromSaveDialog = false;
  dialogFlag = false;
  public testCodeData: any[] = [];
  requestDataForDelete: any;
  formControl: any;
  public showSearchTest = false;
  dialogFlagEdit = false;
  public loader: any;
  public searchData: any[] = [];
  public editedRowIndex: any = null;
  private isActive = new Subject();
  public notifyPopup: any;
  masterTranslate: any;
  public saveTitleLabel: any;
  createLabel: any;
  notify: any;
  editData=false;
  editDocumentCode:any;
  DATA_VALUE:any
  editedData={doc_text:"",doc_type:""};
  editLabel="";
  public pageable = {
    pageable: {
      position: 'both',
    },
    pageSize: 25,
  };
  public showSearch = false;
  public gridData: GridDataResult = process(this.searchData, this.state);
  dataFromChild: any;
  editorCol = {
    title: 'Actions',
    width: 50,
    type: 'command',
    openPopUp: true
  };
  export: { exportto: boolean, fileName: string } = {
    exportto: true,
    fileName: 'Document Text'
  };
  public search(): any {
    this.showSearch = true;
  }
  public testCodedocumentTextMaster(): any {
    this.loader = true;
    const reqObj = {};
    this.api.getDocumentTextFunction(reqObj).pipe(takeUntil(this.isActive)).subscribe(
      (response: any) => {
        if (response.status === 'SUCCESS') {
          this.loader = false;
          this.testCodeData = response.results;
        }
      },
      (err: any) => {
        this.notify = {
          content: this.commonTranslate.serverError,
          style: 'error'
        };
      });
  }
  public dropdowndocumentText(): any {
    const reqObj = {
      "VALUE_SET_NAME": "PT_DOC_TEXT_TYPE"
    };
    this.loader = true;
    this.api.dropdowndocumentTextMaster(reqObj).pipe(takeUntil(this.isActive)).subscribe(
      (response: any) => {
        this.loader = false;
        this.dropItems=response.results
        this.DATA_VALUE = response.results[0]["DATA_VALUE"];
      })
       
  }

  public dataStateChange(state: DataStateChangeEvent): void {
    this.state = state;
    this.gridData = process(this.searchData, this.state);
  }
  opened=false;
  public documenTextData: any;
  constructor(private formBuilder: FormBuilder,
              public api: PspBaseService, private translate: TranslateService) {
    this.translate.get('masters').subscribe((text: string) => {
      this.commonTranslate = text;
    });
    this.documentText = this.formBuilder.group({
      code: [''],
      doc_text: [''],
      doc_type: [''],
    });
    
    this.createForm = new FormGroup({
      code: new FormControl('', [Validators.required,spaceValidator.noWhitespaceValidator]),
      doc_text: new FormControl('', [Validators.required,spaceValidator.noWhitespaceValidator]),
      doc_type: new FormControl(''),
    });
    this.controlNames = {
      code: 'Code',
      doc_text: 'Text',
    };
  }
  public removeHandler(handler: any, isDialog?: any): any {
    if (handler && isDialog) {
      this.isDialog = isDialog;
      this.handler = handler;
      return false;
    }
    const product = handler.dataItem;
    this.loader = true;
    this.api
      .deleteDocumentTextMaster(product)
      .pipe(takeUntil(this.isActive))
      .subscribe(
        (response: any) => {
          this.loader = false;
          if (response.status === 'SUCCESS') {
            this.searchData = this.searchData.filter((row: any) => {
              if (row.code !== product.code) {
                return row;
              }
            });
            this.notify = {
              style: 'success',
              content: this.commonTranslate.recordDeletedSuccessfully
            };
          } else {
            this.notify = {
              style: 'error',
              content: response.results[0].message
            };
          }
        },
        (err: any) => {
          this.notify =
          {
            style: 'error',
            content: err.statusText
          };
        }
      );
    this.isDialog = false;
  }

  ngOnInit(): void {
    this.lookUpHeader = [
      {
        field: 'code',
        header_title: 'Code',
        width: 150,
        type: 'input_text',
        editable: false,
        maxlength: 8
      },
      {
        field: 'doc_text',
        header_title: 'Text',
        width: 300,
        type: 'input_text',
        editable: false,
        maxlength: 100
      },
      {
        field: 'doc_type',
        header_title: 'Type',
        width: 150,
        type: 'dropdown',
        editable: false,
        maxlength: 6,
        dropdown_list:this.dropItems
      }
    ];
    this.dropdowndocumentText();
    this.translate.get('masters').subscribe( (text: string) => {
      this.masterTranslate = text;
      this.deleteTitleLabel = this.masterTranslate.deleteConfirmation;
      this.saveTitleLabel = this.masterTranslate.saveConfirmation;
      this.createLabel = this.masterTranslate.documentText.createDocumentText;
      this.editLabel = this.masterTranslate.documentText.editDocumentText;
    });
  }

  public editHandler(data: any): any {
    if (data[0] === 'openDialog') {

      this.dialogFlag = true;
      this.submitted = false;
      this.createForm = createFormGroup(data[1]);
      this.editedRowIndex = data.rowIndex;
      this.editData=true;
      this.editedData.doc_type = data[1].doc_type;
      this.editedData.doc_text = data[1].doc_text;
      this.editDocumentCode = data[1].code;
    } else if (data[0] === 'removeData') {
      this.deletedialogFlag = true;
      this.requestDataForDelete = data[1];
      this.deleteCode = data[1].code;
    }
  }
  public saveHandler(data: any): void {
    this.loader = true;
    this.api
      .updateDocumentTextMaster(data)
      .pipe(takeUntil(this.isActive))
      .subscribe(
        (response: any) => {
          this.loader = false;
          if (response.status === 'SUCCESS') {
            this.notify = {
              style: 'success',
              content: this.commonTranslate.dataSavedSuccessfully
            };
            Object.assign(this.searchData.find((row: any) => row.code === data.code), data);
            this.dialogFlag = false;
            this.createForm.reset();
            this.editData = false;
          } else {
            this.notify = {
              style: 'error',
              content: response.results[0].message
            };
            this.editDialogFlag = false;
          }
        }
      );
  }
  
  public onDialogClose(): void {
    this.submitted = false;
    this.notify = {};
    this.notifyPopup = {};
    if (this.createForm.valid) {
      if(this.editData){
        if(this.editedData.doc_text !== this.createForm.value.doc_text || this.editedData.doc_type !== this.createForm.value.doc_type){
          this.saveAndClose = true;
        }else{
          this.dialogFlag =false;
        }
      }else{
        this.saveAndClose = true;
      }
    }else{
      this.dialogFlag =false;
    }
  }


  public creatingDocumentTextMaster(reqObj: any): any {
    this.loader = true;
    this.submitted = true;
    this.notify = {}
    this.api
      .createDocumentTextMaster(reqObj)
      .subscribe(
        (response: any) => {
          this.loader = false;
          if (response.status === 'SUCCESS') {
            this.Search();
            this.notify = {
              style: 'success',
              content: this.commonTranslate.dataSavedSuccessfully
            };
            this.dialogFlag = false;
            this.submitted=false;
            this.createForm.reset();
          }
          else {
            if (this.fromSaveDialog) {
              this.notifyPopup = {
                style: 'error',
                content: response.results[0].message
              };
              this.dialogFlag = true;
              this.submitted = true;
              this.fromSaveDialog = false;
            }
            else {
              if (response.status === 'ERROR') {
                this.savepop = response.results[0].message;
              }
              this.notifyPopup = {
                style: 'error',
                content: response.results[0].message
              };
              this.dialogFlag = true;
            }
          }
        }
      );
  }
  Search(): any {
    this.notify = {};
    this.loader = true;
    (document as any).querySelectorAll('.k-grid-cancel-command').forEach((el: any) => { el.click(); });
    this.api.getDocumentTextFunction(this.documentText.value).subscribe((res: any) => {
      if (res.status === 'SUCCESS') {
        this.searchData = res.results;
        this.loader = false;
        if (this.searchData.length === 0) {
          this.notify =
          {
            style: 'info',
            content: this.commonTranslate.noRecordsFoundWithTheSearchcriteria
          };
        }else{
          this.showSearchTest = true;
        }
      }
      const formCtrls: any = {};
      this.lookUpHeader.forEach((item: any) => {
        if (item.field === 'High Value') {
          formCtrls[item.field] = new FormControl(false);
        } else if (item.field === 'descr') {
          formCtrls[item.field] = new FormControl(true);
        } else {
          formCtrls[item.field] = new FormControl(true);
        }
        this.formControl = new FormGroup(formCtrls);
      });
    });
  }
  
  onDeleteDialogClose(data: any): any {
    this.deletedialogFlag = false;
    if (data === 'Yes') {
      this.onAccept();
    }
  }
  onAccept(): any {
    this.loader = true;
    this.api
      .deleteDocumentTextMaster(this.requestDataForDelete)
      .pipe(takeUntil(this.isActive))
      .subscribe(
        (response: any) => {
          this.loader = false;
          if (response.status === 'SUCCESS') {
            this.deletedialogFlag = false;
            this.notify = {
              content: this.commonTranslate.recordDeletedSuccessfully,
              style: 'success'
            };
            this.searchData = this.searchData.filter((row: any) => {
              if (row.code !== this.requestDataForDelete.code) {
                return row;
              }
            });
          } else {
            this.notify = {
              content: response.results[0].message,
              style: 'error'
            };
            this.deletedialogFlag = false;
          }
        }
      );
  }
  close(): any {
    this.dialogFlag = false;
    this.notify = {};
    this.notifyPopup = {};
  }
  create(): any {
    (document as any).querySelectorAll('.k-grid-cancel-command').forEach((el: any) => { el.click(); });
    this.dialogFlag = true;
    this.submitted = false;
    this.editData=false;
    this.createForm.reset();
    this.createForm.controls.doc_type.setValue(this.DATA_VALUE);
    this.notify = {};
    this.notifyPopup = {};
  }
  onClear(): any {
    this.documentText.reset();
    this.showSearchTest = false;
    this.notify = {};
  }
  public save(): void {
    this.submitted = true;
    this.createForm.markAllAsTouched();
    if (this.createForm.valid) {
      if(this.editData){
        this.saveHandler(this.createForm.value);
      }else{
        this.creatingDocumentTextMaster(this.createForm.value);
      }
    }
  }
  public savedata(data: any): any {
    this.saveAndClose = false;
    if (data === 'Yes') {
      this.save();
      this.fromSaveDialog = true;
      this.dialogFlag = true;
    }else if(data === "No"){
      this.dialogFlag = false;
    }else if(data === "Close"){
      this.dialogFlag = true;
    }
  }
  public closeText(status: any): any {
    this.opened = false;
  }
  public insertText(): any {
    this.createForm.controls.doc_text.patchValue(this.documenTextData);
    this.opened = false;
  }
  public nf_justification_fn(): any {
    this.documenTextData = this.createForm.controls.doc_text.value;
  }

  
  // savedata(val: any): any {
  //   if (val) {
  //     if (this.savepop === '') {
  //       if(this.editData){
  //         this.saveHandler(this.createForm.value)
  //         this.notifyPopup = {};
  //       }else{
  //       this.createForm.markAllAsTouched();
  //       const reqObj = {
  //         code: this.createForm.controls.code.value,
  //         doc_text: this.createForm.controls.doc_text.value,
  //         doc_type: this.createForm.controls.doc_type.value
        
  //       };
  //       this.creatingDocumentTextMaster(reqObj);
  //     }
  //     } else {
  //       this.notify = {
  //         style: 'error',
  //         content: this.savepop
  //       };
  //     }
  //     this.submitted = false;
  //   }
  //   this.saveAndClose = false;
  //   this.dialogFlag = false;
  // }
}
