import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Router, NavigationStart } from '@angular/router';
import { PspBaseService } from '../../psp-home/services/psp-base.service';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { TextBoxComponent } from '@progress/kendo-angular-inputs';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-masters',
  templateUrl: './masters.component.html',
  styleUrls: ['./masters.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class MastersComponent implements OnInit {
  public listItems: any;
  private isActive = new Subject();
  valueChangeItem: any;
  sub: any;
  displayVal: any;
  dropdownVal: any;
  directRoute = false;
  selectedValue: any;

  public defaultItem: any = {
    DATA_VALUE: 'Choose Master...',
    DISPLAY_VALUE: '',
    STATUS: null,
    VALUE_SET_NAME: null
  };
   constructor(private pspBaseService: PspBaseService, private routing: Router) {
    this.routing.events.subscribe((event) => {
      if (event instanceof NavigationStart) {
          const routeUrl = event.url;
          let currentValue;
          currentValue = routeUrl.split('?')[0].split('/').pop();
          this.valueChangeItem = currentValue;
          this.dropdownVal = currentValue;
          this.directRoute = true;
          this.displayVal = this.dropdownVal.split(/(?=[A-Z])/).join(' ');
          const first = this.displayVal.substr(0, 1).toUpperCase();
          this.displayVal = first + this.displayVal.substr(1);
          if (this.displayVal === 'Masters'){
            this.displayVal = 'Analytes';
          }
          if(this.displayVal){
            this.selectedValue = this.displayVal;
          }else{
            this.selectedValue = 'Choose Master...';
          }
          
      }
    });
   }

  ngOnInit(): void {
    this.sub = this.routing.url;
    this.valueChangeItem = this.routing.url.split('/', 3)[2];
    const first = this.valueChangeItem.substr(0, 1).toUpperCase();
    this.valueChangeItem = first + this.valueChangeItem.substr(1);
    this.valueChangeItem = this.valueChangeItem.split(/(?=[A-Z])/).join(' ');
    this.selectedValue = this.valueChangeItem;
    this.gettingCategoryDropdown();
  }

  public gettingCategoryDropdown(): any {
    const reqObj = {
      VALUE_SET_NAME: 'PRODTRACK_MASTER',
    };
    this.pspBaseService.getCategoryDropdown(reqObj).pipe(takeUntil(this.isActive)).subscribe(
      (response: any) => {
        if (response.status === 'SUCCESS') {
          this.listItems = response.results;
        }
      },
      (err: any) => {
      }
    );
  }
  public changeRouting(menu: any): void {
    this.directRoute = false;
    this.valueChangeItem = menu;
    switch (menu) {
      case 'Analytes':
        this.routing.navigate(['/masters/analytes']);
        break;
      case 'Category Master':
        this.routing.navigate(['/masters/categoryMaster']);
        break;
      case 'Chemicals':
        this.routing.navigate(['/masters/chemicals']);
        break;
      case 'Document Text':
        this.routing.navigate(['/masters/documentText']);
        break;
      case 'End Use Master':
        this.routing.navigate(['/masters/endUseMaster']);
        break;
      case 'Food Contact Type':
        this.routing.navigate(['/masters/foodContactType']);
        break;
      case 'Assessment Codes':
        this.routing.navigate(['/masters/assessmentCodes']);
        break;
      case 'Function Master':
        this.routing.navigate(['/masters/functionMaster']);
        break;
      case 'Material Types':
        this.routing.navigate(['/masters/materialTypes']);
        break;
      case 'Note Master':
        this.routing.navigate(['/masters/noteMaster']);
        break;
      case 'Performance Standard':
        this.routing.navigate(['/masters/performanceStandard']);
        break;
      case 'Raw Material Numbers':
        this.routing.navigate(['/masters/rawMaterialNumbers']);
        break;
      case 'Reduction Claim Master':
        this.routing.navigate(['/masters/reductionClaimMaster']);
        break;
      case 'Resin Types':
        this.routing.navigate(['/masters/resinTypes']);
        break;
      case 'System Types Master':
        this.routing.navigate(['/masters/systemTypesMaster']);
        break;
      case 'Test Decisions':
        this.routing.navigate(['/masters/testDecisions']);
        break;
      case 'Nonfood Category Master':
        this.routing.navigate(['/masters/nonfoodCategoryMaster']);
        break;
      default:
        this.routing.navigate(['/masters']);
    }
  }
}
