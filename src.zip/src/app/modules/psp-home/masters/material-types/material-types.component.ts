import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { PspBaseService } from '../../services/psp-base.service';
import { ExcelExportData } from '@progress/kendo-angular-excel-export';
import { DataStateChangeEvent, GridDataResult } from '@progress/kendo-angular-grid';
import { State, process } from '@progress/kendo-data-query';
import { TranslateService } from '@ngx-translate/core';
import { takeUntil } from 'rxjs/operators';
import { Subject } from 'rxjs';
import { ValidationComponent } from '../../../../app-shared/validation/validation.component'
const spaceValidator = new ValidationComponent();

@Component({
  selector: 'app-material-types',
  templateUrl: './material-types.component.html',
  styleUrls: ['./material-types.component.scss']
})
export class MaterialTypesComponent implements OnInit {
  materialTypeForm: FormGroup | any;
  windowOpen = false;
  lookUpHeader: any = [];
  control: any;
  notify: any;
  deletedialogFlag = false;
  requestDataForDelete: any;
  deleteCode: any;
  submitted: any;
  saveAndClose = false;
  fromSaveDialog = false;
  dialogFlag = false;
  public pageable = {
    pageable: {
      position: 'both',
    },
    pageSize: 25,
  };
  public showGrid = false;
  public state: State = {};
  public searchData: any[] = [];
  public loader: any;
  public editedRowIndex: any = null;
  private isActive = new Subject();
  public isDialog: any = false;
  public handler: any;
  public deleteTitleLabel = '';
  public createForm: FormGroup | any;
  public notifyPopup: any;
  masterTranslate: any;
  controlNames: any;
  dataFromChild: any;
  savedialogFlag = false;
  public saveTitleLabel: any;
  titleLabel = '';
  editorCol = {
    title: 'Actions',
    width: 50,
    type: 'command',
    openPopUp: false
  };
  export: { exportto: boolean, fileName: string } = {
    exportto: true,
    fileName: 'Material Type'
  };
  public allDataSet: GridDataResult = process(this.searchData, this.state);

  public dataStateChange(state: DataStateChangeEvent): void {
    this.state = state;
    this.allDataSet = process(this.searchData, this.state);
  }
  constructor(private formBuilder: FormBuilder, public pspBaseService: PspBaseService, private translate: TranslateService) {
  }

  ngOnInit(): void {
    this.initializeForm();
    this.initializeCreateForm();
    this.translate.get('masters').subscribe( (text: string) => {
      this.masterTranslate = text;
      this.deleteTitleLabel = this.masterTranslate.deleteConfirmation;
      this.saveTitleLabel = this.masterTranslate.saveConfirmation;
      this.titleLabel = this.masterTranslate.materialType.createMaterialType;
    });
  }

  initializeForm(): any {
    this.materialTypeForm = this.formBuilder.group({
      code: new FormControl('', [Validators.required]),
      descr: new FormControl('', [Validators.required]),
    });
    this.controlNames = {
      code: 'Code',
      descr: 'Description'
    };
    this.control = new FormGroup({});
    this.lookUpHeader = [
      { field: 'code', header_title: 'Code', width: 150, type: 'input_text', editable: false, maxlength: '20'},
      { field: 'descr', header_title: 'Description', width: 350, type: 'input_text', editable: true, maxlength: '50'},
    ];
  }
  public create(): void {
    (document as any).querySelectorAll('.k-grid-cancel-command').forEach((el: any) => { el.click(); });
    this.dialogFlag = true;
    this.submitted = false;
    this.savedialogFlag = false;
    this.notify = {};
    this.notifyPopup = {};
    this.createForm.reset();
  }
  public search(): any {
    (document as any).querySelectorAll('.k-grid-cancel-command').forEach((el: any) => { el.click(); });
    this.showGrid = true;
    const reqObj = {
      code: this.materialTypeForm.controls.code.value,
      descr: this.materialTypeForm.controls.descr.value
    };
    this.searchMaterialType(reqObj);
  }
  // Search Material claim
  public searchMaterialType(reqObj: any): any {
    this.loader = true;
    this.notify = {};
    this.pspBaseService
      .getMaterialTypeMaster(reqObj)
      .pipe(takeUntil(this.isActive))
      .subscribe(
        (response: any) => {
          if (response.status === 'SUCCESS') {
            this.searchData = response.results;
            this.loader = false;
            if (this.searchData.length === 0) {
              this.notify = {
                style: 'info',
                content: this.masterTranslate.noRecordsFoundWithTheSearchcriteria
              };
            }
          }
          const formCtrls: any = {};
          this.lookUpHeader.forEach((item: any) => {
            if (item.field === 'descr') {
              formCtrls[item.field] = new FormControl('', [Validators.required, spaceValidator.noWhitespaceValidator]);
            }
            else {
              formCtrls[item.field] = new FormControl(false);
            }
            this.control = new FormGroup(formCtrls);
          });
        },
        (err: any) => {
          this.loader = false;
          this.notify = {
            style: 'error',
            content: this.masterTranslate.noRecordsFoundWithTheSearchcriteria
          };
        }
      );
  }
  public createMaterialTypeMaster(reqObj: any): any {
    this.submitted = true;
    if (this.createForm.valid) {
      this.loader = true;
      this.pspBaseService
        .createMaterialTypeMaster(reqObj)
        .pipe(takeUntil(this.isActive))
        .subscribe(
          (response: any) => {
            this.loader = false;
            if (response.status === 'SUCCESS') {
              this.dialogFlag = false;
              this.submitted = false;
              this.search();
              this.notify = {
                style: 'success',
                content: this.masterTranslate.dataSavedSuccessfully
              };
            } else {
              if (this.fromSaveDialog) {
                this.notifyPopup = {
                  style: 'error',
                  content: response.results[0].message
                };
                this.dialogFlag = true;
                this.submitted = false;
                this.fromSaveDialog = false;
              }
              else {
                this.notifyPopup = {
                  style: 'error',
                  content: response.results[0].message
                };
                this.dialogFlag = true;
              }
            }
          }
        );
    }
  }
  public clear(): any {
    this.materialTypeForm.reset();
    this.showGrid = false;
    this.notify = {};
  }
  public save(): void {
    this.submitted = true;
    this.createForm.markAllAsTouched();
    const reqObj = {
      code: this.createForm.controls.code.value,
      descr: this.createForm.controls.descr.value,
    };
    this.createMaterialTypeMaster(reqObj);
  }

  initializeCreateForm(): any {
    this.createForm = this.formBuilder.group({
      code: new FormControl('', [Validators.required, spaceValidator.noWhitespaceValidator]),
      descr: new FormControl('', [Validators.required, spaceValidator.noWhitespaceValidator]),
    });
    this.controlNames = {
      code : 'Code',
      descr: 'Description'
    };
  }

  public onsaveDialogClose(data: any): any {
    this.savedialogFlag = false;
    if (data === 'Yes') {
      this.save();
      this.fromSaveDialog = true;
      this.dialogFlag = false;
    }else if (data === 'No'){
      this.dialogFlag = false;
    }else if (data === 'Close'){
      this.dialogFlag = true;
    }
  }

  onDeleteDialogClose(data: any): any {
    this.deletedialogFlag = false;
    if (data  === 'Yes') {
      this.onAccept();
    }
  }
  onAccept(): any {
    this.loader = true;
    this.pspBaseService
      .deleteMaterialTypeMaster(this.requestDataForDelete)
      .pipe(takeUntil(this.isActive))
      .subscribe(
        (response: any) => {
          this.loader = false;
          if (response.status === 'SUCCESS') {
            this.deletedialogFlag = false;
            this.notify = {
              content: this.masterTranslate.recordDeletedSuccessfully,
              style: 'success'
            };
            this.searchData = this.searchData.filter((row: any) => {
              if (row.code !== this.requestDataForDelete.code) {
                return row;
              }
            });
          } else {
            this.notify = {
              content: response.results[0].message,
              style: 'error'
            };
            this.deletedialogFlag = false;
          }
        }
      );
  }
  public editHandler(data: any): any {
    if (data[0] === 'editData') {
      this.saveHandler(data[1]);
    } else if (data[0] === 'removeData') {
      this.deletedialogFlag = true;
      this.requestDataForDelete = data[1];
      this.deleteCode = data[1].code;
    }
  }
  // for cancel operation in main grid
  public cancelHandler(handler: any): any {
    this.closeEditor(handler.sender, handler.rowIndex);
  }
  // for saving data in main grid
  public saveHandler(data: any): void {
    this.loader = true;
    this.pspBaseService
      .updateMaterialTypeMaster(data)
      .pipe(takeUntil(this.isActive))
      .subscribe(
        (response: any) => {
          this.loader = false;
          if (response.status === 'SUCCESS') {
            this.search();
            this.notify = {
              content: this.masterTranslate.dataSavedSuccessfully,
              style: 'success'
            };
          } else {
            this.notify = {
              style: 'error',
              content: response.results[0].message
            };
          }
        },
        (err: any) => {
          this.notify = {
            style: 'error',
            content: err
          };
        }
      );
  }
  // for remove record from main grid
  public removeHandler(handler: any, isDialog?: any): any {
    if (handler && isDialog) {
      this.isDialog = isDialog;
      this.handler = handler;
      return false;
    }
    const product = handler.dataItem;
    this.loader = true;
    this.pspBaseService
      .deleteMaterialTypeMaster(product)
      .pipe(takeUntil(this.isActive))
      .subscribe(
        (response: any) => {
          this.loader = false;
          if (response.status === 'SUCCESS') {
            this.searchData = this.searchData.filter((row: any) => {
              if (row.code !== product.code) {
                return row;
              }
            });
            this.notify = {
              content: this.masterTranslate.recordDeletedSuccessfully,
              style: 'error'
            };
          } else {
            this.notify = {
              style: 'error',
              content: response.results[0].message
            };
          }
        },
        (err: any) => {
          this.notify =
          {
            style: 'error',
            content: err.statusText
          };
        }
      );
    this.isDialog = false;
  }

  private closeEditor(grid: any, rowIndex = this.editedRowIndex): any {
    grid.closeRow(rowIndex);
  }
  public closeConfirmDialog(status: any): void {
    if (status === 'cancel' || status === 'no') {
      this.isDialog = false;
    }
    if (status === 'yes') {
      this.removeHandler(this.handler);
    }
  }
  public allData(): ExcelExportData {
    const myState: State = this.state;
    myState.skip = 0;
    myState.take = this.allDataSet.total;
    const result: ExcelExportData = {
      data: process(this.searchData, this.state).data
    };
    return result;
  }
  public onDialogClose(): void {
    this.notify = {};
    if (this.createForm.valid){
        this.savedialogFlag = true;
    }
    else {
      this.submitted = false;
      this.dialogFlag = false;
    }
  }

}
