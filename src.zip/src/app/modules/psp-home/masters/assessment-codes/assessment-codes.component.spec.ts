import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssessmentCodesComponent } from './assessment-codes.component';

describe('AssessmentCodesComponent', () => {
  let component: AssessmentCodesComponent;
  let fixture: ComponentFixture<AssessmentCodesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AssessmentCodesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AssessmentCodesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
