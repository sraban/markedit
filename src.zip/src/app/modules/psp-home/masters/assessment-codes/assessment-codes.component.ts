import { Component, OnInit, ViewChildren, ViewEncapsulation } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { PspBaseService } from '../../services/psp-base.service';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { TranslateService } from '@ngx-translate/core';
import { DataStateChangeEvent, GridComponent, GridDataResult } from '@progress/kendo-angular-grid';
import { exportPDF, Group } from '@progress/kendo-drawing';
import { saveAs } from '@progress/kendo-file-saver';
import { ExcelExportData } from '@progress/kendo-angular-excel-export';
import { State, process } from '@progress/kendo-data-query';
import { ValidationComponent } from '../../../../app-shared/validation/validation.component'
const spaceValidator = new ValidationComponent();

@Component({
  selector: 'app-assessment-codes',
  templateUrl: './assessment-codes.component.html',
  styleUrls: ['./assessment-codes.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class AssessmentCodesComponent implements OnInit {
  public assessmentCodeForm: FormGroup | any;
  public createAssessmentForm: FormGroup | any;
  public submitted = false;
  public listItems: any;
  private isActive = new Subject();
  lookUpDialogFlag = false;
  result!: string;
  dialogFlag = false;
  lookUpGridData: any;
  public loader: any;
  public handler: any;
  controlNames: any;
  public isDialog: any = false;
  notify: any;
  public notifyPopup: any;
  fromSaveDialog = false;
  public showLableRecords = true;
  columnHeader: any = [];
  titleLabel = 'Create Assessment Codes';
  public pageable = {
    pageable: {
      position: 'both',
    },
    pageSize: 10,
  };
  public showSearch = false;
  public searchData: any[] = [];
  public editedRowIndex: any = null;
  public DeleteTitleLabel = 'Delete Confirmation';
  deletedialogFlag = false;
  public dropdownItemList: any = [];
  @ViewChildren(GridComponent)
  public grids: any;
  public state: State = {
    skip: 0,
    take: 5,
  };
  dimension = {
    height: 200,
    width: 200,
    position: 'right'
  };
  editorCol = {
    title: 'Actions',
    width: 50,
    type: 'command',
    openPopUp: false
  };
  export: {exportto: boolean, fileName: string} = {
    exportto : true,
    fileName : 'AssessmentCode'
  };
  public deleteTitleLabel = '';
  createReductionLabel = '';
  masterTranslate: any;
  public gridData: GridDataResult = process(this.searchData, this.state);
  requestDataForDelete: any;
  deleteCode: any;
  dataFromChild: any;
  control: any;
  assmType: any;
  savedialogFlag = false;
  public saveTitleLabel: any;
  displayValue: any;
  public dataStateChange(state: DataStateChangeEvent): void {
    this.state = state;
    this.gridData = process(this.searchData, this.state);
  }
  constructor(private pspBaseService: PspBaseService, private formBuilder: FormBuilder,
              private translate: TranslateService) {
  }
  ngOnInit(): any {
    this.initializeForm();
    this.initializeCreateForm();
    this.translate.get('masters').subscribe( (text: string) => {
      this.masterTranslate = text;
      this.deleteTitleLabel = this.masterTranslate.deleteConfirmation;
      this.saveTitleLabel = this.masterTranslate.saveConfirmation;
      this.createReductionLabel = this.masterTranslate.reduction.createReductionClaim;
    });
    this.dropdownTypeCodes();
  }
  initializeForm(): any {
    this.assessmentCodeForm = this.formBuilder.group({
      code: new FormControl('', [Validators.required]),
      descr: new FormControl('', [
        Validators.required
      ]),
      display_value: new FormControl()
    });
    this.control = new FormGroup({});
  }
  initializeCreateForm(): any {
    this.createAssessmentForm = this.formBuilder.group({
      code: new FormControl('', [Validators.required, spaceValidator.noWhitespaceValidator]),
      descr: new FormControl('', [Validators.required, spaceValidator.noWhitespaceValidator]),
      display_value: new FormControl('')
    });
    this.controlNames = {
      code: 'Code',
      descr: 'Description'
    };
  }
  public search(): void {
    this.showSearch = true;
    const reqObj = {
      code: this.assessmentCodeForm.controls.code.value,
      descr: this.assessmentCodeForm.controls.descr.value
    };
    this.searchingAssessmentCodes(reqObj);
  }
  public searchingAssessmentCodes(reqObj: any): any {
    this.loader = true;
    this.notify = {};
    this.pspBaseService
      .searchAssessmentCodes(reqObj)
      .pipe(takeUntil(this.isActive))
      .subscribe(
        (response: any) => {
          if (response.status === 'SUCCESS') {
            this.searchData = response.results;
            this.loader = false;
            if (this.searchData.length === 0) {
              this.notify = {
                style: 'info',
                content: this.masterTranslate.noRecordsFoundWithTheSearchcriteria
              };
            }
          }
          const formCtrls: any = {};
          this.columnHeader.forEach((item: any) => {
            if (item.field === 'descr') {
              formCtrls[item.field] = new FormControl('',[Validators.required,spaceValidator.noWhitespaceValidator]);
            }
            else {
              formCtrls[item.field] = new FormControl(false);
            }
            this.control = new FormGroup(formCtrls);
          });
        },
        (err: any) => {
          this.loader = false;
          this.notify = {
            style: 'error',
            content: this.masterTranslate.noRecordsFoundWithTheSearchcriteria
          };
        }
      );
  }
   // for dropdown list
   public dropdownTypeCodes(): any {
    const reqObj = {};
    this.pspBaseService.dropdownAssessmentCodeType(reqObj).pipe(takeUntil(this.isActive)).subscribe(
      (response: any) => {
        if (response.status === 'SUCCESS') {
          this.dropdownItemList = response.results;
          this.dropdownItemList.splice(0, 0, {data_value: null, display_value: null});
          this.columnHeader = [
            { field: 'code', header_title: 'Code', width: 150, type: 'input_text', editable: false, maxlength: '20'},
            { field: 'descr', header_title: 'Description', width: 300, type: 'input_text', editable: true, maxlength: '200'},
            { field: 'display_value', header_title: 'Type', width: 100, type: 'dropdown',
              dropdown_list: this.dropdownItemList, editable: true}
          ];
        }
      },
      (err: any) => {
      }
    );
  }
  updateASSMType(event: any): any {
    if (event) {
      this.assmType = null;
      this.dropdownItemList.forEach((element: any) => {
        if (element.display_value === event) {
          this.assmType =  element.seq;
        }
      });
    }
  }
  // for Create form
  public saveAndClose(): void {
    this.submitted = true;
    this.createAssessmentForm.markAllAsTouched();
    if (this.createAssessmentForm.valid) {
    const req = {
      code: this.createAssessmentForm.controls.code.value,
      descr: this.createAssessmentForm.controls.descr.value,
      ASSMT_TYPE: this.assmType
    };
    this.pspBaseService
      .createAssessmentCodeType(req)
      .pipe(takeUntil(this.isActive))
      .subscribe(
        (response: any) => {
          if (response.status === 'SUCCESS') {
            this.dialogFlag = false;
            this.search();
            this.notify = {
              content: this.masterTranslate.dataSavedSuccessfully,
              style: 'success'
            };
          } else {
            if (this.fromSaveDialog) {
              this.notify = {
                style: 'error',
                content: response.results[0].message
              };
              this.dialogFlag = false;
              this.submitted = false;
              this.fromSaveDialog = false;
            }
            else {
              this.notifyPopup = {
                style: 'error',
                content: response.results[0].message
              };
              this.dialogFlag = true;
            }
          }
        }
      );
    }
}
  public onDialogClose(): void {
   
    this.notify = {};
    if (this.createAssessmentForm.valid || this.createAssessmentForm.dirty){
        this.savedialogFlag = true;
    }
    else {
      this.submitted = false;
      this.dialogFlag = false;
    }
  }
  public open(): void {
    this.dialogFlag = true;
    this.createAssessmentForm.reset();
    this.submitted = false;
    this.savedialogFlag = false;
    this.notify = {};
    this.notifyPopup = {};
  }

  public clearSearch(): void {
    this.assessmentCodeForm.reset();
    this.showSearch = false;
    this.notify = {};
  }
  public editHandler(data: any): any {
    if (data[0] === 'editData') {
      this.saveHandler(data[1]);
    } else if (data[0] === 'removeData') {
      this.deletedialogFlag = true;
      this.requestDataForDelete = data[1];
      this.deleteCode = data[1].code;
    }
  }
  onDeleteDialogClose(data: any): any {
    this.deletedialogFlag = false;
    if (data === 'Yes') {
      this.deleteAccept();
    }
  }
// remove row data from main Grid
deleteAccept(): any {
  this.pspBaseService
  .deleteAssessmentCodeType(this.requestDataForDelete)
  .pipe(takeUntil(this.isActive))
  .subscribe(
    (response: any) => {
      if (response.status === 'SUCCESS') {
        this.deletedialogFlag = false;
        this.notify = {
          content: this.masterTranslate.recordDeletedSuccessfully,
          style: 'success'
        };
        this.searchData = this.searchData.filter((row: any) => {
          if (row.code !== this.requestDataForDelete.code) {
            return row;
          }
        });
      } else {
        this.notify = {
          content: response.results[0].message,
          style: 'error'
        };
        this.deletedialogFlag = false;
      }
    }
  );
}
  // for cancel operation in main grid
  public cancelHandler(handler: any): any {
    this.closeEditor(handler.sender, handler.rowIndex);
  }
  // for saving data in main grid
  public saveHandler(data: any): void {
    let assmcode;
    this.dropdownItemList.forEach((element: any) => {
      if (element.display_value === data.display_value) {
        assmcode =  element.seq;
      }
    });
    data.ASSMT_TYPE = assmcode;
    this.pspBaseService
      .updateAssessmentCodeType(data)
      .pipe(takeUntil(this.isActive))
      .subscribe(
        (response: any) => {
          if (response.status === 'SUCCESS') {
            this.search();
            this.showLableRecords = true;
            this.notify = {
              style: 'success',
              content: this.masterTranslate.dataSavedSuccessfully,
            };
          } else {
            this.notify = {
              style: 'error',
              content: response.results[0].message
            };
          }
        },
        (err: any) => {
          this.notify = {
            style: 'error',
            content: err
          };
        }
      );
  }
  // for remove record from main grid
  public removeHandler(handler: any, isDialog?: any): any {
    if (handler && isDialog) {
      this.isDialog = isDialog;
      this.handler = handler;
      return false;
    }
    const product = handler.dataItem;
    this.pspBaseService
      .deleteAssessmentCodeType(product)
      .pipe(takeUntil(this.isActive))
      .subscribe(
        (response: any) => {
          if (response.status === 'SUCCESS') {
            this.searchData = this.searchData.filter((row: any) => {
              if (row.code !== product.code) {
                return row;
              }
            });
            this.notify = {
              style: 'success',
              content: this.masterTranslate.recordDeletedSuccessfully
            };
          } else {
            this.notify = {
              style: 'error',
              content: response.results[0].message
            };
          }
        },
        (err: any) => {
          this.notify =
          {
            style: 'error',
            content: err.statusText
          };
        }
      );
    this.isDialog = false;
  }
  private closeEditor(grid: any, rowIndex = this.editedRowIndex): any {
    grid.closeRow(rowIndex);
  }
  public exportGrids(): void {
    const promises = this.grids.map((grid: any) => grid.drawPDF());
    Promise.all(promises)
      .then((groups) => {
        const rootGroup = new Group({
          pdf: {
            multiPage: true,
          },
        });
        groups.forEach((group: any) => {
          rootGroup.append(...group.children);
        });
        return exportPDF(rootGroup, { paperSize: 'A4' });
      })
      .then((dataUri) => {
        saveAs(dataUri, 'CategoryMaster.pdf');
      });
  }
  public allData(): ExcelExportData {
    const myState: State = this.state;
    myState.skip = 0;
    myState.take = this.gridData.total;
    const result: ExcelExportData = {
      data: process(this.searchData, this.state).data
    };
    return result;
  }
  public onsaveDialogClose(data: any): any {
    this.savedialogFlag = false;
    if (data==='Yes') {
      this.createAssessmentForm.markAllAsTouched();
      this.saveAndClose();
    }else if(data === 'No'){
        this.dialogFlag =false;
        this.submitted =false;
        this.createAssessmentForm.reset();
    }else{
      this.dialogFlag =true;
    }
  }
}
