import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FoodcontactTypeComponent } from './foodcontact-type.component';

describe('FoodcontactTypeComponent', () => {
  let component: FoodcontactTypeComponent;
  let fixture: ComponentFixture<FoodcontactTypeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FoodcontactTypeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FoodcontactTypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
