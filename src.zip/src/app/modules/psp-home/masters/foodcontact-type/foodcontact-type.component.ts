import { Component, OnInit, ViewChildren } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { PspBaseService } from '../../services/psp-base.service';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { GridComponent } from '@progress/kendo-angular-grid';
import { TranslateService } from '@ngx-translate/core';
import { ValidationComponent } from '../../../../app-shared/validation/validation.component'
const spaceValidator = new ValidationComponent();

@Component({
  selector: 'app-foodcontact-type',
  templateUrl: './foodcontact-type.component.html',
  styleUrls: ['./foodcontact-type.component.scss']
})
export class FoodcontactTypeComponent implements OnInit {
  public foodcontactTypeForm: FormGroup;
  public createFoodcontactTypeForm: FormGroup;
  public showSearch = false;
  masterTranslate: any;
  notify: any;
  dialogFlag = false;
  public submitted = false;
  controlNames: any;
  public formControl: any;
  public loader = false;
  private isActive = new Subject();
  public searchData: any = [];
  lookUpHeader: any = [];
  deletedialogFlag = false;
  savedialogFlag = false;
  public deleteFoodContactTypeData: any;
  public deleteCode: any;
  public pageable = {
    pageable: {
      position: 'both',
    },
    pageSize: 25,
  };
  @ViewChildren(GridComponent)
  public grids: any;
  editorCol = {
    title: 'Actions',
    width: 50,
    type: 'command',
    openPopUp: false
  };
  export: { exportto: boolean, fileName: string } = {
    exportto: true,
    fileName: 'Food Contact Type'
  };
  public deleteTitleLabel = '';
  public saveTitleLabel = '';
  createTitleLabel = '';
  fromSaveDialog = false;
  constructor(private pspBaseService: PspBaseService, private formBuilder: FormBuilder, private translate: TranslateService) {
    this.foodcontactTypeForm = this.formBuilder.group({
      code: new FormControl(''),
      descr: new FormControl('')
    });
    this.createFoodcontactTypeForm = this.formBuilder.group({
      code: new FormControl('', [Validators.required, Validators.maxLength(8),spaceValidator.noWhitespaceValidator]),
      descr: new FormControl('', [Validators.required, Validators.maxLength(40),spaceValidator.noWhitespaceValidator])
    });
    this.controlNames = {
      code: 'Code',
      descr: 'Description'
    };
    this.formControl = new FormGroup({});
  }
  ngOnInit(): void {
    this.translate.get('masters').subscribe( (text: string) => {
      this.masterTranslate = text;
      this.deleteTitleLabel = this.masterTranslate.deleteConfirmation;
      this.createTitleLabel = this.masterTranslate.foodContactType.createFoodContactType;
      this.saveTitleLabel = this.masterTranslate.foodContactType.saveFoodContactType;
    });
    this.lookUpHeader = [
      {
        field: 'code',
        header_title: 'Code',
        width: 150,
        type: 'input_text',
        maxlength: '8',
        editable: false
      },
      {
        field: 'descr',
        header_title: 'Description',
        width: 300,
        type: 'input_text',
        maxlength: '40',
        editable: true
      },
    ];
  }
  public clearSearch(): void {
    this.foodcontactTypeForm.reset();
    this.showSearch = false;
    this.notify = {};
  }
  public open(): void {
    (document as any).querySelectorAll('.k-grid-cancel-command').forEach((el: any) => { el.click(); });
    this.dialogFlag = true;
    this.submitted = false;
    this.savedialogFlag = false;
    this.notify = {};
    this.createFoodcontactTypeForm.reset();
  }
  public search(): void {
    (document as any).querySelectorAll('.k-grid-cancel-command').forEach((el: any) => { el.click(); });
    this.showSearch = true;
    const reqObj = {
      code: this.foodcontactTypeForm.controls.code.value,
      descr: this.foodcontactTypeForm.controls.descr.value
    };
    this.searchingFoodContactTypes(reqObj);
  }
  public searchingFoodContactTypes(reqObj: any): any {
    this.notify = {}
    this.loader = true;
    this.pspBaseService
    .searchFoodContactType(reqObj)
    .pipe(takeUntil(this.isActive))
    .subscribe(
      (response: any) => {
        if (response.status === 'SUCCESS') {
          this.searchData = response.results;
          this.loader = false;
          if (this.searchData.length === 0) {
            this.notify =
            {
              style: 'info',
              content: this.masterTranslate.noRecordsFoundWithTheSearchcriteria
            };
          }
        }
        const formCtrls: any = {};
        this.lookUpHeader.forEach((item: any) => {
          if (item.field === 'descr'){
            formCtrls[item.field] = new FormControl('', [Validators.required, Validators.maxLength(40),spaceValidator.noWhitespaceValidator]);
          }else{
            formCtrls[item.field] = new FormControl(true);
          }
          this.formControl = new FormGroup(formCtrls);
        });
      },
      (err: any) => {
        this.loader = false;
        this.notify =
        {
          style: 'error',
          content: err.statusText
        };
      }
    );
  }
  public onDialogClose(): void {
    this.notify = {};
    if (this.createFoodcontactTypeForm.valid && this.createFoodcontactTypeForm.touched){
      this.savedialogFlag = true;
      this.dialogFlag = true;
    }else{
      this.dialogFlag = false;
      this.submitted = false;
    }
  }
  public onsaveDialogClose(data: any): any {
    this.savedialogFlag = false;
    if (data === 'Yes') {
      this.save();
      this.fromSaveDialog = true;
      this.dialogFlag = true;
    }else if(data === "No"){
      this.dialogFlag = false;
    }else if(data === "Close"){
      this.dialogFlag = true;
    }
  }
  public save(): void {
    this.submitted = true;
    this.createFoodcontactTypeForm.markAllAsTouched();
    const reqObj = {
      code: this.createFoodcontactTypeForm.controls.code.value,
      descr: this.createFoodcontactTypeForm.controls.descr.value,
    };
    this.saveFoodContactType(reqObj);
  }
  public saveFoodContactType(reqObj: any): any {
    this.submitted = true;
    this.notify = {}
    if (this.createFoodcontactTypeForm.valid) {
      this.loader=true;
      this.pspBaseService
      .createFoodContactType(reqObj)
      .pipe(takeUntil(this.isActive))
      .subscribe(
        (response: any) => {
          this.loader=false;
          if (response.status === 'SUCCESS') {
            this.dialogFlag = false;
            this.submitted = false;
            this.search();
            this.notify = {
              style: 'success',
              content: this.masterTranslate.dataSavedSuccessfully
            };
          } else {
            if (this.fromSaveDialog) {
              this.notify = {
                style: 'error',
                content: response.results[0].message
              };
              this.dialogFlag = true;
              this.submitted = true;
              this.fromSaveDialog = false;
            }else{
              this.notify = {
                style: 'error',
                content: response.results[0].message
              };
            }
          }
        }
      );
    }
  }
  public editHandler(data: any): any {
    if (data[0] === 'editData') {
      this.saveHandler(data[1]);
    } else if (data[0] === 'removeData') {
      this.deletedialogFlag = true;
      this.deleteFoodContactTypeData = data[1];
      this.deleteCode = data[1].code;
    }
  }
  public saveHandler(data: any): void {
    this.loader=true;
    this.notify = {}
    this.pspBaseService
    .updateFoodContactType(data)
    .pipe(takeUntil(this.isActive))
    .subscribe(
      (response: any) => {
        this.loader=false;
        if (response.status === 'SUCCESS') {
          Object.assign(this.searchData.find((row: any) => row.code === data.code), data);
          this.notify = {
            style: 'success',
            content: this.masterTranslate.dataSavedSuccessfully,
          };
        } else {
          this.notify = {
            style: 'error',
            content: response.results[0].message
          };
        }
      },
      (err: any) => {
        this.notify = {
          style: 'error',
          content: err
        };
      }
    );
  }
  onDeleteDialogClose(data: any): any {
    this.deletedialogFlag = false;
    if (data === 'Yes') {
      this.onAccept();
    }
  }
  onAccept(): any {
    this.notify = {}
    this.loader = true;
    this.pspBaseService
    .deleteFoodContactType(this.deleteFoodContactTypeData)
    .pipe(takeUntil(this.isActive))
    .subscribe(
      (response: any) => {
        this.loader=false;
        this.deletedialogFlag = false;
        if (response.status === 'SUCCESS') {
          this.notify = {
            style: 'success',
            content: this.masterTranslate.recordDeletedSuccessfully,
          };
          this.searchData = this.searchData.filter((row: any) => {
            if (row.code !== this.deleteFoodContactTypeData.code) {
              return row;
            }
          });
        } else {
          this.notify = {
            style: 'error',
            content: response.results[0].message
          };
        }
      },
      (err: any) => {
        this.notify =
        {
          style: 'error',
          content: err.statusText
        };
      }
    );
  }


}
