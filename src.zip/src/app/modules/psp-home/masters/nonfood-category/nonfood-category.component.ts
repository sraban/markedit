import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import {
  DataStateChangeEvent,
  GridDataResult,
} from '@progress/kendo-angular-grid';
import { SortDescriptor, State, process } from '@progress/kendo-data-query';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { PspBaseService } from '../../services/psp-base.service';
import { TranslateService } from '@ngx-translate/core';
import { ValidationComponent } from '../../../../app-shared/validation/validation.component'
const spaceValidator = new ValidationComponent();

const createFormGroup = (dataItem: any) =>
  new FormGroup({
    code: new FormControl(dataItem.code, [Validators.required,spaceValidator.noWhitespaceValidator]),
    descr: new FormControl(dataItem.descr, [Validators.required,spaceValidator.noWhitespaceValidator]),
    dtm_code: new FormControl(dataItem.dtm_code),
  });

@Component({
  selector: 'app-nonfood-category',
  templateUrl: './nonfood-category.component.html',
  styleUrls: ['./nonfood-category.component.scss'],
})
export class NonfoodCategoryComponent implements OnInit {
  public categoryMasterForm: FormGroup;
  public nonFoodcategoryMasterForm: FormGroup;

  private isActive = new Subject();
  public dialogFlag = false;
  public loader: any;
  public notify: any;
  public pageable = {
    pageable: {
      position: 'single',
    },
    pageSize: 25,
  };
  public mainGrodPageable = {
    pageable: {
      position: 'both',
    },
    pageSize: 25,
  };
  public showSearch = false;
  public searchData: any[] = [];
  public editedRowIndex: any = null;
  public functionLookUpGridData: any;
  public editLookUpGridData: any;
  public functiondialogFlag!: boolean;
  public createNonFoodLabel = '';
  public functionTitleLabel = '';
  public editTitleLabel = '';
  public DeleteTitleLabel = '';
  public saveConfirmTitleLabel = '';
  public functionLookupHeader: any;

  public height = 430;
  public dialogHeight = 320;
  public dialogWidth = 700;
  public functionDataFromChild: any;
  public editfunctionDataFromChild: any;
  public documentTextForm: FormGroup;
  public editDialogFlag!: boolean;
  public editfunctiondialogFlag = false;
  public deletedialogFlag!: boolean;
  public saveConfirmFlag!: boolean;
  public createsaveConfirmFlag!: boolean;
  fromSaveDialog = false;
  public requestDataForDelete: any;
  public submitted = false;
  public columnHeaders: any[] = [];
  public formControl: any;
  public deleteCode: any;
  public controlNames: any;
  notifyPopup: any;
  public sort: SortDescriptor[] = [
    {
      field: 'code',
      dir: 'asc',
    },
    {
      field: 'descr',
      dir: 'asc',
    },
    {
      field: 'dtm_code',
      dir: 'asc',
    },
  ];
  public state: State = {
    skip: 0,
    take: 5,
  };
  public editorCol = {
    title: 'Actions',
    width: 50,
    type: 'command',
    openPopUp: true,
  };
  export: { exportto: boolean, fileName: string } = {
    exportto: true,
    fileName: 'Nonfood Category',
  };

  public gridData: GridDataResult = process(this.searchData, this.state);
  nonFoodTranslate: any;

  public dataStateChange(state: DataStateChangeEvent): void {
    this.state = state;
    this.gridData = process(this.searchData, this.state);
  }
  constructor(
    private pspBaseService: PspBaseService,
    private formBuilder: FormBuilder,
    private translate: TranslateService
  ) {
    this.controlNames = {
      code: 'Code',
      descr: 'Description',
    };
    this.categoryMasterForm = this.formBuilder.group({
      code: new FormControl('', [Validators.required, Validators.maxLength(8)]),
      descr: new FormControl('', [
        Validators.required,
        Validators.maxLength(80),
      ]),
      dtm_code: new FormControl('', [Validators.maxLength(8)]),
    });
    this.nonFoodcategoryMasterForm = this.formBuilder.group({
      code_init: new FormControl('', [Validators.maxLength(8)]),
      descr_init: new FormControl('', [Validators.maxLength(80)]),
      dtm_code_init: new FormControl('', [Validators.maxLength(8)]),
    });

    this.documentTextForm = this.formBuilder.group({
      code: new FormControl('', [Validators.required, Validators.maxLength(8),spaceValidator.noWhitespaceValidator]),
      descr: new FormControl('', [
        Validators.required,
        Validators.maxLength(80),spaceValidator.noWhitespaceValidator
      ]),
      dtm_code: new FormControl('', [Validators.maxLength(8)]),
    });

    this.formControl = new FormGroup({});
  }
  ngOnInit(): void {
    this.translate.get('masters').subscribe( (text: string) => {
      this.nonFoodTranslate = text;
      this.createNonFoodLabel = this.nonFoodTranslate.nonfoodCategoryMaster.createNonFoodLabel;
      this.functionTitleLabel = this.nonFoodTranslate.nonfoodCategoryMaster.functionTitleLabel;
      this.editTitleLabel = this.nonFoodTranslate.nonfoodCategoryMaster.editTitleLabel;
      this.DeleteTitleLabel = this.nonFoodTranslate.deleteConfirmation;
      this.saveConfirmTitleLabel = this.nonFoodTranslate.saveConfirmation;
      this.columnHeaders = [
        {
          header_title: this.nonFoodTranslate.code,
          width: 70,
          type: 'input_text',
          field: 'code',
          editable: false,
        },
        {
          header_title: this.nonFoodTranslate.description,
          width: 250,
          type: 'input_text',
          field: 'descr',
          editable: false,
        },
        {
          header_title: this.nonFoodTranslate.nonfoodCategoryMaster.documentTextCode,
          width: 70,
          field: 'dtm_code',
          editable: false,
          tooltip_title: 'Description :',
          tooltip_field: 'doc_text',
          type: 'tooltip',
        },
      ];
      this.functionLookupHeader = [
        {
          field: 'code',
          header_title: this.nonFoodTranslate.code,
          width: 200,
          type: 'input_text',
        },
        {
          field: 'doc_text',
          header_title: this.nonFoodTranslate.description,
          width: 200,
          type: 'input_text',
        },
      ];
    });
  }
  /* To search Non food category master grid data */
  public searchingCategoryMaster(reqObj: any): any {
    this.loader = true;
    this.notify = {};
    this.pspBaseService
      .searchNonFoodCategoryMaster(reqObj)
      .pipe(takeUntil(this.isActive))
      .subscribe(
        (response: any) => {
          if (response.status === 'SUCCESS') {
            this.searchData = response.results;
            this.loader = false;
            if (this.searchData.length === 0) {
              this.notify = {
                style: 'error',
                content: this.nonFoodTranslate.noRecordsFoundWithMatchingcriteria,
              };
            }
          }
        },
        (err: any) => {
          this.loader = false;
          this.notify = {
            style: 'error',
            content: this.nonFoodTranslate.noRecordsFoundWithMatchingcriteria,
          };
        }
      );
  }
  /* To Open close Dialog */
  public onDialogClose(): void {
    this.submitted = false;
    if (
      this.documentTextForm.controls.code.dirty ||
      this.documentTextForm.controls.descr.dirty
    ) {
      this.createsaveConfirmFlag = true;
   //   this.dialogFlag = true;
    }else{
      this.dialogFlag = false;
    }
  }
  /* To Open dialog pop up */
  public open(): void {
    this.dialogFlag = true;
    this.documentTextForm.reset();
    this.functionDataFromChild = [];
    this.submitted = false;
    this.notify = {};
    this.notifyPopup = {};
  }
  /* To Get non food category Master data grid*/
  public search(): void {
    this.showSearch = true;
    const reqObj = {
      code: this.nonFoodcategoryMasterForm.controls.code_init.value,
      descr: this.nonFoodcategoryMasterForm.controls.descr_init.value,
      dtm_code: this.nonFoodcategoryMasterForm.controls.dtm_code_init.value,
    };
    this.searchingCategoryMaster(reqObj);
  }
  public clearSearch(): void {
    this.nonFoodcategoryMasterForm.reset();
    this.showSearch = false;
    this.notify = false;
  }

  // Table rows editing for main grid
  public editHandler(data: any): any {
    if (data[0] === 'openDialog') {
      this.editDialogFlag = true;
      this.submitted = false;
      this.categoryMasterForm = createFormGroup(data[1]);
      this.editedRowIndex = data.rowIndex;
    } else if (data[0] === 'removeData') {
      this.deletedialogFlag = true;
      const product = data[1];
      delete product.doc_text;
      this.requestDataForDelete = product;
      this.deleteCode = product.code;
    }
  }

  // for cancel operation in main grid
  public cancelHandler(handler: any): any {
    this.closeEditor(handler.sender, handler.rowIndex);
  }
  // for saving data in main grid
  public saveGridOption(): void {
    this.submitted = true;
    this.categoryMasterForm.markAllAsTouched();
    if (this.categoryMasterForm.valid) {
      const req = this.categoryMasterForm.value;
      this.pspBaseService
        .updateNonFoodCategoryMaster(req)
        .pipe(takeUntil(this.isActive))
        .subscribe((response: any) => {
          if (response.status === 'SUCCESS') {
            this.notify = {
              content: this.nonFoodTranslate.dataSavedSuccessfully,
              style: 'success',
            };
            this.editDialogFlag = false;
            Object.assign(
              this.searchData.find(({ code }) => code === req.code),
              req
            );
          }
          else {
            // this.notify = {
            //   content: response.results[0].message,
            //   style: 'error',
            // };
            if (this.fromSaveDialog) {
              this.notifyPopup = {
                style: 'error',
                content: response.results[0].message
              };
              this.editDialogFlag = true;
              this.submitted = false;
              this.fromSaveDialog = false;
            }
            else {
              this.notifyPopup = {
                style: 'error',
                content: response.results[0].message
              };
              this.editDialogFlag = true;
            }
          }
        });
    }
  }
  // for saving and closing create document
  public saveAndClose(): void {
    this.submitted = true;
    this.documentTextForm.markAllAsTouched();
    if (this.documentTextForm.valid) {
      const requestdata = this.documentTextForm.value;
      const req = {
        code: requestdata.code ? requestdata.code : null,
        descr: requestdata.descr ? requestdata.descr : null,
        dtm_code: requestdata.dtm_code ? requestdata.dtm_code : null,
        // dtm_code: requestdata.documentTextCode
      };
      this.pspBaseService
        .saveCloseNonFoodCategoryMaster(req)
        .pipe(takeUntil(this.isActive))
        .subscribe(
          (response: any) => {
            if (response.status === 'SUCCESS') {
              this.dialogFlag = false;

              this.search();
              this.notify = {
                content: this.nonFoodTranslate.dataSavedSuccessfully,
                style: 'success',
              };
              Object.assign(
                this.searchData.find(({ code }) => code === req.code),
                req
              );

            } else {
              // this.dialogFlag = true;

              // this.notify = {
              //   content: response.results[0].message,
              //   style: 'error',
              // };
              if (this.fromSaveDialog) {
                this.notifyPopup = {
                  style: 'error',
                  content: response.results[0].message
                };
                this.dialogFlag = true;
                this.submitted = false;
                this.fromSaveDialog = false;
              }
              else {
                this.notifyPopup = {
                  style: 'error',
                  content: response.results[0].message
                };
                this.dialogFlag = true;
              }
            }
          },
          (): any => {
            alert('Update: API Error');
          }
        );
    }
  }

  private closeEditor(grid: any, rowIndex = this.editedRowIndex): any {
    grid.closeRow(rowIndex);
  }
  /* TO open look-up dialog grid*/
  public openDocumentTextDialog(): any {
    this.functiondialogFlag = true;
    this.getDocumentTextLookupGrid();
  }
  public openEditDocumentTextDialog(): any {
    this.editfunctiondialogFlag = true;
    this.getEditDocumentTextLookupGrid();
  }

  /* To get Material Type lookup grid Response*/
  public getDocumentTextLookupGrid(): any {
    this.loader = true;
    const reqObj = {
      code: '',
    };
    this.pspBaseService
      .getDocumentTextFunction(reqObj)
      .pipe(takeUntil(this.isActive))
      .subscribe((response: any) => {
        if (response.status === 'SUCCESS') {
          this.functionLookUpGridData = response.results;
          this.loader = false;
        }
      });
  }
  /* To get Material Type lookup grid Response*/
  public getEditDocumentTextLookupGrid(): any {
    const reqObj = {
      code: '',
    };
    this.pspBaseService
      .getDocumentTextFunction(reqObj)
      .pipe(takeUntil(this.isActive))
      .subscribe((response: any) => {
        if (response.status === 'SUCCESS') {
          this.editLookUpGridData = response.results;
        }
      });
  }
  /* To close dialog popup */
  public onCreateDialogClose(): void {
    this.functiondialogFlag = false;
  }

  functionSelectedRowData(data: any): void {
    this.functionDataFromChild = data.code;
    this.documentTextForm.controls.dtm_code.patchValue(data.code);
    this.functiondialogFlag = false;
  }
  /* To close dialog popup */
  public onEditDialogClose(): void {
    this.submitted = false;
    if (
      this.categoryMasterForm.controls.code.dirty ||
      this.categoryMasterForm.controls.descr.dirty
    ) {
      this.saveConfirmFlag = true;
    }else {
      this.editDialogFlag = false;

    }
  }
  public onEditlookUpClose(): void {
    this.editfunctiondialogFlag = false;
    this.submitted = false;
    this.editDialogFlag = false;
  }
  editSelectedRowData(data: any): void {
    this.editfunctionDataFromChild = data.code;
    this.categoryMasterForm.controls.dtm_code.patchValue(data.code);
    this.editfunctiondialogFlag = false;
  }
  onDeleteDialogClose(data: any): any {
    this.deletedialogFlag = false;
    if (data === 'Yes') {
      this.onAccept();
    }
  }
  /* On Delete confimation pop up*/
  onSaveConfirmDialogClose(data: any) {
    this.saveConfirmFlag = false;
    this.fromSaveDialog = true;
    if (data === 'Yes'){
      this.onSaveConfirm();
    }else if (data === 'No'){
      this.functiondialogFlag = false;
      this.editDialogFlag = false;
    }else{
      this.functiondialogFlag = false;
     }
  }
  /* To confirm delete Row */
  onAccept(): any {
    this.pspBaseService
      .deleteNonFoodCategoryMaster(this.requestDataForDelete)
      .pipe(takeUntil(this.isActive))
      .subscribe(
        (response: any) => {
          if (response.status === 'SUCCESS') {
            this.notify = {
              content: this.nonFoodTranslate.recordDeletedSuccessfully,
              style: 'success',
            };
            this.deletedialogFlag = false;
            this.searchData = this.searchData.filter((row: any) => {
              if (row.code !== this.requestDataForDelete.code) {
                return row;
              }
            });
          } else {
            this.notify = {
              content: response.results[0].message,
              style: 'error',
            };
            this.deletedialogFlag = false;
          }
        },
        () => {
          alert('Delete: API Error');
        }
      );
  }
  /* On Save confimation pop up*/
  onSaveConfirm(): any {
    this.submitted = true;
    this.categoryMasterForm.markAllAsTouched();
    if (this.categoryMasterForm.valid) {
    const req = {
      code: this.categoryMasterForm.controls.code.value,
      descr: this.categoryMasterForm.controls.descr.value,
      dtm_code: this.categoryMasterForm.controls.dtm_code.value,
    };
    this.pspBaseService
      .updateNonFoodCategoryMaster(req)
      .pipe(takeUntil(this.isActive))
      .subscribe((response: any) => {
        if (response.status === 'SUCCESS') {
          this.saveConfirmFlag = false;
          this.editDialogFlag = false;
          this.notify = {
            content: this.nonFoodTranslate.dataSavedSuccessfully,
            style: 'success',
          };
          Object.assign(
            this.searchData.find(({ code }) => code === req.code),
            req
          );
        } else {
          this.saveConfirmFlag = false;
          this.editDialogFlag = false;
          this.notify = {
            content: response.results[0].message,
            style: 'error',
          };
          
        }
      });
  }
}
   /* On create save confimation pop up*/
   onCreateSaveConfirmDialogClose(data: any) {
    this.createsaveConfirmFlag = false;
    if(this.documentTextForm.controls.code.value || this.documentTextForm.controls.descr.value) {
      if (data =='Yes') {
        this.saveAndClose();
      }else if(data == 'No'){
        this.dialogFlag = false;
      }
    }
  }
}
