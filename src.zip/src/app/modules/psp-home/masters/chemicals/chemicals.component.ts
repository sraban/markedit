import { Component, OnInit, AfterContentChecked, ViewChildren, Renderer2, ViewChild, TemplateRef, ElementRef, ViewEncapsulation } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { PspBaseService } from '../../services/psp-base.service';
import { Subject } from 'rxjs';
import { DataStateChangeEvent, GridComponent, GridDataResult } from '@progress/kendo-angular-grid';
import { ExcelExportData } from '@progress/kendo-angular-excel-export';
import { SortDescriptor, State, process } from '@progress/kendo-data-query';
import { takeUntil } from 'rxjs/operators';
import { TranslateService } from '@ngx-translate/core';
import { ValidationComponent } from '../../../../app-shared/validation/validation.component';
import { TooltipDirective } from '@progress/kendo-angular-tooltip';
import { element } from 'protractor';
const spaceValidator = new ValidationComponent();
const matches = (el: any, selector: any) =>
  (el.matches || el.msMatchesSelector).call(el, selector);
@Component({
  selector: 'app-chemicals',
  templateUrl: './chemicals.component.html',
  styleUrls: ['./chemicals.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class ChemicalsComponent implements OnInit, AfterContentChecked {
  @ViewChild(GridComponent)
  private grid!: GridComponent;
  public nf_justification: any;
  public comments: any;
  public res_spec: any;
  deleteChemicalData: any[] = [];
  testDecisionTranslate: any;
  testDesCode: any;
  testDesDescr: any;
  lowVal: any;
  highVal: any;
  belowLowTest: any;
  inRangeTestData: any;
  aboveHighTest: any;
  createTestDecisionLabel: any;
  saveButtonAddItemFlag!: boolean;
  createEditReadOnlyCode!: boolean;
  isLowValue!: boolean;
  is_edit!: boolean;
  isHighValue!: boolean;
  testView: any[] = [];
  public formGroup: any;
  decimalPoints = 2;
  testDecisionGridHeigth!: any;
  docClickSubscription: any;
  editedRowIndex: any;
  testDecisionHeaders!: { field: string; header_title: string; width: number; type: string; }[];
  testPageable!: { pageable: { position: string; }; pageSize: number; };
  constructor(private pspBaseService: PspBaseService, private formBuilder: FormBuilder, private renderer: Renderer2, private translate: TranslateService) {
    this.formGroup = new FormGroup({});
    this.renderer.listen('window', 'click', (e: Event) => {
      if (e.target && (<any>e.target).getAttribute('class') && (<any>e.target).getAttribute('class').indexOf('mngCol') === -1) {
        this.showCol = false;
      }
    });
    this.chemicalsForm = new FormGroup({
      cascode: new FormControl(''),
      chemical_name: new FormControl(''),
      comments: new FormControl(''),
      nf_justification: new FormControl(''),
    });
    this.createchemicalsForm = new FormGroup({
      cascode: new FormControl('', [Validators.required, Validators.maxLength(30), spaceValidator.noWhitespaceValidator]),
      chemical_name: new FormControl('', [Validators.required, Validators.maxLength(80), spaceValidator.noWhitespaceValidator]),
      'nf_justification': new FormControl('', [Validators.maxLength(4000)]),
      'structural_formula': new FormControl('', [Validators.maxLength(40)]),
      'molecular_wt': new FormControl('', [Validators.maxLength(20)]),
      'comments': new FormControl('', [Validators.maxLength(4000)]),
      'std60_acceptable_value': new FormControl('', [Validators.maxLength(20)]),
      'td_code': new FormControl('', [Validators.maxLength(8)]),
      'phosphate_pct': new FormControl('', [Validators.maxLength(5)]),
      'td_descr': new FormControl(''),
      'zinc_pct': new FormControl('', [Validators.maxLength(5)]),
      'fluoride_pct': new FormControl('', [Validators.maxLength(5)]),
      'info_required_flg': new FormControl(''),
      'fcms_no': new FormControl('', [Validators.maxLength(80)]),
      'reference_no': new FormControl('', [Validators.maxLength(80)]),
      'substance_name': new FormControl('', [Validators.maxLength(80)]),
      'supporting_rationale': new FormControl('', [Validators.maxLength(80)]),
      'status': new FormControl('', [Validators.maxLength(30)]),
      'sufa_25nov1992': new FormControl('', [Validators.maxLength(30)]),
      'sufa_9nov1994': new FormControl('', [Validators.maxLength(30)]),
      'sudwc_iii': new FormControl('', [Validators.maxLength(30)]),
      'suid_21mar1973': new FormControl('', [Validators.maxLength(30)]),
      'sgbfrr_xv': new FormControl('', [Validators.maxLength(80)]),
      'sgbfr_rec': new FormControl('', [Validators.maxLength(80)]),
      'res_spec': new FormControl('', [Validators.maxLength(4000)]),
      'sml': new FormControl('', [Validators.maxLength(80)]),
      'copper_pct': new FormControl('', [Validators.maxLength(5)]),
      'operation': new FormControl('create'),
      'chemicals21CfrRef': new FormControl(''),
    });
    this.controlNames = {
      cascode: 'CAS#',
      chemical_name: 'Chemical Name',
    };
  }
  @ViewChild(TooltipDirective)
  public tooltipDir!: TooltipDirective;
  @ViewChild('kgrid') kgrid!: TemplateRef<any>;
  public opened = false;
  public opened1 = false;
  public opened2 = false;
  public autoCorrect = true;
  public min = 0;
  public max = 100;
  public value = 2;
  public chemicalsForm: FormGroup;
  public createchemicalsForm: FormGroup;
  public searchGrid: any[] = [];
  public showAdd = false;
  public showSearch = false;
  fromSaveDialog = false;
  public notifyPopup: any;
  masterTranslate: any;
  commonTranslate: any;
  public editfunctiondialogFlag = false;
  lookUpHeader: any = [];
  dialogGridHeader: any = [];
  allHeaders: any = [];
  showCol = false;
  controlNames: any;
  public deleteTitleLabel = '';
  public showHide = false;
  public submitted = false;
  public listItems: any;
  public loader: any;
  dialogFlag = false;
  careateTitleLabel = '';
  editTitleLabel = '';
  notify: any;
  public saveTitleLabel: any;
  testCodeHeader: any;
  public testCodeData: any[] = [];
  deletedialogFlag = false;
  public searchData: any[] = [];
  public editDialogFlag!: boolean;
  public editLookUpGridData: any;
  public editfunctionDataFromChild: any;
  public functionDataFromChild: any;
  public functiondialogFlag!: boolean;
  public functionLookUpGridData: any;
  public functionLookupHeader: any;
  public height = 430;
  public functionTitleLabel = ' ';
  testDecisionview: any;
  savedialogFlag = false;
  selectedRow: any;
  removeRowFlag = false;
  maxlength21CFR = 20;
  @ViewChildren(GridComponent)
  public grids: any;
  public state: State = {
    skip: 0,
    take: 5,
  };
  editorCol = {
    title: 'Actions',
    width: 80,
    type: 'command',
    openPopUp: true
  };
  export: { exportto: boolean, fileName: string } = {
    exportto: true,
    fileName: 'Chemicals'
  };
  public pageable = {
    pageable: {
      position: 'bottom',
    },
    pageSize: 25,
  };
  public mainGrodPageable = {
    pageable: {
      position: 'both',
    },
    pageSize: 25,
  };
  public gridData: GridDataResult = process(this.searchData, this.state);
  requestDataForDelete: any;
  deleteCode: any;
  dataFromChild: any;
  formControl: any;
  testDecisiondialogFlag = false;
  private isActive = new Subject();
  public sort: SortDescriptor[] = [
    {
      field: 'code',
      dir: 'asc',
    },
    {
      field: 'descr',
      dir: 'asc',
    },
  ];
  public view: any[] = [];
  isNew: boolean = false;
  // for grid in popup
  public temp: any;
  public dataStateChange(state: DataStateChangeEvent): void {
    this.state = state;
    this.gridData = process(this.searchData, this.state);
  }
  ngAfterContentChecked(): void {
    let casIndex: any = null;
    document.querySelectorAll('.chemicalGrid .k-grid-header-wrap table thead th').forEach((el: any, index) => {
      if (el.innerText == 'CAS#') {
        casIndex = index;
      }
    });
    if (casIndex !== null) {
      casIndex = casIndex + 1;
      document.querySelectorAll('.chemicalGrid table.k-grid-table tr td:nth-child(' + casIndex + ')').forEach((el: any) => {
        el.style.color = 'blue';
        el.style.cursor = 'pointer';
      });
    }
  }
 ngOnInit(): void {
      this.translate.get('masters').subscribe((text: string) => {
      this.masterTranslate = text;
      this.saveTitleLabel = this.masterTranslate.saveConfirmation;
      this.deleteTitleLabel = this.masterTranslate.deleteConfirmation;
      this.careateTitleLabel = this.masterTranslate.chemicals.createchemical;
      this.editTitleLabel = this.masterTranslate.chemicals.editChemicals;
      this.functionTitleLabel = this.masterTranslate.chemicals.selecttest;
      this.createTestDecisionLabel = this.masterTranslate.testDecision.infoTestDecisionLabel;
});
    this.translate.get('common').subscribe((text: string) => {
      this.commonTranslate = text;
    });
    this.testPageable = {
      pageable: {
        position: 'bottom'
      },
      pageSize: 25
    };
    this.testDecisionGridHeigth = 280;
    this.testDecisionHeaders = [
      {
        field: 'TESTING_TYPE',
        header_title: 'Test Code',
        width: 200,
        type: 'input_text'
      },
      {
        field: 'ANLM_CODE',
        header_title: 'Testing Type',
        width: 200,
        type: 'input_text'
      },
      {
        field: 'ANLM_DESCR',
        header_title: 'Analyte Code',
        width: 200,
        type: 'input_text'
      }
    ];
    this.functionLookupHeader = [
      {
        field: 'CODE',
        header_title: 'Test Code',
        width: 200,
        type: 'input_text'
      },
      {
        field: 'DESCR',
        header_title: 'Description',
        width: 400,
        type: 'input_text'
      }
    ];
    this.lookUpHeader = [
      {
        field: 'cascode',
        header_title: 'CAS #',
        width: 150,
        type: 'underline',
        editable: false
      },
      {
        field: 'chemical_name',
        header_title: 'Chemical Name',
        width: 300,
        type: 'input_text',
        editable: true
      },
      {
        field: 'structural_formula',
        header_title: 'Structural Formula',
        width: 300,
        type: 'input_text',
        editable: true
      }, {
        field: 'molecular_wt',
        header_title: 'Molecular Weight',
        width: 300,
        type: 'input_text',
        editable: true
      }, {
        field: 'comments',
        header_title: 'Food Justification',
        width: 300,
        type: 'input_text',
        editable: true
      }, {
        field: 'nf_justification',
        header_title: 'NF Justification',
        width: 300,
        type: 'input_text',
        editable: true
      }, {
        field: 'std60_acceptable_value',
        header_title: 'Std60 Acceptance Value',
        width: 300,
        type: 'input_text',
        editable: true
      }, {
        field: 'td_code',
        header_title: 'Test Decision Code',
        width: 200,
        type: 'underline',
        editable: true
      }, {
        field: 'td_descr',
        header_title: 'Test Decision',
        width: 200,
        type: 'input_text',
        editable: true
      },
      {
        field: 'phosphate_pct',
        header_title: 'Phosphate %',
        width: 150,
        type: 'input_text',
        editable: true
      },
      {
        field: 'zinc_pct',
        header_title: 'Zinc %',
        width: 150,
        type: 'input_text',
        editable: true
      },
      {
        field: 'copper_pct',
        header_title: 'Copper %',
        width: 150,
        type: 'input_text',
        editable: true
      },
      {
        field: 'fluoride_pct',
        header_title: 'Fluoride %',
        width: 300,
        type: 'input_text',
        editable: true,
        colCheck: true
      },
    ];
    this.dialogGridHeader = [
      {
        field: 'ref',
        header_title: '21 CFR Reference',
        width: 100,
        type: 'input_text',
        editable: true
      },
      {
        field: 'ref_url',
        header_title: '21 CFR Reference URL',
        width: 200,
        type: 'input_text',
        editable: true
      }

    ];
    this.allHeaders = [
      {
        field: 'cascode',
        header_title: 'CAS #',
        width: 150,
        type: 'tooltip',
        editable: false,
        colCheck: false
      },
      {
        field: 'chemical_name',
        header_title: 'Chemical Name',
        width: 300,
        type: 'input_text',
        editable: true,
        colCheck: false
      },
      {
        field: 'structural_formula',
        header_title: 'Structural Formula',
        width: 300,
        type: 'input_text',
        editable: true,
        colCheck: false
      }, {
        field: 'molecular_wt',
        header_title: 'Molecular Weight',
        width: 300,
        type: 'input_text',
        editable: true,
        colCheck: false
      }, {
        field: 'comments',
        header_title: 'Food Justification',
        width: 300,
        type: 'input_text',
        editable: true,
        colCheck: false
      }, {
        field: 'nf_justification',
        header_title: 'NF Justification',
        width: 300,
        type: 'input_text',
        editable: true,
        colCheck: false
      }, {
        field: 'std60_acceptable_value',
        header_title: 'Std60 Acceptance Value',
        width: 300,
        type: 'input_text',
        editable: true,
        colCheck: false
      }, {
        field: 'td_code',
        header_title: 'Test Decision Code',
        width: 300,
        type: 'input_text',
        editable: true,
        colCheck: false
      }, {
        field: 'td_descr',
        header_title: 'Test Decision',
        width: 300,
        type: 'input_text',
        editable: true,
        colCheck: false
      },
      {
        field: 'phosphate_pct',
        header_title: 'Phosphate %',
        width: 300,
        type: 'input_text',
        editable: true,
        colCheck: false
      },
      {
        field: 'zinc_pct',
        header_title: 'Zinc %',
        width: 300,
        type: 'input_text',
        editable: true,
        colCheck: false
      },
      {
        field: 'copper_pct',
        header_title: 'Copper %',
        width: 300,
        type: 'input_text',
        editable: true,
        colCheck: false
      },

      {
        field: 'fcms_no',
        header_title: 'FCM Substance No',
        width: 300,
        type: 'input_text',
        editable: true,
        colCheck: true
      },
      {
        field: 'reference_no',
        header_title: 'Reference No',
        width: 300,
        type: 'input_text',
        editable: true,
        colCheck: true
      },

      {
        field: 'substance_name',
        header_title: 'Substance Name',
        width: 300,
        type: 'input_text',
        editable: true,
        colCheck: true
      },
      {
        field: 'sml',
        header_title: 'SML',
        width: 300,
        type: 'input_text',
        editable: true,
        colCheck: true
      },
      {
        field: 'res_spec',
        header_title: 'Restrictions And Specification',
        width: 300,
        type: 'input_text',
        editable: true,
        colCheck: true
      },
      {
        field: 'status',
        header_title: 'Status',
        width: 300,
        type: 'input_text',
        editable: true,
        colCheck: true
      },
      {
        field: 'supporting_rationale',
        header_title: 'Supporting Rationale',
        width: 300,
        type: 'input_text',
        editable: true,
        colCheck: true
      },
      {
        field: 'sgbfr_rec',
        header_title: 'Section of German BFR Recommendation',
        width: 300,
        type: 'input_text',
        editable: true,
        colCheck: true
      },
      {
        field: 'sufa_9nov1994',
        header_title: 'Status under French Arrete 9 Nov 1994',
        width: 300,
        type: 'input_text',
        editable: true,
        colCheck: true
      },
      {
        field: 'sudwc_iii',
        header_title: 'Status under Dutch Warenwet Chapter III',
        width: 300,
        type: 'input_text',
        editable: true,
        colCheck: true
      },
      {
        field: 'sgbfrr_xv',
        header_title: 'Section of German BFR Recommendation XV',
        width: 300,
        type: 'input_text',
        editable: true,
        colCheck: true
      },
      {
        field: 'sufa_25nov1992',
        header_title: 'Status Under French Arrete 25 Nov 1992',
        width: 300,
        type: 'input_text',
        editable: true,
        colCheck: true
      },
      {
        field: 'suid_21mar1973',
        header_title: 'Status Under Italian Decree 21 March 1973',
        width: 300,
        type: 'input_text',
        editable: true,
        colCheck: true
      },
    ];
    this.createFormGroup = this.createFormGroup.bind(this);
  }
  checkChecked(field: any): boolean {
    let flag = false;
    this.lookUpHeader.forEach((el: any) => {
      if (field === el.field) { flag = true; }
    });
    return flag;
  }
  // for manage columns list above grid
  public colSelection() {
    let selectedFields: any = [];
    document.querySelectorAll(".col_List").forEach((el: any) => {
      if (el.checked) {
        selectedFields.push(el.value);
      }
    });
    let lookUpHeaders: any = [];
    this.allHeaders.filter((row: any) => {
      if (row.colCheck == false) {
        lookUpHeaders.push(row);
      } else if (selectedFields.indexOf(row.field) !== -1 && row.colCheck == true) {
        lookUpHeaders.push(row);
      }
    });
    this.lookUpHeader = lookUpHeaders;
  }
  // for chemical search for main grid
  public searchingchemicalsMaster(reqObj: any): any {
    this.loader = true;
    this.pspBaseService
      .searchchemicalsMaster(reqObj)
      .pipe(takeUntil(this.isActive))
      .subscribe(
        (response: any) => {
          if (response.status === 'SUCCESS') {
            this.searchData = response.results;
            this.loader = false;
            if (this.searchData.length === 0) {
              this.notify =
              {
                style: 'info',
                content: this.masterTranslate.noRecordsFoundWithTheSearchcriteria
              };
            }
          }
        },
        (err: any) => {
          this.loader = false;
          this.notify =
          {
            style: 'error',
            content: err.statusText
          };
        }
      );
  }
  public open(): void {
    this.dialogFlag = true;
    this.createchemicalsForm.reset();
    this.functionDataFromChild = [];
    this.view = [];
  }
  public clearSearch(): void {
    this.chemicalsForm.reset();
    this.showSearch = false;
    this.notify = {};
  }
  public onsaveDialogClose(data: any): any {
    this.savedialogFlag = false;
    if (data === 'Yes') {
      this.saveCreateForm();
      this.fromSaveDialog = true;
    } else if (data === 'No') {
      this.dialogFlag = false;
      this.editDialogFlag = false;
      this.tooltipDir.hide();
    } else if (data === "Close") {
      this.dialogFlag = true;
    }
  }
  public saveCreateForm(): void {
    this.submitted = true;
    this.createchemicalsForm.markAllAsTouched();
    if (this.createchemicalsForm.valid && this.formGroup && this.formGroup.valid) {
      const views: any = [];
      this.formGroup.value.ref ? this.saveCurrent() : '';
      this.view.forEach((row: any) => {
        views.push({
          'casm_seq': this.createchemicalsForm.value.seq,
          'ref_url': row.ref_url,
          'cfr21_ref': row.ref,
          'operation': row.operation
        });
      });
      if (this.deleteChemicalData.length > 0) {
        this.deleteChemicalData.forEach((row: any) => {
          views.push({
            'casm_seq': this.createchemicalsForm.value.seq,
            'ref_url': row.ref_url,
            'cfr21_ref': row.ref,
            'operation': row.operation
          });
        });
      }
      const info_required_flg: any = this.createchemicalsForm.controls.info_required_flg.value;
      const req = this.createchemicalsForm.value;
      req.info_required_flg = info_required_flg ? 'Y' : 'N';
      req.chemicals21CfrRef = views.length > 0 ? views : null;
      req.operation = req.seq ? 'update' : 'create';
      this.pspBaseService
        .createChemicalsMaster(req)
        .pipe(takeUntil(this.isActive))
        .subscribe(
          (response: any) => {
            if (response.status === 'SUCCESS') {
              this.editDialogFlag = false;
              this.dialogFlag = false;
              this.deleteChemicalData = [];
              this.search();
              this.notify = {
                style: 'success',
                content: this.masterTranslate.dataSavedSuccessfully
              };
            }
            else {
              if (this.fromSaveDialog) {

                this.notifyPopup = {
                  style: 'error',
                  content: response.results[0].message
                };
                this.dialogFlag = true;
                this.submitted = false;
                this.fromSaveDialog = false;
              }
              else {
                this.notifyPopup = {
                  style: 'error',
                  content: response.results[0].message
                };
                this.dialogFlag = true;
              }
            }
          }
        );
    } else {
      this.showTooltip();
    }
  }
  onDeleteDialogClose(data: any): any {
    this.deletedialogFlag = false;
    if (data === 'Yes') {
      this.onAccept();
    }
  }
  onAccept(): any {
    this.pspBaseService
      .deletechemicalsMaster(this.requestDataForDelete)
      .pipe(takeUntil(this.isActive))
      .subscribe(
        (response: any) => {
          if (response.status === 'SUCCESS') {
            this.deletedialogFlag = false;
            this.notify = {
              content: this.masterTranslate.recordDeletedSuccessfully,
              style: 'success'
            };
            this.searchData = this.searchData.filter((row: any) => {
              if (row.cascode !== this.requestDataForDelete.cascode) {
                return row;
              }
            });
          } else {
            this.notify = {
              content: response.results[0].message,
              style: 'error'
            };
            this.deletedialogFlag = false;
          }
        },
      );
  }
  public Add(): void {
    this.showAdd = true;
  }
  public search(): void {
    this.showSearch = true;
    const reqObj: any = {
      cascode: this.chemicalsForm.controls.cascode.value,
      chemical_name: this.chemicalsForm.controls.chemical_name.value,
      comments: this.chemicalsForm.controls.comments.value,
      nf_justification: this.chemicalsForm.controls.nf_justification.value
    };
    this.searchingchemicalsMaster(reqObj);
  }
  public allData(): ExcelExportData {
    const myState: State = this.state;
    myState.skip = 0;
    myState.take = this.gridData.total;
    const result: ExcelExportData = {
      data: process(this.searchData, this.state).data
    };
    return result;
  }
  public sortChange(sort: SortDescriptor[]): void {
    this.sort = sort;
    this.search();
  }
  public onDialogClose(): any {
    this.submitted = false;
    this.notify = {};
    if (this.createchemicalsForm.dirty || this.formGroup.invalid) {
      this.savedialogFlag = true;
    }
    else {
      this.dialogFlag = false;
      this.editDialogFlag = false;
      this.tooltipDir.hide();
    }
    this.submitted = false;
    this.notify = {};
  }
  public createDialog(): any {
    this.submitted = false;
    this.savedialogFlag = false;
    this.notifyPopup = {};
    this.dialogFlag = true;
    this.showHide = false;
    this.createchemicalsForm.reset();
    this.view = [];
  }
  // edit form
  public createFormGroup(args: any): FormGroup {
    this.formGroup = this.formBuilder.group({
      ref: new FormControl(args.ref, [Validators.required, spaceValidator.noWhitespaceValidator, Validators.maxLength(20)]),
      ref_url: new FormControl(args.ref_url),
      operation: new FormControl(this.isNew ? 'create' : 'update'),
      type: new FormControl(args.type)
    });
    return this.formGroup;
  }
  public editHandler(data: any): any {
    if (data[0] === 'openDialog') {
      this.editDialogFlag = true;
    } else if (data[0] === 'removeData') {
      this.deletedialogFlag = true;
      this.requestDataForDelete = data[1];
      this.deleteCode = data[1].cascode;
    }
  }
  public editFormGroup(args: any): void {
    this.createchemicalsForm = new FormGroup({
      cascode: new FormControl(args.cascode, [Validators.required, Validators.maxLength(30), spaceValidator.noWhitespaceValidator]),
      chemical_name: new FormControl(args.chemical_name, [
        Validators.required,
        Validators.maxLength(80), spaceValidator.noWhitespaceValidator
      ]),
      'nf_justification': new FormControl(args.nf_justification, [Validators.maxLength(4000)]),
      'structural_formula': new FormControl(args.structural_formula, [Validators.maxLength(40)]),
      'molecular_wt': new FormControl(args.molecular_wt, [Validators.maxLength(20)]),
      'comments': new FormControl(args.comments, [Validators.maxLength(4000)]),
      'std60_acceptable_value': new FormControl(args.std60_acceptable_value, [Validators.maxLength(20)]),
      'td_code': new FormControl(args.td_code, [Validators.maxLength(8)]),
      'phosphate_pct': new FormControl(args.phosphate_pct, [Validators.maxLength(5)]),
      'td_descr': new FormControl(args.td_descr),
      'zinc_pct': new FormControl(args.zinc_pct, [Validators.maxLength(5)]),
      'fluoride_pct': new FormControl(args.fluoride_pct, [Validators.maxLength(5)]),
      'info_required_flg': new FormControl(args.info_required_flg == 'Y' ? true : false),
      'fcms_no': new FormControl(args.fcms_no, [Validators.maxLength(80)]),
      'reference_no': new FormControl(args.reference_no, [Validators.maxLength(80)]),
      'substance_name': new FormControl(args.substance_name, [Validators.maxLength(80)]),
      'supporting_rationale': new FormControl(args.supporting_rationale, [Validators.maxLength(80)]),
      'status': new FormControl(args.status, [Validators.maxLength(30)]),
      'sufa_25nov1992': new FormControl(args.sufa_25nov1992, [Validators.maxLength(30)]),
      'sufa_9nov1994': new FormControl(args.sufa_9nov1994, [Validators.maxLength(30)]),
      'sudwc_iii': new FormControl(args.sudwc_iii, [Validators.maxLength(30)]),
      'suid_21mar1973': new FormControl(args.suid_21mar1973, [Validators.maxLength(30)]),
      'sgbfrr_xv': new FormControl(args.sgbfrr_xv, [Validators.maxLength(80)]),
      'sgbfr_rec': new FormControl(args.sgbfr_rec, [Validators.maxLength(80)]),
      'res_spec': new FormControl(args.res_spec, [Validators.maxLength(4000)]),
      'sml': new FormControl(args.sml, [Validators.maxLength(80)]),
      'copper_pct': new FormControl(args.copper_pct, [Validators.maxLength(5)]),
      'seq': new FormControl(args.seq),
      'operation': new FormControl('update'),
      'chemicals21CfrRef': new FormControl(''),
    });
  }
  // for edit scenario clicking on cas# in main grid
  public openWindow(event: any): void {
    this.notifyPopup = {};
    this.deleteChemicalData = [];
    let rowArr = []; let cascode: any = null; let testcode: any;
    if (event.target.closest('tr')) {
      cascode = event.target.closest('tr').cells[0].innerText;
      testcode = event.target.closest('tr').cells[7].innerText;
      if (cascode && cascode == event.target.innerText) {
        rowArr = this.searchData.filter(row => {
          if (row.cascode == cascode) return row;
        });
        if (rowArr[0]) {
          this.pspBaseService.editchemicalsMaster({ 'seq': rowArr[0].seq }).pipe(takeUntil(this.isActive))
            .subscribe(
              (response: any) => {
                rowArr = response.results;
                this.editFormGroup(rowArr[0]);
                this.view = [];
                rowArr[0].chemicals21CfrRef.forEach((row: any) => {
                  this.view.push({
                    'casm_seq': row.casm_seq,
                    'ref_url': row.ref_url,
                    'ref': row.cfr21_ref,
                    'operation': row.operation,
                    type: 'update'
                  });
                });
                this.createchemicalsForm.controls.chemicals21CfrRef.patchValue(this.view);
                this.editDialogFlag = true;
                this.dialogFlag = true;
                this.showHide = false;
              });
        }
      } else if (testcode && testcode == event.target.innerText) {
        rowArr = this.searchData.filter(row => {
          if (row.td_code == testcode) return row;
        });
        if (rowArr[0]) {
          this.isHighValue = false;
          this.isLowValue = false;
          this.submitted = false;
          this.pspBaseService.getCodeTestDecision({ CODE: rowArr[0].td_code }).pipe(takeUntil(this.isActive))
            .subscribe(
              (response: any) => {
                this.translate.get('masters').subscribe((text: string) => {
                });
                this.testDecisiondialogFlag = true;
                rowArr = response.results;
                this.editFormGroup(rowArr[0]);
                this.saveButtonAddItemFlag = false;
                this.createEditReadOnlyCode = false;
                this.is_edit = false;
                this.testDesCode = rowArr[0]['CODE'];
                this.testDesDescr = rowArr[0]['DESCR'];
                this.lowVal = rowArr[0]['LOW_VALUE'];
                this.highVal = rowArr[0]['HIGH_VALUE'];
                this.belowLowTest = rowArr[0]['BELOW_LOW_AC_CODE'];
                this.inRangeTestData = rowArr[0]['IN_RANGE_AC_CODE'];
                this.aboveHighTest = rowArr[0]['ABOVE_HIGH_AC_CODE'];

                this.view = [];
                rowArr[0].testDecisionDtlsDTOList.forEach((row: any) => {
                  this.testView.push({
                    TESTING_TYPE: row.TESTING_TYPE,
                    ANLM_CODE: row.ANLM_CODE,
                    ANLM_DESCR: row.ANLM_DESCR,
                    operation: 'update'
                  });
                });
                this.createchemicalsForm.controls.chemicals21CfrRef.patchValue(this.view);
              });
        }
      }
    }
  }
  /* TO open look-up dialog grid*/
  public openTestCodeDialog(): any {
    this.functiondialogFlag = true;
    this.getTestCodeLookupGrid();
  }
  /* To get Material Type lookup grid Response*/
  public getTestCodeLookupGrid(): any {
    this.loader = true;
    const reqObj = {};
    this.pspBaseService
      .getTestCode(reqObj)
      .pipe(takeUntil(this.isActive))
      .subscribe((response: any) => {
        if (response.status === 'SUCCESS') {
          this.functionLookUpGridData = response.results;
          this.loader = true;
        }
      });
  }
  /* To get Material Type lookup grid Response*/
  public getEditTestCode(): any {
    this.loader = true;
    const reqObj = {};
    this.pspBaseService
      .getTestCode(reqObj)
      .pipe(takeUntil(this.isActive))
      .subscribe((response: any) => {
        if (response.status === 'SUCCESS') {
          this.editLookUpGridData = response.results;
          this.loader = false;
        }
      });
  }
  /* To close dialog popup */
  public onCreateDialogClose(): void {
    this.functiondialogFlag = false;
  }
  public openEditTestCodeDialog(): any {
    this.editfunctiondialogFlag = true;
    this.getEditTestCode();
  }
  functionSelectedRowData(data: any): void {
    this.functionDataFromChild = data.code;
    this.createchemicalsForm.controls.td_code.patchValue(data.code);
    this.createchemicalsForm.controls.td_descr.patchValue(data.DESCR);
    this.functiondialogFlag = false;
  }
  public onEditlookUpClose(): void {
    this.editfunctiondialogFlag = false;
    this.submitted = false;
    this.editDialogFlag = false;
  }
  editSelectedRowData(data: any): void {
    this.editfunctionDataFromChild = data.CODE;
    this.createchemicalsForm.controls.td_code.patchValue(data.CODE);
    this.createchemicalsForm.controls.td_descr.patchValue(data.DESCR);
    this.editfunctiondialogFlag = false;
  }
  removeHandler(event: any): any {
    let { sender, dataItem, rowIndex } = event;
    this.selectedRow = { dataItem, rowIndex };
    this.removeRowFlag = true;
  }
  removeRow(data: any): any {
    if (data === 'Yes') {
      this.removeSelectedRow();
      this.removeRowFlag = false;
    } else {
      this.removeRowFlag = false;
    }
  }
  deleteChemical(): any {
    this.view.forEach((value: any) => {
      if (value.ref === this.selectedRow.dataItem.ref) {
        if (value.type !== 'new') {
          value.operation = 'delete';
          value.cfr21_ref = value.ref;
          this.deleteChemicalData.push(value);
        }
       }
    });
  }
  removeSelectedRow(): any {
    this.deleteChemical();
    this.view = this.view.filter((row: any) => {
      if (row.ref !== this.selectedRow.dataItem.ref) {
        return row;
      }
    });
  }
  // for text area
  public close(status: any): any {
    this.opened = false;
  }
  public insertDesc(): any {
    this.createchemicalsForm.controls.nf_justification.patchValue(this.nf_justification);
    this.opened = false;
  }
  public nf_justification_fn(): any {
    this.nf_justification = this.createchemicalsForm.controls.nf_justification.value;
  }
  // for text area Food justification
  public closecomment(status: any): any {
    this.opened1 = false;
  }
  public insertcomment(): any {
    this.createchemicalsForm.controls.comments.patchValue(this.comments);
    this.opened1 = false;
  }
  public comments_fn(): any {
    this.comments = this.createchemicalsForm.controls.comments.value;
  }
  // for text area Restrictions and specification
  public closerestriction(status: any): any {
    this.opened2 = false;
  }
  public insertrestriction(): any {
    this.createchemicalsForm.controls.res_spec.patchValue(this.res_spec);
    this.opened2 = false;
  }
  public res_spec_fn(): any {
    this.res_spec = this.createchemicalsForm.controls.res_spec.value;
  }
 public showTooltip(event?: any): void {
    const setID = document.getElementById('reftext');
    if (this.formGroup && this.formGroup.touched && this.formGroup.invalid && setID) {
      this.tooltipDir.show(setID);
    } else {
      this.tooltipDir.hide();
    }
  }
 onTestDecisionClose(): void {
    this.testDecisiondialogFlag = false;
  }
  closeFormGroup(): void {
    this.formGroup = new FormGroup({});
  }
  editRow(event: any): void {
    console.log(event);
  }
 addHandler(): void {
    this.closeEditor();
    this.isNew = true;
   this.formGroup = this.createFormGroup({
      ref_url: '',
      cfr21_ref: '',
      operation: true,
      type: 'new'
    });
this.grid.addRow(this.formGroup);
  }
 saveRow(): void {
    if (this.formGroup && this.formGroup.valid) {
      this.saveCurrent();
    }
  }
 cellClickHandler({ sender, rowIndex, dataItem }: { sender: any, dataItem: any, rowIndex: number }): void {
    this.closeEditor(sender);
    this.isNew = false;
    this.formGroup = this.createFormGroup(dataItem);
    this.editedRowIndex = rowIndex;

    sender.editRow(rowIndex, this.formGroup);
  }
cancelHandler(): void {
    this.closeEditor();
  }
 closeEditor(sender?: any): void {
    this.grid.closeRow(this.editedRowIndex);
    this.editedRowIndex = undefined;
    this.formGroup = new FormGroup({});
  }
saveCurrent(): void {
    if (this.isNew) {
      this.view.unshift(this.formGroup.value);
      this.closeEditor();
    } else {
      this.view.splice(this.editedRowIndex, 1, this.formGroup.value);
      this.view.forEach((value: any) => {
        if (value.type === 'new') {
          value.operation = 'create';
        }
      });
      this.closeEditor();
    }
  }
}

