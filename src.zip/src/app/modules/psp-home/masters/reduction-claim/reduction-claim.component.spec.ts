import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReductionClaimComponent } from './reduction-claim.component';

describe('ReductionClaimComponent', () => {
  let component: ReductionClaimComponent;
  let fixture: ComponentFixture<ReductionClaimComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ReductionClaimComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ReductionClaimComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
