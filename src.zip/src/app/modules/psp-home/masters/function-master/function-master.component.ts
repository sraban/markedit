import { Component, OnInit, ViewChildren, ViewEncapsulation } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { PspBaseService } from '../../services/psp-base.service';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { DataStateChangeEvent, GridComponent, GridDataResult } from '@progress/kendo-angular-grid';
import { exportPDF, Group } from '@progress/kendo-drawing';
import { saveAs } from '@progress/kendo-file-saver';
import { ExcelExportData } from '@progress/kendo-angular-excel-export';
import { State, process } from '@progress/kendo-data-query';
import { TranslateService } from '@ngx-translate/core';
import { ValidationComponent } from '../../../../app-shared/validation/validation.component'
const spaceValidator = new ValidationComponent();


@Component({
  selector: 'app-function-master',
  templateUrl: './function-master.component.html',
  styleUrls: ['./function-master.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class FunctionMasterComponent implements OnInit {
  public funtionMasterForm: FormGroup | any;
  public createFunctionMasterForm: FormGroup | any;
  public submitted = false;
  public listItems: any;
  private isActive = new Subject();
  lookUpDialogFlag = false;
  result!: string;
  dialogFlag = false;
  lookUpGridData: any;
  public loader: any;
  public handler: any;
  controlNames: any;
  public isDialog: any = false;
  notify: any;
  public showLableRecords = true;
  gridHeaders: any = [];
  titleLabel = '';
  public pageable = {
    pageable: {
      position: 'both',
    },
    pageSize: 25,
  };
  public showGrid = false;
  public searchData: any[] = [];
  public editedRowIndex: any = null;
  deletedialogFlag = false;
  public dropdownItemList: any = [];
  public notifyPopup: any;
  fromSaveDialog = false;
  masterTranslate: any;
  savedialogFlag = false;
  public saveTitleLabel: any;
  @ViewChildren(GridComponent)
  public grids: any;
  public state: State = {
    skip: 0,
    take: 5,
  };
  dimension = {
    height: 200,
    width: 200,
    position: 'right'
  };
  editorCol = {
    title: 'Actions',
    width: 50,
    type: 'command',
    openPopUp: false
  };
  export: {exportto: boolean, fileName: string} = {
    exportto : true,
    fileName : 'FunctionMaster'
  };
  public gridData: GridDataResult = process(this.searchData, this.state);
  requestDataForDelete: any;
  deleteCode: any;
  dataFromChild: any;
  control: any;
  public deleteTitleLabel = '';
  constructor(private pspBaseService: PspBaseService, private formBuilder: FormBuilder, public translate: TranslateService) {
  }
  public allDataSet: GridDataResult = process(this.searchData, this.state);
  public dataStateChange(state: DataStateChangeEvent): void {
    this.state = state;
    this.allDataSet = process(this.searchData, this.state);
  }

  ngOnInit(): void {
    this.initializeForm();
    this.initializeCreateForm();
    this.translate.get('masters').subscribe( (text: string) => {
      this.masterTranslate = text;
      this.deleteTitleLabel = this.masterTranslate.deleteConfirmation;
      this.saveTitleLabel = this.masterTranslate.saveConfirmation;
      this.titleLabel = this.masterTranslate.functionMaster.createFunctionMaster;
    });
  }

  initializeForm(): any {
    this.funtionMasterForm = this.formBuilder.group({
      code: new FormControl('', [Validators.required]),
      descr: new FormControl('', [Validators.required]),
    });
    this.controlNames = {
      code: 'Code',
      descr: 'Description'
    };
    this.control = new FormGroup({});
    this.gridHeaders = [
      { field: 'code', header_title: 'Code', width: 150, type: 'input_text', editable: false, maxlength: '8'},
      { field: 'descr', header_title: 'Description', width: 350, type: 'input_text', editable: true, maxlength: '40'},
    ];
  }
  public create(): void {
    (document as any).querySelectorAll('.k-grid-cancel-command').forEach((el: any) => { el.click(); });
    this.dialogFlag = true;
    this.submitted = false;
    this.savedialogFlag = false;
    this.notify = {};
    this.notifyPopup = {};
    this.createFunctionMasterForm.reset();
  }
  public search(): any {
    (document as any).querySelectorAll('.k-grid-cancel-command').forEach((el: any) => { el.click(); });
    this.showGrid = true;
    const reqObj = {
      code: this.funtionMasterForm.controls.code.value,
      descr: this.funtionMasterForm.controls.descr.value
    };
    this.searchFunctionMaster(reqObj);
  }
  // Search Function Master
  public searchFunctionMaster(reqObj: any): any {
    this.loader = true;
    this.notify = {};
    this.pspBaseService
      .searchFunctionMaster(reqObj)
      .pipe(takeUntil(this.isActive))
      .subscribe(
        (response: any) => {
          this.loader = false;
          if (response.status === 'SUCCESS') {
            this.searchData = response.results;
            if (this.searchData.length === 0) {
              this.notify = {
                style: 'info',
                content: this.masterTranslate.noRecordsFoundWithTheSearchcriteria
              };
            }
          }
          const formCtrls: any = {};
          this.gridHeaders.forEach((item: any) => {
            if (item.field === 'descr') {
              formCtrls[item.field] = new FormControl('',[Validators.required,spaceValidator.noWhitespaceValidator]);
            }
            else {
              formCtrls[item.field] = new FormControl(false);
            }
            this.control = new FormGroup(formCtrls);
          });
        },
        (err: any) => {
          this.loader = false;
          this.notify = {
            style: 'error',
            content: this.masterTranslate.noRecordsFoundWithTheSearchcriteria
          };
        }
      );
  }
  public createFunctionMaster(reqObj: any): any {
    this.submitted = true;
    if (this.createFunctionMasterForm.valid) {
      this.loader = true;
      this.pspBaseService
        .createFunctionMaster(reqObj)
        .pipe(takeUntil(this.isActive))
        .subscribe(
          (response: any) => {
            this.loader = false;
            if (response.status === 'SUCCESS') {
              this.dialogFlag = false;
              this.submitted = false;
              this.search();
              this.notify = {
                style: 'success',
                content: this.masterTranslate.dataSavedSuccessfully
              };
            } else {
              if (this.fromSaveDialog) {
                this.notify = {
                  style: 'error',
                  content: response.results[0].message
                };
                this.dialogFlag = false;
                this.submitted = false;
                this.fromSaveDialog = false;
              }
              else {
                this.notifyPopup = {
                  style: 'error',
                  content: response.results[0].message
                };
                this.dialogFlag = true;
              }
            }
          }
        );
    }
  }
  public clear(): any {
    this.funtionMasterForm.reset();
    this.showGrid = false;
    this.notify = {};
  }
  public save(): void {
    this.submitted = true;
    this.createFunctionMasterForm.markAllAsTouched();
    const reqObj = {
      code: this.createFunctionMasterForm.controls.code.value,
      descr: this.createFunctionMasterForm.controls.descr.value,
    };
    this.createFunctionMaster(reqObj);
  }

  initializeCreateForm(): any {
    this.createFunctionMasterForm = this.formBuilder.group({
      code: new FormControl('', [Validators.required,spaceValidator.noWhitespaceValidator]),
      descr: new FormControl('', [Validators.required,spaceValidator.noWhitespaceValidator]),
    });
    this.controlNames = {
      code : 'Code',
      descr: 'Description'
    };
  }

  public onsaveDialogClose(data: any): any {

    this.savedialogFlag = false;
    if (data === 'Yes') {
      this.save();
      this.fromSaveDialog = true;
      this.dialogFlag = true;
    }else if(data === "No"){
      this.dialogFlag = false;
    }else if(data === "Close"){
      this.dialogFlag = true;
    }
  }

  onDeleteDialogClose(data: any): any {
    this.deletedialogFlag = false;
    if (data === 'Yes') {
      this.onAccept();
    }
  }
  onAccept(): any {
    this.loader = true;
    this.pspBaseService
      .deleteFunctionMaster(this.requestDataForDelete)
      .pipe(takeUntil(this.isActive))
      .subscribe(
        (response: any) => {
          this.loader = false;
          if (response.status === 'SUCCESS') {
            this.deletedialogFlag = false;
            this.notify = {
              content: this.masterTranslate.recordDeletedSuccessfully,
              style: 'success'
            };
            this.searchData = this.searchData.filter((row: any) => {
              if (row.code !== this.requestDataForDelete.code) {
                return row;
              }
            });
          } else {
            this.notify = {
              content: response.results[0].message,
              style: 'error'
            };
            this.deletedialogFlag = false;
          }
        }
      );
  }
  public editHandler(data: any): any {
    if (data[0] === 'editData') {
      this.saveHandler(data[1]);
    } else if (data[0] === 'removeData') {
      this.deletedialogFlag = true;
      this.requestDataForDelete = data[1];
      this.deleteCode = data[1].code;
    }
  }
  // for cancel operation in main grid
  public cancelHandler(handler: any): any {
    this.closeEditor(handler.sender, handler.rowIndex);
  }
  // for saving data in main grid
  public saveHandler(data: any): void {
    this.loader = true;
    this.pspBaseService
      .updateFunctionMaster(data)
      .pipe(takeUntil(this.isActive))
      .subscribe(
        (response: any) => {
          this.loader = false;
          if (response.status === 'SUCCESS') {
            this.search();
            this.showLableRecords = true;
            this.notify = {
              content: this.masterTranslate.dataSavedSuccessfully,
              style: 'success'
            };
          } else {
            this.notify = {
              style: 'error',
              content: response.results[0].message
            };
          }
        },
        (err: any) => {
          this.notify = {
            style: 'error',
            content: err
          };
        }
      );
  }
  // for remove record from main grid
  public removeHandler(handler: any, isDialog?: any): any {
    if (handler && isDialog) {
      this.isDialog = isDialog;
      this.handler = handler;
      return false;
    }
    const product = handler.dataItem;
    this.loader = true;
    this.pspBaseService
      .deleteFunctionMaster(product)
      .pipe(takeUntil(this.isActive))
      .subscribe(
        (response: any) => {
          this.loader = false;
          if (response.status === 'SUCCESS') {
            this.searchData = this.searchData.filter((row: any) => {
              if (row.code !== product.code) {
                return row;
              }
            });
            this.notify = {
              content: this.masterTranslate.recordDeletedSuccessfully,
              style: 'error'
            };
          } else {
            this.notify = {
              style: 'error',
              content: response.results[0].message
            };
          }
        },
        (err: any) => {
          this.notify =
          {
            style: 'error',
            content: err.statusText
          };
        }
      );
    this.isDialog = false;
  }

  private closeEditor(grid: any, rowIndex = this.editedRowIndex): any {
    grid.closeRow(rowIndex);
  }
  public closeConfirmDialog(status: any): void {
    if (status === 'cancel' || status === 'no') {
      this.isDialog = false;
    }
    if (status === 'yes') {
      this.removeHandler(this.handler);
    }
  }
  public allData(): ExcelExportData {
    const myState: State = this.state;
    myState.skip = 0;
    myState.take = this.allDataSet.total;
    const result: ExcelExportData = {
      data: process(this.searchData, this.state).data
    };
    return result;
  }
  public onDialogClose(): void {
    this.notify = {};
    
    if (this.createFunctionMasterForm.valid || this.createFunctionMasterForm.touched){
        this.savedialogFlag = true;
    }
    else {
      this.submitted = false;
      this.dialogFlag = false;
    }
  }
}
