import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TurnaroundTimestoxComponent } from './turnaround-timestox.component';

describe('TurnaroundTimestoxComponent', () => {
  let component: TurnaroundTimestoxComponent;
  let fixture: ComponentFixture<TurnaroundTimestoxComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TurnaroundTimestoxComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TurnaroundTimestoxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
