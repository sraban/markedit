import { Component, OnInit } from '@angular/core';
import { PspBaseService } from '../../services/psp-base.service';
import { forkJoin } from 'rxjs';
import { FormBuilder, FormGroup, Validators, FormArray, FormControl } from '@angular/forms';
import { DatePipe } from '@angular/common';


  @Component({
  selector: 'app-turnaround-timestox',
  templateUrl: './turnaround-timestox.component.html',
  styleUrls: ['./turnaround-timestox.component.scss']
})

export class TurnaroundTimestoxComponent implements OnInit {
  turnAroundTimeForm!: FormGroup;
  public initialDropdown: any;
  public revisionDropdown: any;
  public showDetailDropdown: any;
  public loader: any;
  public notify: any;
  public programItems: any;
  public standardItems: any;
  public defaultProgram = 'ALL';
  public defaultStandard = 'ALL';
  public defaultInitial = 'Yes';

  constructor(private pspBaseService: PspBaseService, private formBuilder: FormBuilder, private datePipe: DatePipe) { }

  ngOnInit(): void {

    this.turnAroundTimeForm = this.formBuilder.group({
      programCode: [''],
      standardCode: [''],
      initials: [''],
      revisions: [''],
      showDetails: [''],
      fromDate: [''],
      toDate: [''],
  });

    // API integration turnaround Dropdown List
    const programCodeRequest = {
      details: "yes",
      fromDate: "",
      initials: "",
      program: "ALL",
      revisions: "yes",
      stdCode: "ALL",
      toDate: ""
    }
    const programCode = this.pspBaseService.getDropdownAPI( 'reports/fetchProgramCode', programCodeRequest);
    const standardCodeRequest = {
      details: "yes",
      fromDate: "",
      initials: "Yes",
      program: "ALL",
      revisions: "yes",
      stdCode: "ALL",
      toDate: ""
    }
    const standardCode = this.pspBaseService.getDropdownAPI ('reports/fetchStandardCodeTox', standardCodeRequest);

    forkJoin([programCode, standardCode]).subscribe((data: any) => {
      this.programItems = data[0].results;
      console.log(this.programItems)
      this.standardItems = data[1].results;

    },
    (err: any) => {
      this.loader = false;
      this.notify =
      {
        style : 'error',
        content : err.statusText
      };

      }
    );

    this.initialDropdown = [
      {DATA_VALUE : 'Yes', DISPLAY_VALUE: 'Yes'},
      {DATA_VALUE : 'No', DISPLAY_VALUE: 'No'},
    ];

    this.revisionDropdown = [
      {DATA_VALUE : ' ', DISPLAY_VALUE: ' '},
      {DATA_VALUE : 'Yes', DISPLAY_VALUE: 'Yes'},
      {DATA_VALUE : 'No', DISPLAY_VALUE: 'No'}
    ];

    this.showDetailDropdown = [
      {DATA_VALUE : ' ', DISPLAY_VALUE: ' '},
      {DATA_VALUE : 'Yes', DISPLAY_VALUE: 'Yes'},
      {DATA_VALUE : 'No', DISPLAY_VALUE: 'No'}
    ];


  }

  generateReport(): any {
    console.log(this.turnAroundTimeForm.value);
    const qparams = {
    details: this.turnAroundTimeForm.controls.showDetails.value,
    fromDate: this.datePipe.transform(this.turnAroundTimeForm.controls.fromDate.value, 'MM/dd/yyyy'),
    initials: this.turnAroundTimeForm.controls.initials.value,
    program: this.turnAroundTimeForm.controls.programCode.value,
    revisions: this.turnAroundTimeForm.controls.revisions.value,
    stdCode: this.turnAroundTimeForm.controls.standardCode.value,
    toDate: this.datePipe.transform(this.turnAroundTimeForm.controls.toDate.value, 'MM/dd/yyyy'),
  }
  console.log(qparams);
  this.pspBaseService.getToxData(qparams).subscribe((data:any) => {
    console.log(data);
  });

}

}
