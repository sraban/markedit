import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FailureresolutionTrackingComponent } from './failureresolution-tracking.component';

describe('FailureresolutionTrackingComponent', () => {
  let component: FailureresolutionTrackingComponent;
  let fixture: ComponentFixture<FailureresolutionTrackingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FailureresolutionTrackingComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FailureresolutionTrackingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
