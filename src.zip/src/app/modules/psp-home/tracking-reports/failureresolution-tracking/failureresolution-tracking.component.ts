import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { PspBaseService } from '../../services/psp-base.service';
import { forkJoin } from 'rxjs';



@Component({
  selector: 'app-failureresolution-tracking',
  templateUrl: './failureresolution-tracking.component.html',
  styleUrls: ['./failureresolution-tracking.component.scss']
})
export class FailureresolutionTrackingComponent implements OnInit {

  failureForm!: FormGroup;
  failureStandard: any = [];
  public selectedStandard = 'ALL';
  failureProgram: any = [];
  public selectedProgram = 'ALL';


  constructor(private formBuilder: FormBuilder, private pspBaseService: PspBaseService) { }

  ngOnInit(): void {

    this.failureForm = this.formBuilder.group({
      failureStandard: [''],
      failureProgram: ['']
    });




    const failurestandard = {VALUE_SET_NAME: ''};
    const FailureStandard = this.pspBaseService.getDropdownAPI('reports/fetchStandardCode', failurestandard);
    const failureprogram = {VALUE_SET_NAME: ''};
    const FailureProgram = this.pspBaseService.getDropdownAPI('reports/fetchProgramCode', failureprogram);

    forkJoin([FailureStandard, FailureProgram]).subscribe((response: any) => {
      this.failureStandard = response[0].results;
      this.failureProgram = response[1].results;
    });

  }

}
