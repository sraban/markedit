import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TrackingReportsComponent } from './tracking-reports.component';

describe('TrackingReportsComponent', () => {
  let component: TrackingReportsComponent;
  let fixture: ComponentFixture<TrackingReportsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TrackingReportsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TrackingReportsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
