import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NonfoodReviewLogComponent } from './nonfood-review-log.component';

describe('NonfoodReviewLogComponent', () => {
  let component: NonfoodReviewLogComponent;
  let fixture: ComponentFixture<NonfoodReviewLogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NonfoodReviewLogComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NonfoodReviewLogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
