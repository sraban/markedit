import { Component, OnInit } from '@angular/core';
import { PspBaseService } from '../../services/psp-base.service';
import { FormGroup, FormControl, FormBuilder } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-nonfood-review-log',
  templateUrl: './nonfood-review-log.component.html',
  styleUrls: ['./nonfood-review-log.component.scss']
})
export class NonfoodReviewLogComponent implements OnInit {
  public nonFoodReviewLogForm: FormGroup;
  public loader = false;
  notify:any;
  masterTranslate: any;
  private isActive = new Subject();
  public searchData: any = [];
  programDropDownList:Array<any>=[];
  programStatusList:Array<any>=[];
  revisionStatusList:Array<any>=[];
  reviewdccStatusList:Array<any>=[];
  fromDate : Date = new Date();
  toDate: Date = new Date();
  displayRevisions=[{text:"YES",textValue:"YES"},{text:"NO",textValue:"NO"}];
  displayInitials=[{text:"YES",textValue:"YES"},{text:"NO",textValue:"NO"}];
  sortOrderList1=[
    {text:"",textValue:"cus_code"},
    {text:"Company",textValue:"Company"},
    {text:"REG",textValue:"dcc"},
    {text:"DCC Status",textValue:"dcc_status"},
    {text:"PRODUCT NAME",textValue:"trade_name"},
    {text:"OPEN DATE",textValue:"open_date"},
    {text:"COMPLETED DATE",textValue:"complete_date"}
  ];
  sortOrderList2=[
    {text:"",textValue:""},
    {text:"[none]",textValue:"[none]"},
    {text:"Company",textValue:"Company"},
    {text:"REG",textValue:"REG"},
    {text:"DCC Status",textValue:"DCC Status"},
    {text:"PRODUCT NAME",textValue:"PRODUCT NAME"},
    {text:"OPEN DATE",textValue:"OPEN DATE"},
    {text:"COMPLETED DATE",textValue:"COMPLETED DATE"}
  ];
  constructor(private pspBaseService: PspBaseService, private formBuilder: FormBuilder, private translate: TranslateService) {
    this.nonFoodReviewLogForm = this.formBuilder.group({
      dcc: new FormControl(''),
      company: new FormControl(''),
      program: new FormControl(''),
      dccStatus: new FormControl(''),
      productStatus: new FormControl(''),
      country: new FormControl(''),
      category: new FormControl(''),
      statusChangeFrom: new FormControl(''),
      statusChangeTo: new FormControl(''),
      revisionStatus: new FormControl(''),
      displayRevision: new FormControl(''),
      displayInitials: new FormControl(''),
      sortOrder1: new FormControl(''),
      sortOrder2: new FormControl('')
    });
   }

  ngOnInit(): void {
    this.translate.get('masters').subscribe( (text: string) => {
      this.masterTranslate = text;
    });
    this.programDropDown();
    this.programStatus();
    this.revisionStatus();
    this.reviewdccStatus();
    this.nonFoodReviewLogForm.controls.displayRevision.setValue(this.displayRevisions[0].textValue);
    this.nonFoodReviewLogForm.controls.displayInitials.setValue(this.displayInitials[0].textValue);
    this.nonFoodReviewLogForm.controls.sortOrder1.setValue('cus_code');
    
  }

  public programDropDown(){
    const reqObj = {};
    this.pspBaseService
    .nonFoodReviewProgramDropDown(reqObj)
    .pipe(takeUntil(this.isActive))
    .subscribe(
    (response: any) => {
      if (response.status === 'SUCCESS') {
        this.programDropDownList = response.results;
        let code = this.programDropDownList[0]["code"];
        this.nonFoodReviewLogForm.controls.program.setValue(code);
      }
    });
  }
  public programStatus(){
    const reqObj = {};
    this.pspBaseService
    .nonFoodReviewProgramStatus(reqObj)
    .pipe(takeUntil(this.isActive))
    .subscribe(
    (response: any) => {
      if (response.status === 'SUCCESS') {
        this.programStatusList = response.results;
        this.programStatusList.forEach((row: any) => {
          if(row.TO_STATUS_VALUE === "ALL"){
            this.nonFoodReviewLogForm.controls.productStatus.setValue(row.TO_STATUS_VALUE);
          }
        });
      }
    });
  }
  public revisionStatus(){
    const reqObj = {};
    this.pspBaseService
    .nonFoodReviewRevisionStatus(reqObj)
    .pipe(takeUntil(this.isActive))
    .subscribe(
    (response: any) => {
      if (response.status === 'SUCCESS') {
        this.revisionStatusList = response.results;
        this.revisionStatusList.forEach((row: any) => {
          if(row.dropdown === "ALL"){
            this.nonFoodReviewLogForm.controls.revisionStatus.setValue(row.dropdown);
          }
        });
      }
    });
  }
  public reviewdccStatus(){
    const reqObj = {};
    this.loader=true;
    this.pspBaseService
    .nonFoodReviewdccStatus(reqObj)
    .pipe(takeUntil(this.isActive))
    .subscribe(
    (response: any) => {
      this.loader=false;
      if (response.status === 'SUCCESS') {
        this.reviewdccStatusList = response.results;
        this.reviewdccStatusList.forEach((row: any) => {
          if(row.TO_STATUS_VALUE === "ALL"){
            this.nonFoodReviewLogForm.controls.dccStatus.setValue(row.TO_STATUS_VALUE);
          }
        });
      }
    });
  }
  public clearSearch(): void {
    this.nonFoodReviewLogForm.reset();
  }
  public search(): void {
    this.loader = true;
    const reqObj = this.nonFoodReviewLogForm.value;
    this.pspBaseService
    .nonFoodReviewnonFood(reqObj)
    .pipe(takeUntil(this.isActive))
    .subscribe(
    (response: any) => {
      this.loader=false;
      if (response.status === 'SUCCESS') {
        this.searchData = response.results;
      }
    });
  }

}
