import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BracketingReportComponent } from './bracketing-report.component';

describe('BracketingReportComponent', () => {
  let component: BracketingReportComponent;
  let fixture: ComponentFixture<BracketingReportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BracketingReportComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BracketingReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
