import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl } from '@angular/forms';
import { PspBaseService } from '../../services/psp-base.service';

@Component({
  selector: 'app-bracketing-report',
  templateUrl: './bracketing-report.component.html',
  styleUrls: ['./bracketing-report.component.scss']
})
export class BracketingReportComponent implements OnInit {

  confidential=["No", "Yes"];
  notify={};
  isloading =false;

  formBracketing:FormGroup = this.formBuilder.group({
    psf: new FormControl(''),
    dcc:new FormControl(''),
    plant:new FormControl(''),
    corporate:new FormControl(''),
    includeConfidential:new FormControl('Yes'),
  });

  constructor(private formBuilder:FormBuilder, private pspService:PspBaseService) { }

  ngOnInit(): void {
  }

  onSearch(){
    this.isloading =true;
    console.log(this.formBracketing.value);
    const form = this.formBracketing.controls;
    if(form.psf.value || form.dcc.value || form.plant.value || form.corporate.value || form.includeConfidential.value){
      this.pspService.getBracketingDCC(this.formBracketing.value).subscribe(
        (response:any) =>{
          
          if(response.status === 'SUCCESS'){
              this.notify ={
                style:'success',
                content:response.results[0].message
              }
          }else{
            this.notify ={
              style:'error',
              content: response.results[0].message
            }
          }
          this.isloading =false;
        }
      )
      
    }else{
      this.notify ={
        style:'error',
        content:'Please Enter Atleast One Parameter'
      }
      this.isloading =false;
    }
    
  }

  onClear(){
    this.formBracketing.reset();
    this.notify={};
    this.formBracketing = this.formBuilder.group({
      psf: new FormControl(''),
      dcc:new FormControl(''),
      plant:new FormControl(''),
      corporate:new FormControl(''),
      includeConfidential:new FormControl('Yes'),
    });
  }

}
