import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TrackingReportsRoutingModule } from './tracking-reports-routing.module';
import { NonfoodReviewLogComponent } from './nonfood-review-log/nonfood-review-log.component';
import { PspBaseService } from '../services/psp-base.service';
import { TrackingReportsComponent } from './tracking-reports.component';
import { ProductusingDccreportComponent } from './productusing-dccreport/productusing-dccreport.component';
import { FailureresolutionTrackingComponent } from './failureresolution-tracking/failureresolution-tracking.component';
import { TurnaroundTimestoxComponent } from './turnaround-timestox/turnaround-timestox.component';
import { BracketingToolComponent } from './bracketing-tool/bracketing-tool.component';
import { BracketingReportComponent } from './bracketing-report/bracketing-report.component';
import { ProductstatusReportComponent } from './productstatus-report/productstatus-report.component';
import { TranslateModule } from '@ngx-translate/core';
import { InputsModule } from '@progress/kendo-angular-inputs';
import { LabelModule } from '@progress/kendo-angular-label';
import { DropDownsModule } from '@progress/kendo-angular-dropdowns';
import { ExcelModule, GridModule } from '@progress/kendo-angular-grid';
import { AppSharedModule } from '../../../app-shared/app-shared.module';
import { DateInputsModule } from '@progress/kendo-angular-dateinputs';
import { FormsModule } from '@angular/forms';



@NgModule({
  declarations: [
    NonfoodReviewLogComponent,
    TrackingReportsComponent,
    ProductusingDccreportComponent,
    FailureresolutionTrackingComponent,
    TurnaroundTimestoxComponent,
    BracketingToolComponent,
    BracketingReportComponent,
    ProductstatusReportComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    TrackingReportsRoutingModule,
    TranslateModule,
    InputsModule,
    LabelModule,
    DropDownsModule,
    GridModule,
    AppSharedModule,
    ExcelModule,
    DateInputsModule
  ],
  providers: [ PspBaseService ],
})
export class TrackingReportsModule { }
