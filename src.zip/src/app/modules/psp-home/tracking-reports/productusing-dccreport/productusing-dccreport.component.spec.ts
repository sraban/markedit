import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductusingDccreportComponent } from './productusing-dccreport.component';

describe('ProductusingDccreportComponent', () => {
  let component: ProductusingDccreportComponent;
  let fixture: ComponentFixture<ProductusingDccreportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProductusingDccreportComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductusingDccreportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
