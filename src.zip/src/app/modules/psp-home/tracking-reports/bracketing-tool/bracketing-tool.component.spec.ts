import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BracketingToolComponent } from './bracketing-tool.component';

describe('BracketingToolComponent', () => {
  let component: BracketingToolComponent;
  let fixture: ComponentFixture<BracketingToolComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BracketingToolComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BracketingToolComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
