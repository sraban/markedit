import { Component, OnInit } from '@angular/core';
import { PspBaseService } from '../../services/psp-base.service';
import { FormBuilder, FormGroup, FormControl, FormArray, Form } from '@angular/forms';

@Component({
  selector: 'app-bracketing-tool',
  templateUrl: './bracketing-tool.component.html',
  styleUrls: ['./bracketing-tool.component.scss']
})
export class BracketingToolComponent implements OnInit {

  reports =["Formulation_Tool"];
  selectedReport ="WPL_Tool";
  DCCStatus:any[]=[];
  formBracketing :any;
  dccArray!:FormArray;
  bracketingStatus:any;
  notify ={};  
  isloading=false;



  constructor(private pspService:PspBaseService, private formBuilder:FormBuilder) { 
    
  }

  ngOnInit(): void {
    //let arr = Array(20).fill(this.addDcc())

    this.pspService.getStatusBracketingTool({}).subscribe(
      (response:any) =>{
        console.log(response);
        
        this.bracketingStatus =response.results[0];

        console.log(this.bracketingStatus.dccStatus)

        for(let i=0; i<response.results.length; i++){
          this.DCCStatus.push(response.results[i].toStatusValue);
        }
      }
    )

    this.formBracketing = this.formBuilder.group({
      corporate: new FormControl(''),
      dccStatus: new FormControl('All'),
      reportType: new FormControl('WPL_Pool'),
      initialReview: new FormControl(''),
      revisionReview:new FormControl(''),
      facilityNos: this.formBuilder.array([this.addDcc()]),
      dccNos: this.formBuilder.array([this.addDcc(), this.addDcc(), this.addDcc()])
    })
  }

  //formArrayName="facilityNos" *ngFor"let faci of getFacility(); let i=index"

  onClear(){
    this.formBracketing.reset();
    this.formBracketing = this.formBuilder.group({
      corporate: new FormControl(''),
      dccStatus: new FormControl('All'),
      reportType: new FormControl('WPL_Pool'),
      initialReview: new FormControl(''),
      revisionReview:new FormControl(''),
      facilityNos: this.formBuilder.array([this.addDcc()]),
      dccNos: this.formBuilder.array([this.addDcc(), this.addDcc(), this.addDcc()])
    })
  }

  onExecute(){
   let dccNos = this.formBracketing.controls.dccNos.value;
   
    dccNos = dccNos.filter((e:any) => e);
    console.log(dccNos)
    console.log(this.formBracketing.value);


    const reqObj ={
      corporate: this.formBracketing.controls.corporate.value,
      dccStatus: this.formBracketing.controls.dccStatus.value,
      reportType: this.formBracketing.controls.reportType.value,
      dccNos: dccNos
    }


    let facilityNos = this.formBracketing.controls.facilityNos.value;
    facilityNos = facilityNos.filter((e:any) => e);


    const filename ={
      corporate: this.formBracketing.controls.corporate.value,
      dccNos: dccNos,
      dccStatus: this.formBracketing.controls.dccStatus.value,
      reportType: this.formBracketing.controls.reportType.value,
      facilityNos: facilityNos
    }

    this.pspService.getFilename(filename).subscribe(
      (response:any)=>{
        console.log(response);
      }
    )

    console.log(reqObj)
    if(reqObj.dccNos.length != 0){
      this.isloading =true;

      this.pspService.getBracketingTool(reqObj).subscribe(
        (response:any)=>{
          this.isloading=false;
          console.log(response);
          if(response.status === 'SUCCESS'){
            this.notify ={
              style:'success',
              content: response.results[0].message
            }
          }else{
            this.notify ={
              style:'error',
              content: response.results[0].message
            }
          }
        }
      )
    }else{
      this.isloading =false;
      this.notify ={
        style:'error',
        content: 'Please enter atleast one DCC'
      }
    }
    
  }

  addDcc(): FormControl{
    return new FormControl('')
  }

  addNewDCC(){
    this.dccArray = this.formBracketing.get('dccNos') as FormArray;
    this.dccArray.push(this.addDcc());
  }
  removeDCC(i:any){
    (<FormArray>this.formBracketing.get('dccNos')).removeAt(i);
  }

  getDccArray(){
    return (this.formBracketing.get('dccNos') as FormArray).controls;
  }
  getFacility(){
    return (this.formBracketing.get('facilityNos') as FormArray).controls;
  }
}
