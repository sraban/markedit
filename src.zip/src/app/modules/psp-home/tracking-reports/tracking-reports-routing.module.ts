import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { NonfoodReviewLogComponent } from './nonfood-review-log/nonfood-review-log.component';
import { TrackingReportsComponent } from './tracking-reports.component';
import { ProductusingDccreportComponent } from './productusing-dccreport/productusing-dccreport.component';
import { FailureresolutionTrackingComponent } from './failureresolution-tracking/failureresolution-tracking.component';
import { BracketingReportComponent } from './bracketing-report/bracketing-report.component';
import { ProductstatusReportComponent } from './productstatus-report/productstatus-report.component';
import { BracketingToolComponent } from './bracketing-tool/bracketing-tool.component';
import { TurnaroundTimestoxComponent } from './turnaround-timestox/turnaround-timestox.component';

const routes: Routes = [
  {
    path: '',
    component: TrackingReportsComponent,
    children: [
      { path: '', redirectTo: 'productdccReport', pathMatch: 'full' },
      { path: 'productdccReport', component: ProductusingDccreportComponent},
      { path: 'failureResolution', component: FailureresolutionTrackingComponent},
      { path: 'bracketingReport', component: BracketingReportComponent},
      { path: 'turnaroundTimes', component: TurnaroundTimestoxComponent},
      { path: 'productStatusReport', component: ProductstatusReportComponent},
      { path: 'nonFoodReviewLog', component: NonfoodReviewLogComponent },
      { path: 'bracketingTool', component: BracketingToolComponent},
    ]
  }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TrackingReportsRoutingModule { }
