import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-tracking-reports',
  templateUrl: './tracking-reports.component.html',
  styleUrls: ['./tracking-reports.component.scss']
})
export class TrackingReportsComponent implements OnInit {

  valueChangItem:any;

  constructor(private routing:Router) { }

  ngOnInit(): void {
    this.valueChangItem = this.routing.url.split('/', 3)[2];
    this.valueChangItem = this.valueChangItem.split(/(?=[A-Z])/).join(' ');
  }

}
