import { Component, OnInit,ViewChildren } from '@angular/core';
import { Validators, FormGroup, FormBuilder,FormControl } from "@angular/forms";
import { takeUntil } from 'rxjs/operators';
import { Subject } from 'rxjs';
import { PspBaseService } from '../../services/psp-base.service';
import { TranslateService } from '@ngx-translate/core';
@Component({
  selector: 'app-productstatus-report',
  templateUrl: './productstatus-report.component.html',
  styleUrls: ['./productstatus-report.component.scss']
})
export class ProductstatusReportComponent implements OnInit {

  public gridData: any;
  public notify: any;
  submitted = false;
  controlNames: any;
  isloading =false;
  
    // public gridData: any[] = [
    //   {
    //       "ProductID": 1,
    //       "ProductName": "Chai",
    //       "SupplierID": 1,
    //       "CategoryID": 1,
    //       "QuantityPerUnit": "10 boxes x 20 bags",
    //       "UnitPrice": 18,
    //       "UnitsInStock": 39,
    //       "UnitsOnOrder": 0,
    //       "ReorderLevel": 10,
    //       "Discontinued": false,
    //       "FirstOrderedOn": new Date(1996, 8, 20)
    //   }];
  
  
   
  
    dropItems: any;
    private isActive = new Subject();
  
    public form: FormGroup = new FormGroup({
      dcc: new FormControl(''),
      orderBy: new FormControl(''),
      acceptNews: new FormControl(''),
      tradeName: new FormControl(''),
      supplierName: new FormControl(''),
    });
    // this.controlNames = {
    //   dcc: 'Code',
    //   orderBy: 'Description',
    // };
   constructor(private formBuilder: FormBuilder, private pspBaseService: PspBaseService,private translate: TranslateService) {
  }
  
    ngOnInit(): void {
      this.initializeForm();
  
      this.gettingorderByDropDown();
     }
     initializeForm(): any {
      this.form = this.formBuilder.group({
        dcc: new FormControl(''),
        orderBy: new FormControl(''),
        droppedProduct: new FormControl(''),
        tradeName: new FormControl(''),
        supplierName: new FormControl(''),
      });
      this.controlNames = {
        dcc: 'At least one of the parameters has to be entered ',
      };
    }
    public clearForm(): void {
     this.form.reset();
    }
  // tslint:disable-next-line:typedef
    public gettingorderByDropDown() {
      const reqObj = { };
      this.dropItems = [];
      this.pspBaseService.getorderByDropdown(reqObj).pipe(takeUntil(this.isActive)).subscribe(
        (response: any) => {
          if (response.status === 'SUCCESS') {
             response.results.forEach((row: any) => {
              this.dropItems.push({'DATA_VALUE':row.orderBy, 'DISPLAY_VALUE':row.display});
             });
          }
        },
        (err: any) => {
          }
        );
    }
   public submitForm(): any {
      this.form.markAllAsTouched();
      this.submitted = false;
      this.notify = {};
       const reqObj = {
        dcc: this.form.controls.dcc.value,
        orderBy: this.form.controls.orderBy.value,
        droppedProduct: this.form.controls.droppedProduct ? 'N' : 'Y',
        supplierName:this.form.controls.supplierName.value || '',
        tradeName:this.form.controls.tradeName.value || ''
      };
      this.gettingproductDcc(reqObj);
    }
    // Search product dcc
    public gettingproductDcc(reqObj: any) {
      // this.isloading =true;
      this.submitted = true;
     this.notify = {};
      // const req = this.form.value;
      // req.info_required_flg = info_required_flg ? 'Y' : 'N';
       this.pspBaseService.getproductDcc(reqObj).pipe(takeUntil(this.isActive)).subscribe(
        (response: any) => {
          if (response.status === 'SUCCESS' || 1) {
            this.gridData = response.results;
           setTimeout( () => {
                (<any>document).querySelector("#gridForExcel .k-grid-excel").click();
              },2000);
              }  
          },
        
        (err: any) => {
            this.notify = {
              style: 'error',
              content: 'no data'
            };
          }
  
        );
    }
  
  } 
  
  
  
  
