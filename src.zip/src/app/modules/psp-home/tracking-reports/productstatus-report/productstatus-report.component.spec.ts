import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductstatusReportComponent } from './productstatus-report.component';

describe('ProductstatusReportComponent', () => {
  let component: ProductstatusReportComponent;
  let fixture: ComponentFixture<ProductstatusReportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProductstatusReportComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductstatusReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
