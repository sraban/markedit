import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { PanelBarItemModel } from '@progress/kendo-angular-layout';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { PspBaseService } from '../../services/psp-base.service';
import { forkJoin } from 'rxjs';

@Component({
  selector: 'app-cas-chemical',
  templateUrl: './cas-chemical.component.html',
  styleUrls: ['./cas-chemical.component.scss']
})
export class CasChemicalComponent implements OnInit {
  value='';
  counter = 0;
  chemicalForm!: FormGroup;
  percentageItems: any = [];
  allPercentageItems: any = [];
  public defaultValue = 'EQUAL_TO';
  public loader: any;
  public notify: any;

  @Output() searchChemicalForm = new EventEmitter();
  constructor(private formBuilder: FormBuilder, private pspBaseService: PspBaseService) { }

  public items: Array<PanelBarItemModel> = [
    { title: 'CAS Chemical', content: 'content', expanded: false } as PanelBarItemModel,
];



  ngOnInit(): void {
    this.chemicalForm = this.formBuilder.group({
      casNumber: [''],
      percentageDropdown: [''],
      percentageText: [''],
      chemicalName: [''],
  });
    this.chemicalForm.valueChanges.subscribe((res) => {
    this.searchChemicalForm.emit(this.chemicalForm.value);
  });

  // clear all function
    this.pspBaseService.resetForm.subscribe((data) => {
    if (data){
      this.chemicalForm.reset();
      this.chemicalForm.get('percentageDropdown')?.patchValue('EQUAL_TO');
    }
  });

    // API integration Chemical Dropdown List
    const percentageRequest = {VALUE_SET_NAME: 'PT_GRT_SML_EQL'};
    const percentage = this.pspBaseService.getDropdownAPI( 'lookupNames', percentageRequest);

    forkJoin([percentage]).subscribe((data: any) => {
      this.percentageItems = data[0].results;
      this.allPercentageItems = this.percentageItems.map(( res: any ) => {
        return {
          DATA_VALUE: res.DATA_VALUE ,
          DISPLAY_VALUE: res.DISPLAY_VALUE == null ? 'null' : res.DISPLAY_VALUE
        };
      });
    },
    (err: any) => {
      this.loader = false;
      this.notify =
       {
         style : 'error',
        content : err.statusText
       };

      }
    );
  }

}
