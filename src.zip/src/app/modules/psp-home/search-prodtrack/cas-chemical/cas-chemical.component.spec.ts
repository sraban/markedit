import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CasChemicalComponent } from './cas-chemical.component';

describe('CasChemicalComponent', () => {
  let component: CasChemicalComponent;
  let fixture: ComponentFixture<CasChemicalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CasChemicalComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CasChemicalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
