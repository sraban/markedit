import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { DropDownFilterSettings } from '@progress/kendo-angular-dropdowns';
import { PanelBarItemModel } from '@progress/kendo-angular-layout';
import { forkJoin, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { PspBaseService } from '../../services/psp-base.service';

@Component({
  selector: 'app-water-assembly',
  templateUrl: './water-assembly.component.html',
  styleUrls: ['./water-assembly.component.scss'],
})
export class WaterAssemblyComponent implements OnInit {
  waterAssemblyForm!: FormGroup;
  dialogFlag = false;
  surfaceAreaGSED: any;
  surfaceAreaUnitDrop: any;
  capacityGSED: any;
  capacityVolumeUnitDrop: any;
  maxUseLevelGSED: any;
  maxRatedPressureGSED: any;
  maxRatedPressureUnitDrop: any;
  sizeGSED: any;
  sizeUnit: any;
  waterContactTemp: any;
  repackagesBlenderDilute: any;
  connectionTyeCategory: any;
  methodOfManufacturing: any;
  fieldAdded!: boolean;
  controlValues: any = [];
  surfaceAreaEqual: any = [];
  capacityEqual: any = [];
  maxUseLevelEqual: any = [];
  sizeEqual: any = [];
  maxRatedPressureEqual: any = [];
  dataFromChild: any;
  private isActive = new Subject();
  reductionClaimLookUpGridData: any;
  titleLabel = '';
  SystemTypeTitleLabel = '';
  endUseTitleLabel = '';
  materialTypeTitleLabel = '';
  functionTitleLabel = '';
  sectionCategoryTitleLabel = '';
  height = 420;
  public defaultValue = 'EQUAL_TO';
  public defaultValueCapacity = 'EQUAL_TO';
  public defaultValueSize = 'EQUAL_TO';
  public defaultValueMaxRatedPressure = 'EQUAL_TO';
  public defaultValueMaxUseLevel = 'EQUAL_TO';

  public selectedUnit = 'SQIN';

  public selectedCapacity = 'LITERS';
  public selectedMaxPressure = 'PSI';

  lookUpHeader: any = [];
  SystemLookupHeader: any = [];
  endUseLookupHeader: any = [];
  materailLookupHeader: any = [];
  functionLookupHeader: any = [];
  sectionCategoryLookupHeader: any = [];
  pageable = {
    pageable: true,
    pageSize: 25,
  };
  systemTypedialogFlag!: boolean;
  systemTypeLookUpGridData: any;
  endUseLookUpGridData: any;
  materialTypeLookUpGridData: any;
  endUsedialogFlag!: boolean;
  materialTypedialogFlag!: boolean;
  functiondialogFlag!: boolean;
  sectionCategorydialogFlag!: boolean;
  functionLookUpGridData: any;
  sectionCategoryLookUpGridData: any;
  sectionCategorydataFromChild: any;
  functionDataFromChild: any;
  materialDataFromChild: any;
  endUseDataFromChild: any;
  systemTypeDataFromChild: any;
  addedFieldIndex: any;
  public filterSettings: DropDownFilterSettings = {
    caseSensitive: false,
    operator: 'startsWith',
  };
  @Output() searchWaterAssemblyForm = new EventEmitter();
  waterAssemblyTranslate: any;
  public defaultItem: any = {
    DATA_VALUE: '',
    DISPLAY_VALUE: '',
    STATUS: null,
    VALUE_SET_NAME: null,
  };
  repackagesBlender: any;
  constructor(
    private formBuilder: FormBuilder,
    private pspBaseService: PspBaseService,
    private translate: TranslateService
  ) {}
  public items: Array<PanelBarItemModel> = [
    {
      title: 'Water Assembly / Material',
      content: 'content',
      expanded: false,
    } as PanelBarItemModel,
  ];
  ngOnInit(): void {
    this.translate.get('waterAssembly').subscribe( (text: string) => {

      this.waterAssemblyTranslate = text;
      this.titleLabel = this.waterAssemblyTranslate.titleLabel;
      this.SystemTypeTitleLabel = this.waterAssemblyTranslate.SystemTypeTitleLabel;
      this.endUseTitleLabel = this.waterAssemblyTranslate.endUseTitleLabel;
      this.materialTypeTitleLabel = this.waterAssemblyTranslate.materialTypeTitleLabel;
      this.functionTitleLabel = this.waterAssemblyTranslate.functionTitleLabel;
      this.sectionCategoryTitleLabel = this.waterAssemblyTranslate.sectionCategoryTitleLabel;
      this.lookUpHeader = [
        {
          field: 'descr',
          header_title: 'Description',
          width: 200,
          type: 'input_text',
        },
      ];
      this.SystemLookupHeader = [
        {
          field: 'descr',
          header_title: 'Description',
          width: 200,
          type: 'input_text',
        },
      ];
      this.endUseLookupHeader = [
        {
          field: 'descr',
          header_title: 'Description',
          width: 200,
          type: 'input_text',
        },
      ];
      this.materailLookupHeader = [
        {
          field: 'descr',
          header_title: 'Description',
          width: 200,
          type: 'input_text',
        },
      ];
      this.functionLookupHeader = [
        {
          field: 'code',
          header_title: 'Code',
          width: 200,
          type: 'input_text',
        },
        {
          field: 'descr',
          header_title: 'Description',
          width: 200,
          type: 'input_text',
        },
      ];
      this.sectionCategoryLookupHeader = [
        {
          field: 'code',
          header_title: 'Code',
          width: 200,
          type: 'input_text',
        },
        {
          field: 'descr',
          header_title: 'Description',
          width: 200,
          type: 'input_text',
        },
      ];
    })
    this.waterAssemblyForm = this.formBuilder.group({
      assemblyCheck: new FormControl(true),
      materialCheck: new FormControl(true),
      ingrediantCheck: new FormControl(true),
      part: [''],
      surfaceArea: [''],
      surfaceAreaGSED: [''],
      surfaceAreaText: [''],
      surfaceAreaDrop2: [''],
      waterContactTemp: [''],
      function: [''],
      selectionCategory: [''],
      connectionTypeDetails: [''],
      temperature: [''],
      replacementElement: [''],
      capacitydrop: [''],
      capacityText: [''],
      capacityDrop1: [''],
      maxratedPressureDrop: [''],
      maxratedPressureText: [''],
      maxratedPressureDrop1: [''],
      endUse: [''],
      materialType: [''],
      maxUseLevel: [''],
      maxUseLevelText: [''],
      productChemicalName: [''],
      repackagerBlender: [''],
      size: [''],
      sizeText: [''],
      sizeDrop2: [''],
      approvalNumber: [''],
      shoreHardness: [''],
      reductionClaim: [''],
      systemType: [''],
      connectionTypeCategory: [''],
      methodofManufacturing: [''],
      newclassification: this.formBuilder.array([]),
    });

    this.waterAssemblyForm.valueChanges.subscribe((res) => {
      this.searchWaterAssemblyForm.emit(this.waterAssemblyForm.value);
    });

    // clear all function
    this.pspBaseService.resetForm.subscribe((data) => {
      if (data) {
        this.waterAssemblyForm.reset();
        (this.waterAssemblyForm.get('newclassification') as FormArray).clear();
        this.waterAssemblyForm.get('surfaceAreaGSED')?.patchValue('EQUAL_TO');
        this.waterAssemblyForm.get('surfaceAreaDrop2')?.patchValue('SQIN');
        this.waterAssemblyForm.get('maxUseLevel')?.patchValue('EQUAL_TO');
        this.waterAssemblyForm.get('size')?.patchValue('EQUAL_TO');
        this.waterAssemblyForm.get('capacitydrop')?.patchValue('EQUAL_TO');
        this.waterAssemblyForm.get('capacityDrop1')?.patchValue('LITERS');
        this.waterAssemblyForm.get('maxratedPressureDrop')?.patchValue('EQUAL_TO');
        this.waterAssemblyForm.get('maxratedPressureDrop1')?.patchValue('PSI');
        this.waterAssemblyForm.get('assemblyCheck')?.patchValue(true);
        this.waterAssemblyForm.get('materialCheck')?.patchValue(true);
        this.waterAssemblyForm.get('ingrediantCheck')?.patchValue(true);
      }
    });

    const surfaceAreaReq = { VALUE_SET_NAME: 'PT_GRT_SML_EQL' };
    const surfaceAreaGSED = this.pspBaseService.getDropdownAPI(
      'lookupNames',
      surfaceAreaReq
    );
    const surfaceAreaUnitDropReq = { VALUE_SET_NAME: 'PT_CONTACT_AREA_UNIT' };
    const surfaceAreaUnitDrop = this.pspBaseService.getDropdownAPI(
      'lookupNames',
      surfaceAreaUnitDropReq
    );
    const capacityGSEDRequest = { VALUE_SET_NAME: 'PT_GRT_SML_EQL' };
    const capacityGSED = this.pspBaseService.getDropdownAPI(
      'lookupNames',
      capacityGSEDRequest
    );
    const capacityVolumeUnitDropRequest = {
      VALUE_SET_NAME: 'PT_VOLUME_UNITS',
    };
    const capacityVolumeUnitDrop = this.pspBaseService.getDropdownAPI(
      'lookupNames',
      capacityVolumeUnitDropRequest
    );
    const maxUseLevelRequest = { VALUE_SET_NAME: 'PT_GRT_SML_EQL' };
    const maxUseLevelGSED = this.pspBaseService.getDropdownAPI(
      'lookupNames',
      maxUseLevelRequest
    );
    const maxRatedPressureRequest = { VALUE_SET_NAME: 'PT_GRT_SML_EQL' };
    const maxRatedPressureGSED = this.pspBaseService.getDropdownAPI(
      'lookupNames',
      maxRatedPressureRequest
    );
    const maxRatedPressureUnitDropRequest = { VALUE_SET_NAME: 'PT_DWTU_UNITS' };
    const maxRatedPressureUnitDrop = this.pspBaseService.getDropdownAPI(
      'lookupNames',
      maxRatedPressureUnitDropRequest
    );
    const sizeRequest = { VALUE_SET_NAME: 'PT_GRT_SML_EQL' };
    const sizeGSED = this.pspBaseService.getDropdownAPI(
      'lookupNames',
      sizeRequest
    );
    const sizeUnitRequest = { VALUE_SET_NAME: 'SIZE_UNIT' };
    const sizeUnit = this.pspBaseService.getDropdownAPI(
      'lookupNames',
      sizeUnitRequest
    );
    const waterContactRequest = { VALUE_SET_NAME: '61_TEMP_TYPE' };
    const waterContactTemp = this.pspBaseService.getDropdownAPI(
      'lookupNames',
      waterContactRequest
    );
    const repackagerRequest = { VALUE_SET_NAME: 'PT_RBDL' };
    const repackagesBlenderDilute = this.pspBaseService.getDropdownAPI(
      'lookupNames',
      repackagerRequest
    );
    const connectionTyeCategoryReq = {
      VALUE_SET_NAME: 'PT_CONN_TYPE_CATEGORY',
    };
    const connectionTyeCategory = this.pspBaseService.getDropdownAPI(
      'lookupNames',
      connectionTyeCategoryReq
    );
    const methodofManufacturingReq = {
      VALUE_SET_NAME: 'PT_METHOD_OF_MANUFACTURING',
    };
    const methodOfManufacturing = this.pspBaseService.getDropdownAPI(
      'lookupNames',
      methodofManufacturingReq
    );
    // tslint:disable-next-line:max-line-length
    forkJoin([
      surfaceAreaGSED,
      surfaceAreaUnitDrop,
      capacityGSED,
      capacityVolumeUnitDrop,
      maxUseLevelGSED,
      maxRatedPressureGSED,
      maxRatedPressureUnitDrop,
      sizeGSED,
      sizeUnit,
      waterContactTemp,
      repackagesBlenderDilute,
      connectionTyeCategory,
      methodOfManufacturing,
    ]).subscribe((response: any) => {
      this.surfaceAreaEqual = response[0].results;
      this.surfaceAreaUnitDrop = response[1].results;
      this.surfaceAreaUnitDrop.unshift({DATA_VALUE: ' ', DISPLAY_VALUE: ' '});
      this.capacityEqual = response[2].results;
      this.capacityVolumeUnitDrop = response[3].results;
      this.capacityVolumeUnitDrop.unshift({DATA_VALUE: ' ', DISPLAY_VALUE: ' '});
      this.maxUseLevelEqual = response[4].results;
      this.maxRatedPressureEqual = response[5].results;
      this.maxRatedPressureUnitDrop = response[6].results;
      this.sizeEqual = response[7].results;
      this.sizeUnit = response[8].results;
      this.waterContactTemp = response[9].results;
      this.repackagesBlender = response[10].results;
      this.connectionTyeCategory = response[11].results;
      this.methodOfManufacturing = response[12].results;
      this.repackagesBlenderDilute = this.repackagesBlender.map((res: any) => {
        return {
          DATA_VALUE: res.DATA_VALUE == null ? 'null' : res.DATA_VALUE,
          DISPLAY_VALUE: res.DISPLAY_VALUE == null ? 'null' : res.DISPLAY_VALUE,
        };
      });
      this.surfaceAreaGSED = this.surfaceAreaEqual.map((res: any) => {
        return {
          DATA_VALUE: res.DATA_VALUE,
          DISPLAY_VALUE: res.DISPLAY_VALUE == null ? 'null' : res.DISPLAY_VALUE,
        };
      });
      this.capacityGSED = this.capacityEqual.map((resCap: any) => {
        return {
          DATA_VALUE: resCap.DATA_VALUE,
          DISPLAY_VALUE:
            resCap.DISPLAY_VALUE == null ? 'null' : resCap.DISPLAY_VALUE,
        };
      });
      this.maxUseLevelGSED = this.maxUseLevelEqual.map((resp: any) => {
        return {
          DATA_VALUE: resp.DATA_VALUE,
          DISPLAY_VALUE:
            resp.DISPLAY_VALUE == null ? 'null' : resp.DISPLAY_VALUE,
        };
      });
      this.sizeGSED = this.sizeEqual.map((resSize: any) => {
        return {
          DATA_VALUE: resSize.DATA_VALUE,
          DISPLAY_VALUE:
            resSize.DISPLAY_VALUE == null ? 'null' : resSize.DISPLAY_VALUE,
        };
      });
      this.maxRatedPressureGSED = this.maxRatedPressureEqual.map(
        (resMax: any) => {
          return {
            DATA_VALUE: resMax.DATA_VALUE,
            DISPLAY_VALUE:
              resMax.DISPLAY_VALUE == null ? 'null' : resMax.DISPLAY_VALUE,
          };
        }
      );
    });
   
  }
  /* To open Reduction Claim Dialog to select lookup values */
  public openReductionClaim(i?: number): void {
    this.addedFieldIndex = i;
    this.dialogFlag = true;
    this.gettingReductionClaimLookupGrid();
  }
  /* To open System Type Dialog to select lookup values */
  public openSystemType(): any {
    this.systemTypedialogFlag = true;
    this.gettingSystemTypeLookupGrid();
  }
  /* To open End Use Dialog to select lookup values */
  public openEndUse(): any {
    this.endUsedialogFlag = true;
    this.gettingEndUseLookupGrid();
  }
  /* To open Master Type Dialog to select lookup values */
  public openMaterialType(): any {
    this.materialTypedialogFlag = true;
    this.gettingMaterialTypeLookupGrid();
  }
  /* To open Select Category Dialog to select lookup values */
  public openSelectionCategory(): any {
    this.sectionCategorydialogFlag = true;
    this.gettingSectionCategoryLookupGrid();
  }
  /* To open Function Dialog to select lookup values */
  public openFunction(): any {
    this.functiondialogFlag = true;
    this.gettingFunctionLookupGrid();
  }
  public get newclassifications(): any {
    return this.waterAssemblyForm.get('newclassification') as FormArray;
  }
  /* To close dialog popup */
  public onDialogClose(): void {
    this.dialogFlag = false;
  }
  /* To close dialog popup */
  public onSystemTypeDialogClose(): void {
    this.systemTypedialogFlag = false;
  }
  /* To close dialog popup */
  public endUseDialogClose(): void {
    this.endUsedialogFlag = false;
  }
  /* To close dialog popup */
  public onMaterialTypeDialogClose(): void {
    this.materialTypedialogFlag = false;
  }
  /* To close dialog popup */
  public onFunctionDialogClose(): void {
    this.functiondialogFlag = false;
  }
  /* To close dialog popup */
  public onSectionCategoryDialogClose(): void {
    this.sectionCategorydialogFlag = false;
  }
  /* To Add additional field*/

  public addNewReductionClaimField(): any {
    if (this.newclassifications.length <= 3) {
      this.newclassifications.push(new FormControl());
      this.fieldAdded = true;
      this.controlValues.push('');
    }
  }
  /* To Remove additional field*/
  public removeReductionClaim(i: number): any {
    this.controlValues.splice(i, 1);
    this.newclassifications.removeAt(i);
  }
  selectedRowData(data: any): void {
    if (this.addedFieldIndex >= 0) {
      this.controlValues.splice(this.addedFieldIndex, 1, data.descr);
      this.waterAssemblyForm.controls.newclassification.patchValue(
        this.controlValues
      );
      this.addedFieldIndex = undefined;
    } else {
      this.dataFromChild = data.descr;
      this.waterAssemblyForm.controls.reductionClaim.patchValue(data.descr);
    }

    this.dialogFlag = false;
  }
  /* To Select Row data value*/
  systemSelectedRowData(data: any): void {
    this.systemTypeDataFromChild = data.descr;
    this.waterAssemblyForm.controls.systemType.patchValue(data.descr);

    this.systemTypedialogFlag = false;
  }
  /* To Select End Use Row data value*/
  endUseSelectedRowData(data: any): void {
    this.endUseDataFromChild = data.descr;
    this.waterAssemblyForm.controls.endUse.patchValue(data.descr);

    this.endUsedialogFlag = false; 
  }
  /* To Select Material Type Row data value*/
  materialTypeSelectedRowData(data: any): void {
    this.materialDataFromChild = data.descr;
    this.waterAssemblyForm.controls.materialType.patchValue(data.descr);

    this.materialTypedialogFlag = false;
  }
  /* To Select Function field Row data value*/
  functionSelectedRowData(data: any): void {
    this.functionDataFromChild = data.descr;
    this.waterAssemblyForm.controls.function.patchValue(data.descr);

    this.functiondialogFlag = false;
  }
  /* To Select category field Row data value*/
  sectionCategoryselectedRowData(data: any): void {
    this.sectionCategorydataFromChild = data.descr;
    this.waterAssemblyForm.controls.selectionCategory.patchValue(data.descr);

    this.sectionCategorydialogFlag = false;
  }
  /* To get Reduction claim lookup grid Response*/
  public gettingReductionClaimLookupGrid(): any {
    const reqObj = {};
    this.pspBaseService
      .getReductionClaim(reqObj)
      .pipe(takeUntil(this.isActive))
      .subscribe((response: any) => {
        if (response.status === 'SUCCESS') {
          this.reductionClaimLookUpGridData = response.results;
        }
      });
  }
  /* To get System Type lookup grid Response*/
  public gettingSystemTypeLookupGrid(): any {
    const reqObj = {};
    this.pspBaseService
      .getSystemType(reqObj)
      .pipe(takeUntil(this.isActive))
      .subscribe((response: any) => {
        if (response.status === 'SUCCESS') {
          this.systemTypeLookUpGridData = response.results;
        }
      });
  }
  /* To get End Use lookup grid Response*/
  public gettingEndUseLookupGrid(): any {
    const reqObj = {};
    this.pspBaseService
      .getEndUse(reqObj)
      .pipe(takeUntil(this.isActive))
      .subscribe((response: any) => {
        if (response.status === 'SUCCESS') {
          this.endUseLookUpGridData = response.results;
        }
      });
  }
  /* To get Material Type lookup grid Response*/
  public gettingMaterialTypeLookupGrid(): any {
    const reqObj = {};
    this.pspBaseService
      .getMaterialTypeWA(reqObj)
      .pipe(takeUntil(this.isActive))
      .subscribe((response: any) => {
        if (response.status === 'SUCCESS') {
          this.materialTypeLookUpGridData = response.results;
        }
      });
  }
  /* To get Material Type lookup grid Response*/
  public gettingFunctionLookupGrid(): any {
    const reqObj = {};
    this.pspBaseService
      .getFunction(reqObj)
      .pipe(takeUntil(this.isActive))
      .subscribe((response: any) => {
        if (response.status === 'SUCCESS') {
          this.functionLookUpGridData = response.results;
        }
      });
  }
  /* To get Material Type lookup grid Response */
  public gettingSectionCategoryLookupGrid(): any {
    const reqObj = {};
    this.pspBaseService
      .getSectionCategory(reqObj)
      .pipe(takeUntil(this.isActive))
      .subscribe((response: any) => {
        if (response.status === 'SUCCESS') {
          this.sectionCategoryLookUpGridData = response.results;
        }
      });
  }
}
