import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WaterAssemblyComponent } from './water-assembly.component';

describe('WaterAssemblyComponent', () => {
  let component: WaterAssemblyComponent;
  let fixture: ComponentFixture<WaterAssemblyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WaterAssemblyComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(WaterAssemblyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
