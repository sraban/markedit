import {
  Component,
  OnInit,
  Output,
  EventEmitter,
} from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { PanelBarItemModel } from '@progress/kendo-angular-layout';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { PspBaseService } from '../../services/psp-base.service';

@Component({
  selector: 'app-dietary-supplements',
  templateUrl: './dietary-supplements.component.html',
  styleUrls: ['./dietary-supplements.component.scss'],
})
export class DietarySupplementsComponent implements OnInit {
  private isActive = new Subject();
  dietaryListItems: any;
  public classificationForm: FormGroup;
  productFormItems: any;
  dsproductTypeItems: any;
  lookUpDialogFlag = false;
  result!: string;
  dialogFlag = false;
  lookUpGridData: any;
  lookUpHeader: any = [];
  titleLabel = 'Select Classification';
  pageable = {
    pageable: true,
    pageSize: 25,
  };
  height = 420;
  colGroupHeader = '';
  public defaultItem: any = {
    DATA_VALUE: '',
    DISPLAY_VALUE: '',
    STATUS: null,
    VALUE_SET_NAME: null,
  };

  @Output() searchDietarySupplementsForm = new EventEmitter();
  dataFromChild: any;
  controlValues: any = [];
  public fieldAdded!: boolean;
  addedFieldIndex: any;
  constructor(
    private formBuilder: FormBuilder,
    private pspBaseService: PspBaseService,
  ) {
    this.classificationForm = this.formBuilder.group({
      classification: [''],
      rawMaterialNumber: [''],
      additionalClaimsonLabel: [''],
      dsProductType: [''],
      rawMaterialName: [''],
      productForm: [''],
      labelClaim: [''],
      newclassification: this.formBuilder.array([]),
    });
    this.classificationForm.valueChanges.subscribe((res) => {
      this.searchDietarySupplementsForm.emit(this.classificationForm.value);
    });
  }

  public items: Array<PanelBarItemModel> = [
    {
      title: 'Dietary Supplements',
      content: 'content',
      expanded: false,
    } as PanelBarItemModel,
  ];

  public get newclassifications(): any {
    return this.classificationForm.get('newclassification') as FormArray;
  }
    /* To Add additional field*/

  public addNewClassificationField(): any {
    if ( this.newclassifications.length <= 3) {
      this.newclassifications.push(new FormControl());
      this.fieldAdded = true;
      this.controlValues.push('');
    }
  }
  /* To Remove additional field*/
  public removeClassificationNUmber(i: number): any {
    this.controlValues.splice(i, 1);
    this.newclassifications.removeAt(i);
  }
  ngOnInit(): void {
    this.gettingProductForms();
    this.gettingDSProductType();
    this.lookUpHeader = [
      {
        field: 'descr',
        header_title: 'Description',
        width: 200,
        type: 'input_text',
      },
    ];
    // clear all function
    this.pspBaseService.resetForm.subscribe((data) => {
      if (data){
        this.classificationForm.reset();
        (this.classificationForm.get('newclassification') as FormArray).clear();
      }
    });
  }
  /* Getting response for Lookup grid Data */
  public gettingClassificationDetails(): any {
    const reqObj = {};
    this.pspBaseService
      .getClassificationDetails(reqObj)
      .pipe(takeUntil(this.isActive))
      .subscribe(
        (response: any) => {
          if (response.status === 'SUCCESS') {
            this.lookUpGridData = response.results;
          }
        },
      );
  }
  /* Getting response for product type dropdown data*/
  public gettingDSProductType(): any {
    const reqObj = {
      VALUE_SET_NAME: 'PT_DS_PROD_TYPE',
      STATUS: 'A',
    };
    this.pspBaseService
      .gettingProductTypeForms(reqObj)
      .pipe(takeUntil(this.isActive))
      .subscribe(
        (response: any) => {
          if (response.status === 'SUCCESS') {
            this.dsproductTypeItems = response.results;
          }
        },
      );
  }
  /* Getting response for product Form dropdown data */

  public gettingProductForms(): any {
    const reqObj = {
      VALUE_SET_NAME: 'PT_DS_PROD_FORM',
      STATUS: 'A',
    };
    this.pspBaseService
      .gettingProductTypeForms(reqObj)
      .pipe(takeUntil(this.isActive))
      .subscribe(
        (response: any) => {
          if (response.status === 'SUCCESS') {
            this.productFormItems = response.results;
          }
        },
      );
  }
  /* To close dialog popup */
  public onDialogClose(): void {
    this.dialogFlag = false;
  }
  /* To Open dialog popup */
  public open(i?: number): void {
    this.addedFieldIndex = i;
    this.dialogFlag = true;
    this.gettingClassificationDetails();
  }

  /* To patch selected row item to the input text */
  selectedRowData(data: any): void {
    if (this.addedFieldIndex >= 0) {
       this.controlValues.splice(this.addedFieldIndex, 1, data.descr);
       this.classificationForm.controls.newclassification.patchValue(this.controlValues);
       this.addedFieldIndex = undefined;
    } else {
      this.dataFromChild = data.descr;
      this.classificationForm.controls.classification.patchValue(data.descr);

    }

    this.dialogFlag = false;
  }

}
