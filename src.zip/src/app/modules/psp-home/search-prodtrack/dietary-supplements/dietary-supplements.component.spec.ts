import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DietarySupplementsComponent } from './dietary-supplements.component';

describe('DietarySupplementsComponent', () => {
  let component: DietarySupplementsComponent;
  let fixture: ComponentFixture<DietarySupplementsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DietarySupplementsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DietarySupplementsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
