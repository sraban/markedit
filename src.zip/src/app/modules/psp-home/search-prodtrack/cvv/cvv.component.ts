import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { PanelBarItemModel } from '@progress/kendo-angular-layout';
import { FormBuilder, FormGroup } from '@angular/forms';
import { forkJoin } from 'rxjs';
import { PspBaseService } from '../../services/psp-base.service';
import { DropDownFilterSettings } from '@progress/kendo-angular-dropdowns';

@Component({
  selector: 'app-cvv',
  templateUrl: './cvv.component.html',
  styleUrls: ['./cvv.component.scss']
})
export class CvvComponent implements OnInit {
  cvvForm!: FormGroup;
  pbCategoryList: any = [];
  productFormList: any = [];
  webCategorylist: any = [];
  gfCategoryList: any = [];
  logoMarksList: any = [];
  ngpRiskList: any = [];
  gfComplianceList: any = [];
  ngpComplianceList: any = [];

  @Output() searchCvvForm = new EventEmitter();
  constructor(private formBuilder: FormBuilder, private pspBaseService: PspBaseService) { }

  public items: Array<PanelBarItemModel> = [
    { title: 'CVV', content: 'content', expanded: false } as PanelBarItemModel,
];
public filterSettings: DropDownFilterSettings = {
  caseSensitive: false,
  operator: 'startsWith',
};
  ngOnInit(): void {
    this.cvvForm = this.formBuilder.group({
      brandName: [''],
      plantBased: [''],
      weblistCategory: [''],
      logoMarks: [''],
      gfCategory: [''],
      pbCategory: [''],
      productForm: [''],
      ngpRiskLevel: [''],
      gfComplianceDoc: [''],
      ngpComplianceDoc: ['']
  });
    this.cvvForm.valueChanges.subscribe((res) => {
    this.searchCvvForm.emit(this.cvvForm.value);
  });

  // clear all function
    this.pspBaseService.resetForm.subscribe((data) => {
    if (data){
      this.cvvForm.reset();
    }
  });

  // CVV Dropdown List
  // tslint:disable-next-line:align
    const pbUrl = this.pspBaseService.getDropdownAPI('dcc/CvvMaterialInfoController/getCategoryType', {});
    const productReq = {VALUE_SET_NAME: 'PT_CVV_PROD_FORM'};
    const productFormUrl = this.pspBaseService.getDropdownAPI('lookupNames', productReq);
    const webCategoryUrl = this.pspBaseService.getDropdownAPI('dcc/CvvMaterialInfoController/getWebListCategoryType', {});
    const gfCategoryUrl = this.pspBaseService.getDropdownAPI('dcc/CvvMaterialInfoController/getGFCategoryType', {});
    const logoReq = {VALUE_SET_NAME: 'PT_LOGOS_AND_MARKS'};
    const logoMarksUrl = this.pspBaseService.getDropdownAPI('lookupNames', logoReq);
    const ngpRiskReq = {VALUE_SET_NAME: 'NGP_PI_RISK_LEVEL'};
    const ngpRiskUrl = this.pspBaseService.getDropdownAPI('lookupNames', ngpRiskReq);
    const gfComplianceReq = {VALUE_SET_NAME: 'GF_COMPLIANCE_EVIDENCE'};
    const gfComplianceUrl = this.pspBaseService.getDropdownAPI('lookupNames', gfComplianceReq);
    const ngpComplianceReq = {VALUE_SET_NAME: 'NGP_EVIDENCE_COMPLIANCE'};
    const ngpComplianceUrl = this.pspBaseService.getDropdownAPI('lookupNames', ngpComplianceReq);

  // tslint:disable-next-line:align
  forkJoin([pbUrl, productFormUrl, webCategoryUrl, gfCategoryUrl, logoMarksUrl,
            ngpRiskUrl, gfComplianceUrl, ngpComplianceUrl]).subscribe((response: any) => {
      this.pbCategoryList = response[0].results;
      this.productFormList = response[1].results;
      this.webCategorylist = response[2].results;
      this.gfCategoryList = response[3].results;
      this.logoMarksList = response[4].results;
      this.ngpRiskList = response[5].results;
      this.gfComplianceList = response[6].results;
      this.ngpComplianceList = response[7].results;
  });
 }
 // tslint:disable-next-line:typedef
 get f() {
   return this.cvvForm.controls;
 }

}
