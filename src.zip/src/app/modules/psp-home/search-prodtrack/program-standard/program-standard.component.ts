import { Component, OnInit, ViewEncapsulation, ViewChild, Output, EventEmitter } from '@angular/core';
import { PanelBarItemModel } from '@progress/kendo-angular-layout';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { TextBoxComponent } from '@progress/kendo-angular-inputs';
import { PspBaseService } from '../../services/psp-base.service';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { DropDownFilterSettings } from '@progress/kendo-angular-dropdowns';

@Component({
  selector: 'app-program-standard',
  templateUrl: './program-standard.component.html',
  styleUrls: ['./program-standard.component.scss']
})
export class ProgramStandardComponent implements OnInit {
  public listItems: any;
  public opened = false;
  lookUpDialogFlag = false;
  result!: string;
  dialogFlag = false;
  lookUpGridData: any;
  lookUpHeader: any = [];
  programDataFromChild: any;
  titleLabel = 'Select Standard';
  pageable = {
    pageable: true,
    pageSize: 25,
  };
  height = 420;
  private isActive = new Subject();
  programStandard!: FormGroup;
  public items: Array<PanelBarItemModel> = [
    { title: 'Program & Standard', content: 'content', expanded: false } as PanelBarItemModel,
  ];
  public filterSettings: DropDownFilterSettings = {
    caseSensitive: false,
    operator: 'startsWith',
  };

  @Output() searchProgramStandardForm = new EventEmitter();
  constructor(private pspBaseService: PspBaseService, private formBuilder: FormBuilder) { }
  ngOnInit(): void {
    this.gettingsaveProgramStandard();
    this.gettingProgramNameDropdown();
    this.lookUpHeader = [
      {
        field: 'name',
        header_title: 'Name',
        width: 200,
        type: 'input_text'
      },
    ];
    this.programStandard = this.formBuilder.group({
      program: ['', Validators.required],
      standardProgram: ['', Validators.required],
      accManager: ['', Validators.required],
    });
    this.programStandard.valueChanges.subscribe((res) => {
      this.searchProgramStandardForm.emit(this.programStandard.value);
    });
    // clear all function
    this.pspBaseService.resetForm.subscribe((data) => {
      if (data) {
        this.programStandard.reset();
      }
    });
  }
  public gettingsaveProgramStandard(): any {
    const reqObj = {};
    this.pspBaseService
      .saveProgramStandard(reqObj)
      .pipe(takeUntil(this.isActive))
      .subscribe(
        (response: any) => {
          if (response.status === 'SUCCESS') {
            this.lookUpGridData = response.results;
          }
        },
        (err: any) => { }
      );
  }
  public openWindow(event: any): void {
    const name = event.target.closest('tr').cells[0].innerText;
    if (name && !(event.target.closest('thead') )) {
      this.programStandard.controls.program.patchValue(name);
      this.onDialogClose();
    }
  }
  public clearForm(): void {
    this.programStandard.reset();
  }
  public gettingProgramNameDropdown(): any {
    const reqObj = {};
    this.pspBaseService.getProgramNameDropdown(reqObj).pipe(takeUntil(this.isActive)).subscribe(
      (response: any) => {
        if (response.status === 'SUCCESS') {
          this.listItems = response.results;
        }
      },
      (err: any) => {
      }
    );
  }
  public onDialogClose(): void {
    this.dialogFlag = false;
  }
  public open(): void {
    this.dialogFlag = true;
  }

}


