import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProgramStandardComponent } from './program-standard.component';

describe('ProgramStandardComponent', () => {
  let component: ProgramStandardComponent;
  let fixture: ComponentFixture<ProgramStandardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProgramStandardComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ProgramStandardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
