import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BrakeFrictionComponent } from './brake-friction.component';

describe('BrakeFrictionComponent', () => {
  let component: BrakeFrictionComponent;
  let fixture: ComponentFixture<BrakeFrictionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BrakeFrictionComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BrakeFrictionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
