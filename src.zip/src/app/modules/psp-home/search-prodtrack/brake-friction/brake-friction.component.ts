import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { PanelBarItemModel } from '@progress/kendo-angular-layout';
import { takeUntil } from 'rxjs/operators';
import { Subject } from 'rxjs';
import { PspBaseService } from '../../services/psp-base.service';
import { FormatSettings } from '@progress/kendo-angular-dateinputs';

@Component({
  selector: 'app-brake-friction',
  templateUrl: './brake-friction.component.html',
  styleUrls: ['./brake-friction.component.scss']
})
export class BrakeFrictionComponent implements OnInit {
  brakeFrictionForm!: FormGroup;
  public listItems: any;
  private isActive = new Subject();
  listItems1: any;
  productFormItems: any;
  public format: FormatSettings = {
    displayFormat: 'dd/MM/yyyy',
    inputFormat: 'dd/MM/yyyy',
  };
  public value: Date = new Date(2019, 5, 1);
  
  @Output() searchBrakeFrictionForm = new EventEmitter();
  constructor(private formBuilder: FormBuilder, private pspBaseService: PspBaseService) { }

  public items: Array<PanelBarItemModel> = [
    { title: 'Brake Friction Material', content: 'content', expanded: false } as PanelBarItemModel,
];

public defaultItem: any = {
  DATA_VALUE: 'please select',
  DISPLAY_VALUE: 'please select',
  STATUS: null,
  VALUE_SET_NAME: null
};

  ngOnInit(): void {
    this.brakeFrictionForm = this.formBuilder.group({
      complianceLevel: [''],
      vehicleUsage: [''],
      testReport: [''],
      testReportFromDate: [''],
      testReportToDate: [''],
      nextReviewFromDate: [''],
      nextReviewToDate: [''],
  });

    this.brakeFrictionForm.valueChanges.subscribe((res) => {
    this.searchBrakeFrictionForm.emit(this.brakeFrictionForm.value);
  });

  // clear all function
    this.pspBaseService.resetForm.subscribe((data) => {
    if (data){
      this.brakeFrictionForm.reset();
    }
  });

    this.gettingComplianceLavelDropdown();
    this.gettingVehicleUsageDropDown();
 }

 // tslint:disable-next-line:typedef
 public gettingComplianceLavelDropdown() {
  const reqObj = {VALUE_SET_NAME: 'PT_COMPLIANCE_LEVEL'};

  this.pspBaseService.getComplianceLavelDropdown(reqObj).subscribe(
    (response: any) => {
      if (response.status === 'SUCCESS') {
       this.listItems = response.results;
      }
    },
    (err: any) => {
      }
    );
 }
    // tslint:disable-next-line:typedef
    public gettingVehicleUsageDropDown() {
      const reqObj = {VALUE_SET_NAME: 'PT_VEHICLE_USAGE'};

      this.pspBaseService.getVehicleUsageDropdown(reqObj).pipe(takeUntil(this.isActive)).subscribe(
        (response: any) => {
          if (response.status === 'SUCCESS') {
           this.listItems1 = response.results;

          }
        },
        (err: any) => {
          }
        );

 }

}
