import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { PanelBarItemModel } from '@progress/kendo-angular-layout';
import { FormBuilder, FormGroup, Validators, FormArray, Form } from '@angular/forms';
import { PspBaseService } from '../../services/psp-base.service';
import { forkJoin } from 'rxjs';
import { DropDownFilterSettings } from '@progress/kendo-angular-dropdowns';


@Component({
  selector: 'app-facility',
  templateUrl: './facility.component.html',
  styleUrls: ['./facility.component.scss']
})
export class FacilityComponent implements OnInit {
  facilityForm!: FormGroup;
  listItems: any = [];
  noteItem: any = [];
  public loader: any;
  public notify: any;

  @Output() searchFacilityForm = new EventEmitter();
  constructor(private formBuilder: FormBuilder, private pspBaseService: PspBaseService) { }

  public get newfacilityNumbers(): any{
   return this.facilityForm.get('newfacilityNumber') as FormArray;
 }


  public items: Array<PanelBarItemModel> = [
    { title: 'Facility', content: 'content', expanded: false } as PanelBarItemModel,
  ];

  public filterSettings: DropDownFilterSettings = {
    caseSensitive: false,
    operator: 'startsWith',
  };


  ngOnInit(): void {
    this.facilityForm = this.formBuilder.group({
      facilitiesStandardNoteType: [''],
      facilitiesStandardNote: [''],
      facilityNumber: [''],
      facilityName: [''],
      facilityCountry: [''],
      newfacilityNumber : this.formBuilder.array([])
  });
    this.searchFacilityForm.emit(this.facilityForm.value);
    this.facilityForm.valueChanges.subscribe((res) => {
    this.searchFacilityForm.emit(this.facilityForm.value);
  });

    // clear all function
    this.pspBaseService.resetForm.subscribe((data) => {
    if (data){
      this.facilityForm.reset();
      (this.facilityForm.get('newfacilityNumber') as FormArray).clear();
    }
  });

    // API integration Facility Dropdown List
    const facilityCountry = this.pspBaseService.getDropdownAPI( 'dcc/searchTool/facilityCountryDropDown', {});
    const noteRequest = {VALUE_SET_NAME: 'PT_NOTE_TYPE'};
    const facilitiesStandardNote = this.pspBaseService.getDropdownAPI( 'lookupNames', noteRequest);

    forkJoin([facilityCountry, facilitiesStandardNote]).subscribe((data: any) => {
      this.listItems = data[0].results;
      this.noteItem = data[1].results;
      this.listItems.unshift({
        APPFUPD: '', code: '', descr: '', name: '', dcc_prefix: '', default_Item_Type: '', al: '', program: ''});
      this.noteItem.unshift({VALUE_SET_NAME: 'ALL', STATUS: 'ALL', DATA_VALUE: 'ALL', DISPLAY_VALUE: 'ALL'});
    },
    (err: any) => {
      this.loader = false;
      this.notify =
       {
         style : 'error',
        content : err.statusText
       };

      }
    );

 }

 // adding and removing input fields
  public addNewFacilityField(): any{
    if (this.newfacilityNumbers.length <= 3)
    {
      this.newfacilityNumbers.push(this.formBuilder.control(''));
    }
 }

  public removeFacilityNUmber(i: number): any{
   this.newfacilityNumbers.removeAt(i);
 }


}
