import { Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormGroup, FormArray, FormControl } from '@angular/forms';
import { PspBaseService } from '../services/psp-base.service';
import { forkJoin } from 'rxjs';
import { DataService } from '../../../common/data.service';
import { DatePipe } from '@angular/common';
import { GridComponent } from '@progress/kendo-angular-grid';
import { TranslateService } from '@ngx-translate/core';
import { DropDownFilterSettings } from '@progress/kendo-angular-dropdowns';
import { PdfPrinterDirective } from 'src/app/app-shared/directives/pdf-printer.directive';


@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.scss'],
  encapsulation: ViewEncapsulation.None
})

export class SearchComponent implements OnInit {

  constructor(private formBuilder: FormBuilder, private pspBaseService: PspBaseService, private dataService: DataService,
              private datePipe: DatePipe, private translate: TranslateService, public printer: PdfPrinterDirective) { }

  public get newCorporateNumbers(): any{
    return this.searchForm.get('newCorporateNumber') as FormArray;
  }

  public get newTradeNames(): any{
    return this.searchForm.get('newTradeName') as FormArray;
  }

  public get newCorporateNames(): any{
    return this.searchForm.get('newCorporateName') as FormArray;
  }
  searchForm!: FormGroup;
  statusItems: any = [];
  prefixItems: any = [];
  facilityFormData: any;
  chemicalFormData: any;
  brakeFrictionFormData: any;
  cvvFormData: any;
  classificationFormData: any;
  foodFormData: any;
  programStandardData: any;
  waterAssemblyFormData: any;
  public defaultPrefixValue = [{ dcc_prefix: 'ALL', descr: 'ALL' }];
  public defaultStatusValue = [{ DATA_VALUE: 'ALL', DISPLAY_VALUE: 'ALL' }];
  public reqObj: any = [];
  public selectedVal: any ;
  public tableData: any;
  public gridExcelHeaders: any;
  public showTable = false;
  public loader: any;
  public notify: any;
  public totalResultsCount: any;
  exportData: any;
  public exporttableData: any;
  qparam: any;
  pageable = {
    pageable: {
      searchPage: false,
      info: true,
      type: 'numeric',
      previousNext: true,
      position: 'both',
      pageSizes: 25
    },
    pageSize: 25,
  };
  searchTranslate: any;
  pageIndex: any;
  @ViewChild ('grid', {static: false}) grid: any;


  public filterSettings: DropDownFilterSettings = {
    caseSensitive: false,
    operator: 'startsWith',
  };
    public exportDataAs(val: any): void {
      this.loader = true;
      this.qparam.page_size = this.totalResultsCount;
      this.qparam.start_index = 1;
      this.dataService.getFilteredData(this.qparam).subscribe(( data: any ) => {
        this.exporttableData = data.results;
        if (val === 'excel'){
          setTimeout(() => {
            this.openFile(this.grid);
           }, 1000);
        }else{
         this.printer.print(this.exporttableData, 'Search Results', this.gridExcelHeaders);
        }

        this.loader = false;
        if (this.tableData.length === 0) {
          this.notify =
         {
           style : 'error',
          content : this.searchTranslate.noRecordsFoundWithTheSearchcriteria,
         };
        }
      },
      (err: any) => {
        this.loader = false;
        this.notify =
         {
           style : 'error',
          content : err.statusText
         };

        });
  }

  public statusValueChange(value: any): void {

    if (this.defaultStatusValue[0]?.DATA_VALUE === 'ALL' && this.defaultStatusValue.length > 1 ){
     this.defaultStatusValue.shift();
     this.searchForm.get('dccStatus')?.setValue(this.defaultStatusValue);
    } else if (this.defaultStatusValue.length > 1 && value[value.length - 1 ].DATA_VALUE === 'ALL'){
          const defaultVal = [{ DATA_VALUE: 'ALL', DISPLAY_VALUE: 'ALL' }];
          this.searchForm.get('dccStatus')?.setValue(defaultVal);
    }
  }


  public prefixValueChange(value: any): void {

    if (this.defaultPrefixValue[0]?.dcc_prefix === 'ALL' && this.defaultPrefixValue.length > 1 ){
     this.defaultPrefixValue.shift();
     this.searchForm.get('prefix')?.setValue(this.defaultPrefixValue);
    } else if (this.defaultPrefixValue.length > 1 && value[value.length - 1 ].dcc_prefix === 'ALL'){
          const defaultVal = [{ dcc_prefix: 'ALL', descr: 'ALL' }];
          this.searchForm.get('prefix')?.setValue(defaultVal);
    }
  }

  resetForms(): any{
    this.pspBaseService.resetData();
    this.searchForm.reset();
    this.tableData = [];
    (this.searchForm.get('newCorporateNumber') as FormArray).clear();
    (this.searchForm.get('newTradeName') as FormArray).clear();
    (this.searchForm.get('newCorporateName') as FormArray).clear();
    this.searchForm.get('dccStatus')?.patchValue([{ DATA_VALUE: 'All', DISPLAY_VALUE: 'ALL' }]);
    this.searchForm.get('prefix')?.patchValue([{ dcc_prefix: 'ALL', descr: 'ALL' }]);
    this.searchForm.get('product')?.patchValue(true);
    this.searchForm.get('nonProduct')?.patchValue(true);
    this.searchForm.get('searchDcc')?.patchValue(true);
    this.searchForm.get('searchFormulation')?.patchValue(false);
    this.notify = {};
  }

  ngOnInit(): void {
    this.searchForm = this.formBuilder.group({
      product: new FormControl(true),
      nonProduct: new FormControl(true),
      searchDcc: new FormControl(true),
      searchFormulation: new FormControl(false),
      dccStatus: [''],
      dccNumber: [''],
      itemDescription: [''],
      corporateNumber: [''],
      formulator: [''],
      tradeName: [''],
      prefix: [''],
      corporateName: [''],
      newCorporateNumber : this.formBuilder.array([]),
      newTradeName : this.formBuilder.array([]),
      newCorporateName : this.formBuilder.array([])
  });

    this.gridExcelHeaders = [
        {field: 'dcc', header_title: 'DCC#', width: 90, type: 'link' },
        {field: 'STD_CODE', header_title: 'Standard', width: 100,  type: 'input_text'},
        {field: 'facility', header_title: 'Facility#', width: 100, type: 'input_text' },
        {field: 'TRADE_NAME', header_title: 'Trade Name', width: 120,  type: 'input_text'},
        {field: 'SUPPLIER_NAME', header_title: 'Supplier Name', width: 150, type: 'input_text' },
        {field: 'FORMULATOR_NAME', header_title: 'Formulator', width: 150,  type: 'input_text'},
        {field: 'co_no', header_title: 'CO#', width: 90,  type: 'input_text'},
        {field: 'co_name', header_title: 'CO Name', width: 120,  type: 'input_text'},
        {field: 'facility_loc', header_title: 'Facility Location', width: 150, type: 'input_text' },
        {field: 'DCC_STATUS', header_title: 'DCC Status', width: 100,  type: 'input_text'},
        {field: 'PRODUCT_STATUS', header_title: 'Product Status', width: 120,  type: 'input_text'},
      ];

    this.translate.get('search').subscribe( (text: string) => {
        this.searchTranslate = text;
      });


    // API integration Search Dropdown List
    const dccStatusRequest = {VALUE_SET_NAME: 'PT_DCC_STATUS'};
    const dccStatus = this.pspBaseService.getDropdownAPI( 'lookupNames', dccStatusRequest);
    const prefix = this.pspBaseService.getDropdownAPI( 'dcc/nonProductPrefixLookup', {});

    forkJoin([dccStatus, prefix]).subscribe((data: any) => {
    this.statusItems = data[0].results;
    this.prefixItems  = data[1].results;
    this.prefixItems.unshift({dcc_prefix: 'ALL', descr: 'ALL', default_item_type: 'ALL', last_nbr: 'ALL'});
    this.statusItems.unshift({VALUE_SET_NAME: 'ALL', STATUS: 'ALL', DATA_VALUE: 'ALL', DISPLAY_VALUE: 'ALL'});
 });

}

// Data from child components

public searchFacilityForm(formValue: any): any{
  this.facilityFormData = formValue;
}

public searchChemicalForm(formValue: any): any{
  this.chemicalFormData = formValue;
}

public searchBrakeFrictionForm(formValue: any): any{
  this.brakeFrictionFormData = formValue;
}

public searchCvvForm(formValue: any): any{
  this.cvvFormData = formValue;
}

public searchDietarySupplementsForm(formValue: any): any{
  this.classificationFormData = formValue;
}

public searchFoodForm(formValue: any): any{
  this.foodFormData = formValue;
}

public searchProgramStandardForm(formValue: any): any{
  this.programStandardData = formValue;
}

public searchWaterAssemblyForm(formValue: any): any{
  this.waterAssemblyFormData = formValue;
}
filterGridData(val: any){
this.qparam.dcc_filter= val.dcc_filter ? val.dcc_filter:'';
this.qparam.standard_filter= val.standard_filter ? val.standard_filter:'';
this.qparam.facility_filter=  val.facility_filter?val.facility_filter:'';
this.qparam.trade_name_filter= val.trade_name_filter ? val.trade_name_filter:'';
this.qparam.supplier_filter= val.supplier_filter ? val.supplier_filter:'';
this.qparam.formulator_filter= val.formulator_filter ? val.formulator_filter: '';
this.qparam.co_filter= val.co_filter ? val.co_filter: '';
this.qparam.co_name_filter= val.co_name_filter ? val.co_name_filter:'';
this.qparam.facility_location_filter= val.facility_location_filter ? val.facility_location_filter:'';
this.qparam.dcc_status_filter= val.dcc_status_filter ? val.dcc_status_filter:'';
this.qparam.product_status_filter= val.product_status_filter ? val.product_status_filter:'';
this.qparam.start_index = 1

this.loader = true;
this.dataService.getFilteredData(this.qparam).subscribe(( data: any ) => {
  if (data.status === 'SUCCESS') {
  this.tableData = data;
  this.totalResultsCount = data.count;
  this.loader = false;
  if (this.tableData.results.length === 0) {
    this.notify = {
     style : 'info',
    content : this.searchTranslate.noRecordsFoundWithTheSearchcriteria,
   };
  }
}
else {
  this.notify = {
    content: data.results[0].message,
    style: 'error'
  };
  this.loader = false;
}
},
(err: any) => {
  this.loader = false;
  this.notify =
   {
     style : 'error',
    content : err.statusText
   };

  });

}
public totalPageSize(val: any): any{
  this.qparam.page_size = val.pageSize;
  this.qparam.start_index=val.pageNumber
  this.loader = true;
  this.dataService.getFilteredData(this.qparam).subscribe(( data: any ) => {
    if (data.status === 'SUCCESS') {
    this.tableData = data;
    this.totalResultsCount = data.count;
    this.loader = false;
    if (this.tableData.length === 0) {
      this.notify = {
       style : 'error',
      content : this.searchTranslate.noRecordsFoundWithTheSearchcriteria,
     };
    }
  }
  else {
    this.notify = {
      content: data.results[0].message,
      style: 'error'
    };
    this.loader = false;
  }
  },
  (err: any) => {
    this.loader = false;
    this.notify =
     {
       style : 'error',
      content : err.statusText
     };

    });
}
// adding and removing input fields
public addNewCorpField(): any{
  if (this.newCorporateNumbers.length <= 3)
  {
    this.newCorporateNumbers.push(this.formBuilder.control(''));
  }
  else
  { // Empty on purpose
  }
  }

 public removeCorporateNUmber(i: number): any{
  this.newCorporateNumbers.removeAt(i);
}

public addNewTradeName(): any{
  if (this.newTradeNames.length <= 3)
  {
  this.newTradeNames.push(this.formBuilder.control(''));
  }
}

 public removeTradeName(i: number): any{
  this.newTradeNames.removeAt(i);
}

public addNewCorpName(): any{
  if (this.newCorporateNames.length <= 3)
  {
  this.newCorporateNames.push(this.formBuilder.control(''));
  }
  else
  { // Empty on purpose
  }

}

 public removeCorpName(i: number): any{
  this.newCorporateNames.removeAt(i);
}
public valueParams(){ // Empty on purpose

}
// Request Payload for search
public applyFilter(): any {
  const WaterAssemblyCheckValues = [this.waterAssemblyFormData?.assemblyCheck === true ? 'A' : '',
                                    this.waterAssemblyFormData?.materialCheck === true ? 'M' : '' ,
                                    this.waterAssemblyFormData?.ingrediantCheck === true ? 'I' : ''].filter(x => x);
  this.loader = true;
  this.showTable = true;
  this.qparam = {
    dcc_filter: '',
    standard_filter: '',
    facility_filter:  '',
    trade_name_filter: '',
    supplier_filter: '',
    formulator_filter: '',
    co_filter: '',
    co_name_filter: '',
    facility_location_filter: '',
    dcc_status_filter: '',
    product_status_filter: '',
    PI_PROD_FLG: this.searchForm.get('product')?.value === true ? 'Y' : 'N',
    PI_NON_PROD_FLG: this.searchForm.get('nonProduct')?.value === true ? 'Y' : 'N',
    PI_SEARCH_DCC_FLG: this.searchForm.get('searchDcc')?.value === true ? 'Y' : 'N',
    PI_SEARCH_WPL_FORM_FLG: this.searchForm.get('searchFormulation')?.value === true ? 'Y' : 'N',
    PI_DCC_NO: this.searchForm.get('dccNumber')?.value,
    PI_FORMULATOR_NAME: this.searchForm.get('formulator')?.value,
    PI_DCC_STAT: this.searchForm.get('dccStatus')?.value.map((data: any) =>  data.DATA_VALUE ),
    PI_PREFIX: this.searchForm.get('prefix')?.value.map((data: any) =>  data.dcc_prefix ),
    PI_ITM_DESC: this.searchForm.get('itemDescription')?.value,
    PI_TRADE_NM:
      ([].concat(this.searchForm?.get('tradeName')?.value , this.searchForm?.get('newTradeName')?.value).filter( x => x)),
    PI_F_ND_S_NT: this.facilityFormData.facilitiesStandardNote ? this.facilityFormData.facilitiesStandardNote :  '' ,
    PI_F_ND_S_NT_TYP: this.facilityFormData?.facilitiesStandardNoteType ? this.facilityFormData.facilitiesStandardNoteType :  [] ,
    pi_standard: this.programStandardData?.program ? this.programStandardData?.program : '',
    pi_programe: this.programStandardData?.standardProgram ? this.programStandardData?.standardProgram : [],
    pi_prog_rep: this.programStandardData?.accManager ? this.programStandardData?.accManager : '',
    pi_select: WaterAssemblyCheckValues,
    pi_part_num: this.waterAssemblyFormData?.part ? this.waterAssemblyFormData?.part: '',
    pi_surf_area1: this.waterAssemblyFormData?.surfaceAreaGSED,
    pi_surf_area2: this.waterAssemblyFormData?.surfaceAreaText ? this.waterAssemblyFormData?.surfaceAreaText: '',
    pi_watr_cntct_temp: this.waterAssemblyFormData?.waterContactTemp ? this.waterAssemblyFormData?.waterContactTemp: '',
    pi_function: this.waterAssemblyFormData?.function ? this.waterAssemblyFormData?.function: '',
    pi_sec_or_cat: this.waterAssemblyFormData?.selectionCategory ? this.waterAssemblyFormData?.selectionCategory: '',
    pi_end_use: this.waterAssemblyFormData?.endUse ? this.waterAssemblyFormData?.endUse: '',
    pi_mat_type: this.waterAssemblyFormData?.materialType ? this.waterAssemblyFormData?.materialType: '',
    pi_max_use1: this.waterAssemblyFormData?.maxUseLevel,
    pi_max_use2: this.waterAssemblyFormData?.maxUseLevelText ? this.waterAssemblyFormData?.maxUseLevelText: '',
    pi_repckgr_blndr_dilutr: this.waterAssemblyFormData?.repackagerBlender ? this.waterAssemblyFormData.repackagerBlender :[],
    pi_replacement_element: this.waterAssemblyFormData?.replacementElement ? this.waterAssemblyFormData?.replacementElement: '',
    pi_capacity: this.waterAssemblyFormData?.capacityText ? this.waterAssemblyFormData?.capacityText: '',
    pi_capacity1: this.waterAssemblyFormData?.capacitydrop,
    pi_capacity_units: this.waterAssemblyFormData?.capacityDrop1,
    pi_max_rated1: this.waterAssemblyFormData?.maxratedPressureDrop,
    pi_max_rated: this.waterAssemblyFormData?.maxratedPressureText ? this.waterAssemblyFormData?.maxratedPressureText: '',
    pi_max_rated_units: this.waterAssemblyFormData?.maxratedPressureDrop1,
    pi_reduction_claim:
      ([].concat(this.waterAssemblyFormData?.reductionClaim , this.waterAssemblyFormData?.newclassification).filter( x => x)),
    pi_system_type: this.waterAssemblyFormData?.systemType ? this.waterAssemblyFormData?.systemType: '',
    pi_classification:
      ([].concat(this.classificationFormData?.classification , this.classificationFormData?.newclassification).filter( x => x)),
    pi_ds_prod_type: this.classificationFormData?.dsProductType ? this.classificationFormData?.dsProductType: '',
    pi_form: this.classificationFormData?.productForm ? this.classificationFormData?.productForm: '',
    raw_material_name: this.classificationFormData?.rawMaterialName ? this.classificationFormData?.rawMaterialName: '',
    raw_material_number: this.classificationFormData?.rawMaterialNumber ? this.classificationFormData?.rawMaterialNumber: '',
    label_claim_search: this.classificationFormData?.labelClaim ? this.classificationFormData?.labelClaim: '',
    additional_claims_on_label: this.classificationFormData?.additionalClaimsonLabel ? this.classificationFormData?.additionalClaimsonLabel: '',
    pi_cas: this.chemicalFormData?.casNumber ? this.chemicalFormData?.casNumber: '' ,
    pi_chem_name: this.waterAssemblyFormData?.productChemicalName ? this.waterAssemblyFormData?.productChemicalName: '',
    pi_chemical_name: this.chemicalFormData?.chemicalName ? this.chemicalFormData?.chemicalName: '',
    percentage: this.chemicalFormData?.percentageDropdown,
    percentage_per: this.chemicalFormData?.percentageText ? this.chemicalFormData?.percentageText: '',
    pi_co_no:
      ([].concat(this.searchForm?.get('corporateNumber')?.value , this.searchForm?.get('newCorporateNumber')?.value).filter( x => x)),
    pi_plant_no:
      ([].concat(this.facilityFormData.facilityNumber , this.facilityFormData.newfacilityNumber).filter( x => x)),
    pi_plant_name: this.facilityFormData?.facilityName ? this.facilityFormData?.facilityName: '',
    pi_plant_country: this.facilityFormData?.facilityCountry ? this.facilityFormData?.facilityCountry : '' ,
    pi_supplier_name:
      ([].concat(this.searchForm?.get('corporateName')?.value , this.searchForm?.get('newCorporateName')?.value).filter( x => x)),
    pi_size: this.waterAssemblyFormData?.size,
    pi_size_amount: this.waterAssemblyFormData?.sizeText ? this.waterAssemblyFormData?.sizeText: '',
    pi_size_unit: this.waterAssemblyFormData?.sizeDrop2 ? this.waterAssemblyFormData?.sizeDrop2: '',
    part_description: this.foodFormData?.partDescription ? this.foodFormData?.partDescription: '',
    contact_area: this.foodFormData?.contactEqual,
    surface_area_unit: this.waterAssemblyFormData?.surfaceAreaDrop2,
    contact_area_amt: this.foodFormData?.contactArea ? this.foodFormData?.contactArea: '',
    contact_area_unit: this.foodFormData?.contactUnit,
    contact_zone: this.foodFormData?.contactZone ? this.foodFormData?.contactZone: '',
    restrictions: this.foodFormData?.restrictions ? this.foodFormData?.restrictions: '',
    food_contact_material_type: this.foodFormData?.foodContactMaterialType ? this.foodFormData?.foodContactMaterialType: '',
    food_contact_type:
      ([].concat(this.foodFormData?.foodContactType , this.foodFormData?.newFoodContactType).filter( x => x)),
    food_contact_temperature: this.foodFormData?.FoodContact,
    food_contact_temperature_amt: this.foodFormData?.foodContactText ? this.foodFormData?.foodContactText: '',
    food_contact_temperature_unit: this.foodFormData?.FoodContactTemp,
    resinTypes: this.foodFormData?.resinTypes ? this.foodFormData?.resinTypes: '',
    pigment_let_down_ratio: this.foodFormData?.pigmentLetDownRatio ? this.foodFormData?.pigmentLetDownRatio: '',
    ingredient_supplier: this.foodFormData?.ingredientSupplier ? this.foodFormData?.ingredientSupplier: '',
    regulatory_ref: this.foodFormData?.regulatoryRef ? this.foodFormData?.regulatoryRef: '',
    non_food_category:
      ([].concat(this.foodFormData?.nonfoodCategory , this.foodFormData?.newNonfoodCategoryType).filter( x => x)),
    filter_column: '1',
    filter_order: 'asc',
    compliance_level: this.brakeFrictionFormData?.complianceLevel ? this.brakeFrictionFormData?.complianceLevel: '',
    vehicle_usage: this.brakeFrictionFormData?.vehicleUsage ? this.brakeFrictionFormData?.vehicleUsage: '',
    test_report_id: this.brakeFrictionFormData?.testReport ? this.brakeFrictionFormData?.testReport: '',
    test_report_from_date: this.datePipe.transform(this.brakeFrictionFormData?.testReportFromDate, 'yyyy-MM-dd'),
    test_report_to_date: this.datePipe.transform(this.brakeFrictionFormData?.testReportToDate, 'yyyy-MM-dd'),
    next_review_by_from_date: this.datePipe.transform(this.brakeFrictionFormData?.nextReviewFromDate, 'yyyy-MM-dd'),
    next_review_by_to_date: this.datePipe.transform(this.brakeFrictionFormData?.nextReviewToDate, 'yyyy-MM-dd'),
    brand_name: this.cvvFormData?.brandName ? this.cvvFormData.brandName: '',
    pb_category: this.cvvFormData?.pbCategory ? this.cvvFormData.pbCategory: [],
    total_plant_based: this.cvvFormData?.plantBased ? this.cvvFormData.plantBased:'',
    prod_form: this.cvvFormData?.productForm ? this.cvvFormData.productForm: [],
    ngp_pi_risk_level: this.cvvFormData?.ngpRiskLevel ? this.cvvFormData.ngpRiskLevel:[],
    web_list_category: this.cvvFormData?.weblistCategory ? this.cvvFormData.weblistCategory:[],
    gf_comp_doc: this.cvvFormData?.gfComplianceDoc ? this.cvvFormData.gfComplianceDoc:[],
    logos_and_marks: this.cvvFormData?.logoMarks ? this.cvvFormData.logoMarks:[],
    ngp_comp_doc: this.cvvFormData?.ngpComplianceDoc ? this.cvvFormData.ngpComplianceDoc:[],
    gf_category: this.cvvFormData?.gfCategory ? this.cvvFormData.gfCategory:[],
    conn_type_category: this.waterAssemblyFormData?.connectionTypeCategory ? this.waterAssemblyFormData.connectionTypeCategory: [],
    conn_type_details: this.waterAssemblyFormData?.connectionTypeDetails ? this.waterAssemblyFormData?.connectionTypeDetails: '',
    approval_number: this.waterAssemblyFormData?.approvalNumber ? this.waterAssemblyFormData?.approvalNumber: '',
    method_of_manufacturing: this.waterAssemblyFormData?.methodofManufacturing ? this.waterAssemblyFormData.methodofManufacturing: [],
    temperature: this.waterAssemblyFormData?.temperature ? this.waterAssemblyFormData?.temperature: '',
    shore_hardness: this.waterAssemblyFormData?.shoreHardness ? this.waterAssemblyFormData?.shoreHardness: '',
    start_index: 1,
    page_size: 25
  };
  this.dataService.getFilteredData(this.qparam).subscribe(( data: any ) => {
    if (data.status === 'SUCCESS') {
    this.tableData = data;
    this.notify = false;
    this.totalResultsCount = data.count;
    this.loader = false;
    
    if (this.tableData.results.length === 0) {
      this.notify = {
       style : 'info',
      content : this.searchTranslate.noRecordsFoundWithTheSearchcriteria,
     };
    }
  }
  else {
    this.notify = {
      content: data.results[0].message,
      style: 'error'
    };
    this.loader = false;
  }
  },
  (err: any) => { this.loader = false; 
        this.notify =
     {
       style : 'error',
      content : err.statusText
     };

    });
}
public openFile(grid: GridComponent ): any{
  grid.saveAsExcel();
  this.loader = false;

}

}
