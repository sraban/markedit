import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { PanelBarItemModel } from '@progress/kendo-angular-layout';
import { FormBuilder, FormGroup, FormControl, FormArray } from '@angular/forms';
import { PspBaseService } from '../../services/psp-base.service';
import { forkJoin, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';




@Component({
  selector: 'app-food-material',
  templateUrl: './food-material.component.html',
  styleUrls: ['./food-material.component.scss']
})
export class FoodMaterialComponent implements OnInit {
  private isActive = new Subject();

  foodForm!: FormGroup;
  contactEqual: any = [];
  allContactEqual: any = [];
  contactUnit: any = [];
  FoodContact: any = [];
  allFoodContact: any = [];
  FoodContactTemp: any = [];
  public loader: any;
  public notify: any;
  lookUpGridData: any;
  lookUpHeader: any = [];
  dialogFlag!: boolean;
  dataFromFoodContact: any;
  controlValues: any = [];
  fieldAdded!: boolean;
  addedFieldIndex: any;

  nonControlValues: any = [];
  nonFieldAdded!: boolean;
  nonAddedFieldIndex: any;



  lookUpZoneData: any;
  lookUpZone: any = [];
  dialogZone!: boolean;
  dataFromContactZone: any;

  lookUpResinTypes: any;
  lookUpResin: any = [];
  dialogResin!: boolean;
  dataFromResinTypes: any;

  lookUpMaterialType: any;
  lookUpMaterial: any = [];
  dialogMaterialType!: boolean;
  dataFromMaterialType: any;

  lookUpNonfoodType: any;
  lookUpNonfood: any = [];
  dialogNonfoodType!: boolean;
  dataFromNonfoodType: any;

  titleLabel = 'Select Food Contact Type';
  zoneTitle = 'Select Contact Zone';
  resinTitle = 'Select Resin Types';
  materialTypeTitle = 'Select Food Contact Material Type';
  nonfoodCategoryTitle = 'Select Nonfood Category';

  pageable = {
    pageable: true,
    pageSize: 25,
  };
  height = 420;


  public selectedValue = 'EQUAL_TO';
  public selectedUnit = 'SQIN';
  public selectedFoodValue = 'EQUAL_TO';
  public selectedTempValue = 'F';

  @Output() searchFoodForm = new EventEmitter();
  dataFromChild: any;
  constructor(private formBuilder: FormBuilder, private pspBaseService: PspBaseService) { }


public get newFoodContactTypes(): any{
  return this.foodForm.get('newFoodContactType') as FormArray;
}


public get newNonfoodCategoryTypes(): any{
  return this.foodForm.get('newNonfoodCategoryType') as FormArray;
}


  public items: Array<PanelBarItemModel> = [
    { title: 'Food Material / Nonfood Compounds', content: 'content', expanded: false } as PanelBarItemModel,
];

  ngOnInit(): void {
    this.lookUpHeader = [
      {
        field: 'descr',
        header_title: 'Description',
        width: 200,
        type: 'input_text'
      }
    ];
    this.lookUpZone = [
      {
          field: 'DISPLAY_VALUE',
          header_title: 'Display Value',
          width: 200,
          type: 'input_text'
      }
  ];
    this.lookUpResin = [
    {
        field: 'descr',
        header_title: 'Description',
        width: 200,
        type: 'input_text'
    }
];
    this.lookUpMaterial = [
    {
        field: 'descr',
        header_title: 'Description',
        width: 200,
        type: 'input_text'
    }
];
    this.lookUpNonfood = [
    {
        field: 'descr',
        header_title: 'Nonfood Category',
        width: 200,
        type: 'input_text'
    }
];

    this.foodForm = this.formBuilder.group({
      partDescription: [''],
      pigmentLetDownRatio: [''],
      foodContactType: [''],
      contactZone: [''],
      regulatoryRef: [''],
      resinTypes: [''],
      foodContactMaterialType: [''],
      contactEqual: [''],
      contactArea: [''],
      contactUnit: [''],
      ingredientSupplier: [''],
      FoodContact: [''],
      foodContactText: [''],
      FoodContactTemp: [''],
      restrictions: [''],
      nonfoodCategory: [''],
      newFoodContactType : this.formBuilder.array([]),
      newNonfoodCategoryType : this.formBuilder.array([])

    });
    this.foodForm.valueChanges.subscribe((res) => {
    this.searchFoodForm.emit(this.foodForm.value);
    });

    // clear all function
    this.pspBaseService.resetForm.subscribe((data) => {
      if (data){
        this.foodForm.reset();
        (this.foodForm.get('newFoodContactType') as FormArray).clear();
        (this.foodForm.get('newNonfoodCategoryType') as FormArray).clear();
        this.foodForm.get('contactEqual')?.patchValue('EQUAL_TO');
        this.foodForm.get('contactUnit')?.patchValue('SQIN');
        this.foodForm.get('FoodContact')?.patchValue('EQUAL_TO');
        this.foodForm.get('FoodContactTemp')?.patchValue('F');
      }
    });


      // Food Material Dropdown List
    const contactRequest = {VALUE_SET_NAME: 'PT_GRT_SML_EQL'};
    const ContactEqual = this.pspBaseService.getDropdownAPI('lookupNames', contactRequest);
    const contactUnitRequest = {VALUE_SET_NAME: 'PT_CONTACT_AREA_UNIT'};
    const ContactUnits = this.pspBaseService.getDropdownAPI('lookupNames', contactUnitRequest);
    const FoodAreaRequest = {VALUE_SET_NAME: 'PT_GRT_SML_EQL'};
    const FoodContactArea = this.pspBaseService.getDropdownAPI('lookupNames', FoodAreaRequest);
    const FoodTempRequest = {VALUE_SET_NAME: 'TEMPERATURE_UNIT'};
    const FoodTemperature = this.pspBaseService.getDropdownAPI('lookupNames', FoodTempRequest);

    forkJoin([ContactEqual, ContactUnits, FoodContactArea, FoodTemperature]).subscribe((response: any) => {
      this.contactEqual = response[0].results;
      this.allContactEqual = this.contactEqual.map(( res: any ) => {
        return {
          DATA_VALUE: res.DATA_VALUE ,
          DISPLAY_VALUE: res.DISPLAY_VALUE == null ? 'null' : res.DISPLAY_VALUE
        };
      });
      this.contactUnit = response[1].results;
      this.contactUnit.unshift({DATA_VALUE: ' ', DISPLAY_VALUE: ' '});
      this.FoodContact = response[2].results;
      this.allFoodContact = this.FoodContact.map(( res: any ) => {
        return {
          DATA_VALUE: res.DATA_VALUE ,
          DISPLAY_VALUE: res.DISPLAY_VALUE == null ? 'null' : res.DISPLAY_VALUE
        };
      });
      this.FoodContactTemp = response[3].results;
      this.FoodContactTemp.unshift({DATA_VALUE: ' ', DISPLAY_VALUE: ' '});
  },
  (err: any) => {
    this.loader = false;
    this.notify =
     {
       style : 'error',
      content : err.statusText
     };

    }
    );
}

     public gettingFoodContactType(): any {
      const reqObj = {};
      this.pspBaseService
        .getFoodContactType(reqObj)
        .pipe(takeUntil(this.isActive))
        .subscribe(
          (response: any) => {
            if (response.status === 'SUCCESS') {
              this.lookUpGridData = response.results;
            }
          },
          (err: any) => {}
        );
    }

    public gettingContactZone(): any {
      const reqObj = {
          VALUE_SET_NAME: 'PT_CONTACT_ZONE_TYPE',
          STATUS: 'A',
      };
      this.pspBaseService
          .getContactZone(reqObj)
          .pipe(takeUntil(this.isActive))
          .subscribe(
              (response: any) => {
                  if (response.status === 'SUCCESS') {
                      this.lookUpZoneData = response.results;
                  }
              },
              (err: any) => { }
          );
  }

      public gettingResinTypes(): any {
        const reqObj = {};
        this.pspBaseService
            .getResinTypes(reqObj)
            .pipe(takeUntil(this.isActive))
            .subscribe(
                (response: any) => {
                    if (response.status === 'SUCCESS') {
                        this.lookUpResinTypes = response.results;
                    }
                },
                (err: any) => { }
            );
    }

          public gettingMaterialType(): any {
        const reqObj = {};
        this.pspBaseService
            .getMaterialType(reqObj)
            .pipe(takeUntil(this.isActive))
            .subscribe(
                (response: any) => {
                    if (response.status === 'SUCCESS') {
                        this.lookUpMaterialType = response.results;
                    }
                },
                (err: any) => { }
            );
    }
           public gettingNonfoodCategory(): any {
        const reqObj = {};
        this.pspBaseService
            .getNonfoodCategory(reqObj)
            .pipe(takeUntil(this.isActive))
            .subscribe(
                (response: any) => {
                    if (response.status === 'SUCCESS') {
                        this.lookUpNonfoodType = response.results;
                    }
                },
                (err: any) => { }
            );
    }

    // Food Contact Type
    public onDialogClose(): void {
      this.dialogFlag = false;
    }
    public open(i?: number): void {
      this.addedFieldIndex = i;
      this.dialogFlag = true;
      this.gettingFoodContactType();
    }
    public addNewFoodContactField(): any{
      if (this.newFoodContactTypes.length <= 3)
      {
        this.newFoodContactTypes.push(new FormControl());
        this.fieldAdded = true;
        this.controlValues.push('');
      }
    }
     public removeFoodContactType(i: number): any{
      this.newFoodContactTypes.removeAt(i);
    }
    selectedFoodContactData(data: any): void {
      if (this.addedFieldIndex >= 0) {
        this.controlValues.splice(this.addedFieldIndex, 1, data.descr);
        this.foodForm.controls.newFoodContactType.patchValue(this.controlValues);
        this.addedFieldIndex = undefined;
     } else {
      this.dataFromFoodContact = data.descr;
      this.foodForm.controls.foodContactType.patchValue(data.descr);

    }
      this.dialogFlag = false;
    }


    // Contact Zone
    public onZoneClose(): void {
      this.dialogZone = false;
  }
    public zoneopen(): void {
      this.gettingContactZone();
      this.dialogZone = true;
  }

  selectedContactZone(data: any): void {
    this.dataFromContactZone = data.DISPLAY_VALUE;
    this.foodForm.controls.contactZone.patchValue(data.DISPLAY_VALUE);
    this.dialogZone = false;
  }

  // Resin Types
  public onresinClose(): void {
    this.dialogResin = false;
}

  public resinopen(): void {
    this.gettingResinTypes();
    this.dialogResin = true;
}
selectedResinTypes(data: any): void {
  this.dataFromResinTypes = data.descr;
  this.foodForm.controls.resinTypes.patchValue(data.descr);
  this.dialogResin = false;
}


// Food contact material type
  public onmaterialClose(): void {
    this.dialogMaterialType = false;
}
  public materialopen(): void {
    this.gettingMaterialType();
    this.dialogMaterialType = true;
}
selectedMaterialType(data: any): void {
  this.dataFromMaterialType = data.descr;
  this.foodForm.controls.foodContactMaterialType.patchValue(data.descr);
  this.dialogMaterialType = false;
}

// Nonfood category
  public onnonfoodClose(): void {
    this.dialogNonfoodType = false;
}

  public nonfoodopen(i?: number): void {
    this.nonAddedFieldIndex = i;
    this.dialogNonfoodType = true;
    this.gettingNonfoodCategory();
}
public addNewNonfoodCategoryField(): any{
  if (this.newNonfoodCategoryTypes.length <= 3) {
    this.newNonfoodCategoryTypes.push(new FormControl());
    this.nonFieldAdded = true;
    this.nonControlValues.push('');
  }
}

 public removeNonfoodCategoryType(i: number): any{
  this.newNonfoodCategoryTypes.removeAt(i);
}
selectedNonfoodType(data: any): void {
  if (this.nonAddedFieldIndex >= 0) {
    this.nonControlValues.splice(this.nonAddedFieldIndex, 1, data.descr);
    this.foodForm.controls.newNonfoodCategoryType.patchValue(this.controlValues);
    this.nonAddedFieldIndex = undefined;
 } else {
  this.dataFromNonfoodType = data.descr;
  this.foodForm.controls.nonfoodCategory.patchValue(data.descr);
 }
  this.dialogNonfoodType = false;
}

}
