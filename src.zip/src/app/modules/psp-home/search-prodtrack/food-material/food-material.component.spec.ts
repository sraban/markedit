import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FoodMaterialComponent } from './food-material.component';

describe('FoodMaterialComponent', () => {
  let component: FoodMaterialComponent;
  let fixture: ComponentFixture<FoodMaterialComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FoodMaterialComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FoodMaterialComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
