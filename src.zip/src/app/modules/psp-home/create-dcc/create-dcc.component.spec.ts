import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateDccComponent } from './create-dcc.component';

describe('CreateDccComponent', () => {
  let component: CreateDccComponent;
  let fixture: ComponentFixture<CreateDccComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CreateDccComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateDccComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
