import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { PspBaseService } from '../services/psp-base.service';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { TranslateService } from '@ngx-translate/core';
import { dataJsonIcon } from '@progress/kendo-svg-icons';


@Component({
  selector: 'app-create-dcc',
  templateUrl: './create-dcc.component.html',
  styleUrls: ['./create-dcc.component.scss']
})
export class CreateDccComponent implements OnInit {
  private isActive = new Subject();
  titles = 'kendo-Task';
  productdccform: FormGroup;
  nonproductdccform: FormGroup;
  public submitted = false;
  public nonProductSubmitted = false;

  selectedIndex = 0;

  lookUpPrefixData: any;
  lookPrefixHeader: any = [];
  dialogPrefix!: boolean;
  prefixLabel = '';
  dataFromPrefix: any;
  addedPrefixIndex: any;
  PrefixValues: any = [];
  height = 420;
  selectedTitle = '';
  lookUpInitialData: any;
  lookInitialHeader: any = [];
  dialogInitial!: boolean;
  initialLabel = '';
  dataFromInitial: any;

  lookUpNonPrefixData: any;
  lookNonPrefixHeader: any = [];
  dialogNonPrefix!: boolean;
  nonprefixLabel = '';
  dataFromNonPrefix: any;

  controlNames: any;
  nonControlNames: any;

  public selectedFacility : any = [];
  public selectedStandardValue : any  = [];
  public facilityLookupItems: any;
  public standardLookupItems: any;
  public loader: any;
  public notify: any;
  public facilityValue: any;
  public standardValue: any;
  public nonProductcsSeq: any;
  public successMessage: any;
  public customerSeq: any;
  public activitySeq: any;
  public nonProductItemSeq: any;
  public createTitleLabel = '';
  public nonProdcreateTitleLabel = '';
  createDialogFlag = false;
  nonProdCreateDialogFlag = false;
  public isDirty = false;
  public opened = false;
  public setprefixError = false;
  public createDccTranslate: any;
  public errorMessage= '';
  public style: any;
  public initialErrorFlag= false;
  public setNonPrefixError = false;
  public generateNonPrefixErr= '';
  pageable = {
    pageable: true,
    pageSize: 25,
  };

  constructor(private formBuilder: FormBuilder, private pspBaseService: PspBaseService, private translate: TranslateService) {
    this.productdccform = new FormGroup({
      prefix: new FormControl('', [Validators.required]),
      initial: new FormControl('', [Validators.required]),
      pick: new FormControl('A', [Validators.required]),
      trade: new FormControl('', [Validators.required]),
      facility: new FormControl('', [Validators.required]),
      standard: new FormControl('', [Validators.required]),
      coname: new FormControl('')
    });
    this.controlNames = {
      prefix: 'Prefix',
      initial: 'Initial Review #',
      pick: 'Item Type',
      trade: 'Primary Trade Name',
      facility: 'Facility #',
      standard: 'Standard'
    };

    this.nonproductdccform = new FormGroup({
      nonprefix: new FormControl('', [Validators.required]),
      supportdcc: new FormControl('', [Validators.required]),
      nonpick: new FormControl('A', [Validators.required]),
      nontrade: new FormControl('', [Validators.required]),
      supplier: new FormControl('', [Validators.required]),
      formulator: new FormControl(''),
      coname: new FormControl('', [Validators.required])
    });
    this.nonControlNames = {
      nonprefix: 'Prefix',
      supportdcc: 'Supported DCC #',
      nonpick: 'Item Type',
      nontrade: 'Primary Trade Name',
      supplier: 'Supplier',
      coname: 'Co # and Name',

    };
  }

  ngOnInit(): void {
    this.translate.get('createdcc').subscribe( (text: string) => {
      this.createDccTranslate = text;
      this.prefixLabel = this.createDccTranslate.prefixLabel;
      this.nonprefixLabel = this.createDccTranslate.prefixLabel;
      this.selectedTitle = this.createDccTranslate.selectedTitle;
      this.initialLabel = this.createDccTranslate.initialLabel;
      this.createTitleLabel = this.createDccTranslate.createTitleLabel;
      this.nonProdcreateTitleLabel = this.createDccTranslate.nonProdcreateTitleLabel;
      this.errorMessage= this.createDccTranslate.errorMessage;
      this.generateNonPrefixErr= this.createDccTranslate.generateNonPrefixErr;

    this.lookPrefixHeader = [
      {
        field: 'dcc_prefix',
        header_title: this.createDccTranslate.prefix,
        width: 150,
        type: 'input_text'
      },
      {
        field: 'descr',
        header_title:  this.createDccTranslate.description,
        width: 400,
        type: 'input_text'
      },
      {
        field: 'default_item_type',
        header_title: this.createDccTranslate.itemtype,
        width: 150,
        type: 'input_text'
      }
    ];
    this.lookInitialHeader = [
      {
        field: 'project_job',
        header_title: this.createDccTranslate.projectJob,
        width: 100,
        type: 'input_text'
      },
      {
        field: 'plant',
        header_title: this.createDccTranslate.plant,
        width: 400,
        type: 'input_text'
      },
      {
        field: 'parent_code',
        header_title: this.createDccTranslate.code,
        width: 150,
        type: 'input_text'
      },
      {
        field: 'cus_name',
        header_title: this.createDccTranslate.customerName,
        width: 150,
        type: 'input_text'
      }
    ];
    this.lookNonPrefixHeader = [
      {
        field: 'dcc_prefix',
        header_title: this.createDccTranslate.prefix,
        width: 150,
        type: 'input_text'
      },
      {
        field: 'descr',
        header_title:  this.createDccTranslate.description,
        width: 400,
        type: 'input_text'
      },
      {
        field: 'default_item_type',
        header_title: this.createDccTranslate.itemtype,
        width: 150,
        type: 'input_text'
      }
    ];
  });

  }

  public facilityValueChange(value: any): void {
    if (this.selectedFacility[0]?.code === 'ALL' && this.selectedFacility.length > 1 ){
     this.selectedFacility.shift();
     this.productdccform.get('facility')?.setValue(this.selectedFacility);
    } else if (this.selectedFacility.length > 1 && value[value.length - 1 ].code === 'ALL'){
          const defaultVal = [{ code: 'ALL'}];
          this.productdccform.get('facility')?.setValue(defaultVal);
    }
  }

  public standardValueChange(value: any): void {
    if (this.selectedStandardValue[0]?.std_code === 'ALL' && this.selectedStandardValue.length > 1 ){
     this.selectedStandardValue.shift();
     this.productdccform.get('standard')?.setValue(this.selectedStandardValue);
    } else if (this.selectedStandardValue.length > 1 && value[value.length - 1 ].std_code === 'ALL'){
          const defaultVal = [{ std_code: 'ALL'}];
          this.productdccform.get('standard')?.setValue(defaultVal);
    }
  }

  public gettingProductDccPrefix(): any {
    const reqObj = {};
    this.loader = true;
    this.pspBaseService
      .getProductDccPrefix(reqObj)
      .pipe(takeUntil(this.isActive))
      .subscribe(
        (response: any) => {
          if (response.status === 'SUCCESS') {
            this.lookUpPrefixData = response.results;
            this.loader=false;
          }
        },
        (err: any) => {// This is intentional 
        });
  }

  public gettingProductInitialReview(): any {
    const reqObj = {};
    this.loader=true;
    this.pspBaseService
      .getProductInitialReview(reqObj)
      .pipe(takeUntil(this.isActive))
      .subscribe(
        (response: any) => {
          if (response.status === 'SUCCESS') {
            this.lookUpInitialData = response.results;
            this.loader = false;
            this.dialogInitial = true;
          }
          else {
            this.notify = {
              content: response.results[0].message,
              style: 'error'
            };
            this.loader = false;
          }
        },
        (err: any) => {// This is intentional 
          this.loader=false;
        });
  }

  public gettingNonProductDccPrefix(): any {
    const reqObj = {};
    this.loader = true;
    this.pspBaseService
      .getNonProductDccPrefix(reqObj)
      .pipe(takeUntil(this.isActive))
      .subscribe(
        (response: any) => {
          if (response.status === 'SUCCESS') {
            this.lookUpNonPrefixData = response.results;
            this.loader = false;
          }
          else {
            this.notify = {
              content: response.results[0].message,
              style: 'error'
            };
            this.loader = false;
          }
        },
        (err: any) => {
          this.loader = false;
          this.notify =
           {
             style : 'error',
            content : err.statusText
           };
        });
  }

  onCreateDialog(event: any): any {
    this.submitted = true;
    if(this.productdccform.valid  ){
      this.createDialogFlag = true;      
      if (event==='Yes') {
        this.onAccept();
      }
      else if(event==='No') this.createDialogFlag= false;
    }
    else {
      this.createDialogFlag= false;
    }
  }

  onCreateDialogClose(event: any): any {
    this.createDialogFlag = false;
    if (event === 'Yes') {
      this.onAccept();
    }
  }


  onNonProdCreateDialog(event: any): any {
    this.nonProductSubmitted = true;
    if(this.nonproductdccform.valid  ){
      this.nonProdCreateDialogFlag = true;      
      if (event==='Yes') {
        this.onNonDccAccept();
      }
      else if(event==='No') this.nonProdCreateDialogFlag= false;
    }
    else {
      this.nonProdCreateDialogFlag= false;
    }
    
  }

  onNonProdCreateDialogClose(event: any): any {
    this.nonProdCreateDialogFlag = false;
    if (event === 'Yes') {
      this.onNonDccAccept();
    }
  }

  onAccept(): any{
    this.onSubmit();
  }

  onNonDccAccept(): any{
    this.onNonSubmit();
  }

  onSubmit(): any {
    this.submitted = true;
      this.facilityValue= this.selectedFacility[0]?.code!=="ALL"?
      this.productdccform.controls.facility.value:this.facilityLookupItems.slice(1,this.facilityLookupItems.length);
      this.standardValue= this.selectedStandardValue[0]?.std_code!="ALL"?
      this.productdccform.controls.standard.value:this.standardLookupItems.slice(1,this.standardLookupItems.length);
    
    const qparams = {
      cus_seq: this.customerSeq,
      dcc_prefix: this.productdccform.controls.prefix.value,
      facilityList: this.facilityValue,
      group_code: this.standardLookupItems ? this.standardLookupItems[0]?.group_code:'',
      iact_seq: this.activitySeq,
      item_type: this.productdccform.controls.pick.value,
      standardList: this.standardValue,
      trade_name: this.productdccform.controls.trade.value
    }
    this.pspBaseService.getProductDccForm(qparams).pipe(takeUntil(this.isActive)).subscribe(
      (response: any) => {
        if (response.status === 'SUCCESS') {
          const productSuccessMessage = this.createDccTranslate.productDcc +' '+ response.results.dcc +' '+ this.createDccTranslate.dccSuccess 
          this.createDialogFlag = false;
          this.notify = {
            style : 'success',
           content : productSuccessMessage,
          };
        }
        else {
          this.notify = {
            content: response.results[0].message,
            style: 'error'
          };
          this.loader = false;
        }
    },
    (err: any) => {
      this.loader = false;
      this.notify =
       {
         style : 'error',
        content : err.statusText
       };
    });
  
  }

 
  onNonSubmit(): any {
    this.nonProductSubmitted = true;
    const nonProductqpaarams = {
      cus_seq: this.nonProductcsSeq,
      dcc_prefix: this.nonproductdccform.controls.nonprefix.value,
      formulator_name: this.nonproductdccform.controls.formulator.value,
      item_type: this.nonproductdccform.controls.nonpick.value,
      supplier_name: this.nonproductdccform.controls.supplier.value,
      supported_dcc_seq: this.nonProductItemSeq,
      trade_name: this.nonproductdccform.controls.nontrade.value,
    }

    this.pspBaseService.getNonProductDccForm(nonProductqpaarams).pipe(takeUntil(this.isActive)).subscribe(
      (response: any) => {
        if (response.status === 'SUCCESS') {
          const nonProductSuccessMessage = this.createDccTranslate.nonProductDcc +' '+ response.results.dcc +' '+ this.createDccTranslate.nonDccSuccess
          this.nonProdCreateDialogFlag = false;
          this.notify = {
            style : 'success',
           content : nonProductSuccessMessage,
          };
        }
        else {
          this.notify = {
            content: response.results[0].message,
            style: 'error'
          };
          this.loader = false;
        }
    },
    (err: any) => {
      this.loader = false;
      this.notify =
       {
         style : 'error',
        content : err.statusText
       };
    });

  }

  onReset(): any {
    this.submitted = false;
    this.productdccform.reset();
    this.productdccform.controls.pick.setValue('A');
    this.facilityLookupItems = '';
    this.standardLookupItems= '';
    this.notify = {};
    this.setprefixError=false;
  }

  onNonReset(): any {
    this.nonProductSubmitted = false;
    this.nonproductdccform.reset();
    this.nonproductdccform.controls.nonpick.setValue('A');
    this.setNonPrefixError = false;
    this.notify = {};
  }

  onTabSelect(val: any): any {
    this.selectedTitle = val.title;
    this.onReset();
    this.onNonReset();
  }

  /* To close Dcc Prefix popup */
  public onPrefixClose(): void {
    this.dialogPrefix = false;

  }
  /* To Open Dcc Prefix popup */
  public prefixOpen(): void {
    this.gettingProductDccPrefix();
    this.dialogPrefix = true;
  }

  /* Selected Dcc Prefix data */
  selectedPrefixData(data: any): void {
    this.dataFromPrefix = data.dcc_prefix;
    this.productdccform.controls.prefix.patchValue(data.dcc_prefix);
    this.productdccform.controls.pick.patchValue(data.default_item_type);
    this.dialogPrefix = false;
  }
  /* To close Initial Review popup */
  public onInitialClose(): void {
    this.dialogInitial = false;

  }
  /* To Open Initial Review popup */
  public initialOpen(): void {
    this.gettingProductInitialReview();

  }

  /* Selected Initial Review data */
  selectedInitialData(data: any): void {
    this.dataFromInitial = data.project_job;
    this.productdccform.controls.initial.patchValue(data.project_job);
    this.customerSeq = data.parent_seq;
    this.activitySeq = data.iact_seq;
    const coNameNumber=data.parent_code+" "+data.parent_name;
    this.productdccform.controls.coname.patchValue(coNameNumber)
    this.dialogInitial = false;
    const qparams= {code: data.parent_seq}
    this.pspBaseService.getProductFacilityLookup(qparams).pipe(takeUntil(this.isActive)).subscribe(
      (response: any) => {
        if (response.status === 'SUCCESS') {
          this.facilityLookupItems = response.results.map((data: any)=>{
            const obj={
              code: data.code,
              cus_seq:data.cus_seq
            }
            return obj
          });
          this.facilityLookupItems.unshift({code: 'ALL', cus_seq: 'ALL'});
          this.selectedFacility = [{ code: 'ALL' , cus_seq: 'ALL'}];
          
        }
      },
      (err: any) => {// This is intentional
      });
     const standardqparams={cus_seq: data.parent_seq,
      item_type: this.productdccform.controls.pick.value,
      std_code: ""}
    this.pspBaseService.getProductStandardLookup(standardqparams).pipe(takeUntil(this.isActive)).subscribe((
      response:any)=>{
        if (response.status === 'SUCCESS') {
          this.standardLookupItems = response.results.map((data: any)=>{
            const obj={
              std_code:data.std_code,
              list_status_type:data.list_status_type,
              group_code:data.group_code
            }
            return obj;
          });
         
         if(response.count>0){
          this.standardLookupItems.unshift({std_code: 'ALL'});
          this.selectedStandardValue = [{ std_code: 'ALL' }];
         }

        }
      },(err:any)=>{// This is intentional

      })
  }

  /* To close Non Dcc Prefix popup */
  public onNonPrefixClose(): void {
    this.dialogNonPrefix = false;

  }
  /* To Open Non Dcc Prefix popup */
  public nonprefixOpen(): void {
    this.gettingNonProductDccPrefix();
    this.dialogNonPrefix = true;


  }

  /* Selected Non Dcc Prefix data */
  selectedNonPrefixData(data: any): void {
    this.dataFromNonPrefix = data.dcc_prefix;
    this.nonproductdccform.controls.nonprefix.patchValue(data.dcc_prefix);
    this.nonproductdccform.controls.nonpick.setValue(data.default_item_type);
    this.dialogNonPrefix = false;
  }

  getSupportDcc(event:any){
    if(event.target.value){
      const val={dcc:event.target.value}
      this.loader= true;
      this.pspBaseService.getNonProductSupportDcc(val).pipe(takeUntil(this.isActive)).subscribe((
        response:any)=>{
          if (response.status === 'SUCCESS') {
            this.loader= false;
            const dccNameNo=response.results[0].cus_code+" "+response.results[0].cus_name
            this.nonProductItemSeq=response.results[0].itm_seq;
            this.nonProductcsSeq=response.results[0].cus_seq
            this.nonproductdccform.controls.coname.setValue(dccNameNo)
          }
          else {
            this.notify = {
              content: response.results[0].message,
              style: 'error'
            };
            this.loader = false;
          }
        },
        (err: any) => {// This is intentional 
          this.loader=false;
        });
    }
  }
  getInitialData(event:any){

    if(event.target.value){
    const  reqObj = {project_job: event.target.value};
      this.pspBaseService
      .getProductInitialReview(reqObj)
      .pipe(takeUntil(this.isActive))
      .subscribe(
        (data: any) => {
          if (data.status === 'SUCCESS') {
            this.lookUpInitialData = data.results;
            this.selectedInitialData(data.results[0])
            this.loader = false;
            this.initialErrorFlag = false;
          }
          else {
            this.notify = {
              content: data.results[0].message,
              style: 'error'
            };
            this.loader = false;
            this.initialErrorFlag = true;
          }
        },
        (err: any) => {// This is intentional 
          this.loader=false;
        });

    }else{
      this.facilityLookupItems = '';
      this.standardLookupItems= '';
      this.selectedStandardValue=[];
      this.selectedFacility=[];
    }
  }


  getPrefixData(event:any){
    const  reqObj = {dcc_prefix: event.target.value};
    if(reqObj.dcc_prefix.length!=0){
      this.pspBaseService
      .getProductDccPrefix(reqObj)
      .pipe(takeUntil(this.isActive))
      .subscribe(
        (data: any) => {
          if (data.status === 'SUCCESS') {
            if(this.productdccform.controls?.prefix.value.length < 2 && (this.productdccform.controls?.prefix.value.length!=0)){
              this.setprefixError = true;
              this.errorMessage = this.createDccTranslate.errorMessage;

            }
            else{
              this.lookUpPrefixData = data.results;
              this.productdccform.controls.pick.patchValue(data.results[0].default_item_type);

            this.selectedPrefixData(data.results[0])
            this.loader = false;
            }
            
          }
          else {
            this.setprefixError=true;
            this.errorMessage = data.results[0].message
            this.loader = false;
          }
        },
        (err: any) => {// This is intentional 
          this.loader=false;
        });

      }
      else {
        this.productdccform.controls.pick.setValue('A');
      }    

  }

  getNonPrefixData(event:any){
    const  reqObj = {dcc_prefix: event.target.value};
    if(reqObj.dcc_prefix.length!=0){
      this.pspBaseService
      .getNonProductDccPrefix(reqObj)
      .pipe(takeUntil(this.isActive))
      .subscribe(
        (data: any) => {
          if (data.status === 'SUCCESS') {
            if(this.nonproductdccform.controls?.nonprefix.value.length < 2 && (this.nonproductdccform.controls?.nonprefix.value.length!=0)){
              this.setNonPrefixError = true;
              this.generateNonPrefixErr = this.createDccTranslate.generateNonPrefixErr;
            }
            else{
            this.lookUpNonPrefixData = data.results;
            this.nonproductdccform.controls.nonpick.patchValue(data.results[0].default_item_type);
            this.selectedNonPrefixData(data.results[0])
            this.loader = false;
            }

          }
          else {
            this.setNonPrefixError = true;
            this.generateNonPrefixErr = data.results[0].message;
            this.loader = false;
          }
        },
        (err: any) => {// This is intentional 
          this.loader=false;
        });

      }
      else {
        this.nonproductdccform.controls.nonpick.setValue('A');
      }  
  }

  clearNotification(comp: any): void {
   if(comp=="gdcc") this.setprefixError=false;
   else if(comp=="gNondcc") this.setNonPrefixError = false;
  }
}
