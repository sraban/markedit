import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PspHomeComponent } from './psp-home.component';
import { SearchComponent } from './search-prodtrack/search.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { CreateDccComponent } from './create-dcc/create-dcc.component';

const routes: Routes = [{ path: '', component: PspHomeComponent,
children: [
  { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
  { path: 'dashboard', component: DashboardComponent },
  { path: 'search', component: SearchComponent },
  { path: 'createdcc', component: CreateDccComponent },
  { path: 'reports',
    loadChildren: () => import('./../psp-home/customer-reports/customer-reports.module').then(m => m.CustomerReportsModule) },
  { path: 'masters', loadChildren: () => import('./../psp-home/masters/masters.module').then(m => m.MastersModule) },
  { path: 'trackingReports', loadChildren: () => import('./tracking-reports/tracking-reports.module').then(m => m.TrackingReportsModule) },
  { path: 'admin', loadChildren: () => import('./admin/admin.module').then(m => m.AdminModule) }
]
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PspHomeRoutingModule { }
