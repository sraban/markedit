import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Subject } from 'rxjs';
import { constObj } from '../psp-constants';

@Injectable({
  providedIn: 'root'
})
export class PspBaseService {
  public resetForm: Subject<any> = new Subject<any>();
  private searchSubject = new Subject<any>();
  searchObservable = this.searchSubject.asObservable();
  constructor(private http: HttpClient) { }

  // Common API for Dropdown
  getDropdownAPI(url: any, reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + url, reqObj);
  }
  // dashboard API
  getProgramsDropdown(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.programsDropdown, reqObj);
  }
  getShowSearchViewAlertsDetails(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.searchViewAlerts, reqObj);
  }
  // program standard API
  saveProgramStandard(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.searchProdtrack.programStandard.standardLookup, reqObj);
  }
  // program standard API for drop do
  getProgramNameDropdown(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.searchProdtrack.programStandard.programsLookup, reqObj);
  }
  // category master API
  getCategoryDropdown(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.lookupNames, reqObj);
  }
  createCategoryMaster(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.categoryMaster.create, reqObj);
  }
  searchCategoryMaster(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.categoryMaster.search, reqObj);
  }
  updateCategoryMaster(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.categoryMaster.update, reqObj);
  }
  deleteCategoryMaster(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.categoryMaster.delete, reqObj);
  }
  // chemical master API
  searchchemicalsMaster(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.chemicalMaster.search, reqObj);
  }
  createChemicalsMaster(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.chemicalMaster.save, reqObj);
  }
  deletechemicalsMaster(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.chemicalMaster.delete, reqObj);
  }
  editchemicalsMaster(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.chemicalMaster.get, reqObj);
  }
  getTestCode(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.chemicalMaster.getdecisionCode, reqObj);
  }
  // Dietary Supplements API
  getClassificationDetails(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.searchProdtrack.dietarySupplements.classificationLookup, reqObj);
  }
  gettingProductTypeForms(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.lookupNames, reqObj);
  }

  // Brakefriction Material API

  getComplianceLavelDropdown(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.lookupNames, reqObj);
  }
  getVehicleUsageDropdown(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.lookupNames, reqObj);
  }

  // Analytes master API
  getAnalytesDropdown(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.lookupNames, reqObj);
  }
  getAnalytesUpdate(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.analytes.update, reqObj);
  }
  getAnalytesTestCode(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.analytes.analysisLookup, reqObj);
  }
  searchAnalytesMaster(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.analytes.search, reqObj);
  }

  getAnalytesPrepCode(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.analytes.prepcodeLookup, reqObj);
  }
  getAnalytesCreate(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.analytes.create, reqObj);
  }
  deleteAnalyteMaster(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.analytes.delete, reqObj);
  }
  // Assessmentcodes masters API
  searchAssessmentCodes(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.assessmentCodes.search, reqObj);
  }
  createAssessmentCodeType(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.assessmentCodes.create, reqObj);
  }
  updateAssessmentCodeType(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.assessmentCodes.update, reqObj);
  }
  deleteAssessmentCodeType(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.assessmentCodes.delete, reqObj);
  }
  dropdownAssessmentCodeType(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.assessmentCodes.dropdownLookup, reqObj);
  }
  // Function Master APIs
  searchFunctionMaster(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.functionMaster.search, reqObj);
  }
  createFunctionMaster(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.functionMaster.create, reqObj);
  }
  updateFunctionMaster(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.functionMaster.update, reqObj);
  }
  deleteFunctionMaster(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.functionMaster.delete, reqObj);
  }

  // Food Material Popup APIs
  getFoodContactType(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + 'master/foodContactType/search', reqObj);
  }
  getContactZone(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.lookupNames, reqObj);
  }
  getResinTypes(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + 'master/resinType/search', reqObj);
  }
  getMaterialType(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + 'master/materialType/search', reqObj);
  }
  getNonfoodCategory(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + 'dcc/nonFoodCategory/nonfoodCategoriesLookUp', reqObj);
  }

  // Customer Reports
  getCustomerReports(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.reports.getCustomerReport, reqObj);
  }
  generateReport(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.reports.generateCustomerReport, reqObj);
  }
  previewReport(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.reports.previewReport, reqObj);
  }
  merge(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + 'reports/merge', reqObj, { responseType: 'arraybuffer' });
  }
  mergeGenerate(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.reports.mergeReport, reqObj);
  }
  // Recent DCC
  getRecentDccInfo(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.getRecentDcc, reqObj);
  }
  // Create DCC APIs
  getProductDccPrefix(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.ProductDccPrefix, reqObj);
  }
  getProductInitialReview(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.ProductInitialReview, reqObj);
  }
  getNonProductDccPrefix(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.NonProductDccPrefix, reqObj);
  }

  getProductFacilityLookup(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.ProductFacilityLookup, reqObj);
  }

  getProductStandardLookup(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.ProductStandardLookup, reqObj);
  }

  getNonProductSupportDcc(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.NonProductSupportDcc, reqObj);
  }

  getProductDccForm(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + 'dcc/createProductDcc', reqObj);
  }

  getNonProductDccForm(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + 'dcc/createNonProductDcc', reqObj);
  }
  // water Assembly API
  getReductionClaim(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.reductionClaim.search, reqObj);
  }
  getSystemType(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + 'master/systemType/search', reqObj);
  }
  getEndUse(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + 'master/euMasterType/search', reqObj);
  }
  getMaterialTypeWA(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + 'master/materialType/search', reqObj);
  }
  getFunction(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + 'master/functionMaster/search', reqObj);
  }
  getSectionCategory(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + 'master/categoryType/search', reqObj);
  }
  public resetData(): any {
    const formData = 'reset';
    this.resetForm.next(formData);
  }
  // Non food category master API
  searchNonFoodCategoryMaster(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + 'master/nonFoodCategory/search', reqObj);
  }
  updateNonFoodCategoryMaster(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.nonfoodCategory.update, reqObj);
  }
  deleteNonFoodCategoryMaster(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.nonfoodCategory.delete, reqObj);
  }
  saveCloseNonFoodCategoryMaster(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.nonfoodCategory.create, reqObj);
  }

  // Document Text
  getDocumentTextFunction(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.documentText.search, reqObj);
  }
  createDocumentTextMaster(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.documentText.create, reqObj);
  }
  updateDocumentTextMaster(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.documentText.update, reqObj);
  }
  deleteDocumentTextMaster(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.documentText.delete, reqObj);
  }
  dropdowndocumentTextMaster(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.documentText.dropdown, reqObj);
  }

  // Material Type
  getMaterialTypeMaster(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.materialType.search, reqObj);
  }
  createMaterialTypeMaster(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.materialType.create, reqObj);
  }
  updateMaterialTypeMaster(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.materialType.update, reqObj);
  }
  deleteMaterialTypeMaster(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.materialType.delete, reqObj);
  }

  // Reduction Claim Master API
  searchReductionClaim(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.reductionClaim.search, reqObj);
  }
  updateReductionClaim(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.reductionClaim.update, reqObj);
  }
  deleteReductionClaim(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.reductionClaim.delete, reqObj);
  }
  createReductionClaim(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.reductionClaim.create, reqObj);
  }
  // System Type Master API
  searchsytemType(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.systemType.search, reqObj);
  }
  updatesytemType(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.systemType.update, reqObj);
  }
  deletesytemType(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.systemType.delete, reqObj);
  }
  createsytemType(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.systemType.create, reqObj);
  }

  // Resin Types Master API
  searchResinTypes(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.resinTypes.search, reqObj);
  }
  updateResinTypes(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.resinTypes.update, reqObj);
  }
  deleteResinTypes(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.resinTypes.delete, reqObj);
  }
  createResinTypes(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.resinTypes.create, reqObj);
  }

  // End User Master API
  searchEndUser(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.enduseMaster.search, reqObj);
  }
  updateEndUser(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.enduseMaster.update, reqObj);
  }
  deleteEndUser(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.enduseMaster.delete, reqObj);
  }
  createEndUser(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.enduseMaster.create, reqObj);
  }

  // Performance Standard Master API
  searchPerformanceStandard(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.performanceStandard.search, reqObj);
  }
  updatePerformanceStandard(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.performanceStandard.update, reqObj);
  }
  deletePerformanceStandard(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.performanceStandard.delete, reqObj);
  }
  createPerformanceStandard(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.performanceStandard.create, reqObj);
  }

  // Test Decision master API
  searchTestDecisionMaster(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.testDecisions.search, reqObj);
  }

  saveCloseTestDecisionMaster(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.testDecisions.create, reqObj);

  }
  searchAssementCodeTypeLookup(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.testDecisions.searchAssementCodeType, reqObj);

  }
  testingTypeDropdown(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.testDecisions.testingTypeDropdown, reqObj);

  }
  analyteCodeDescription(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.testDecisions.analyteCodeDescription, reqObj);

  }
  deleteTestDecision(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.testDecisions.delete, reqObj);

  }
  getCodeTestDecision(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.testDecisions.get, reqObj);

  }
  // Master Raw Material Number API's
  searchRawMaterialNumbersMaster(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.rawMaterialNumber.search, reqObj);
  }
  getCorporateAndProgramRawMaterialNumber(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.rawMaterialNumber.corporate, reqObj);
  }
  addNewRow(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.rawMaterialNumber.addRow, reqObj);
  }
  rawMaterialNumberCreate(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.rawMaterialNumber.create, reqObj);
  }
  rawMaterialNumberUpdate(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.rawMaterialNumber.update, reqObj);
  }
  deleteRawMaterialNumberMaster(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.rawMaterialNumber.delete, reqObj);
  }
  // Master Food Contact Type screen API's
  searchFoodContactType(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.foodContactType.search, reqObj);
  }
  createFoodContactType(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.foodContactType.create, reqObj);
  }
  updateFoodContactType(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.foodContactType.update, reqObj);
  }
  deleteFoodContactType(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.foodContactType.delete, reqObj);
  }


  // Generate Dcc API
  facilityStdData(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.reports.generateDcc.facilityStdLookup, reqObj);
  }

  initialReviewData(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.reports.generateDcc.initialReviewLookup, reqObj);
  }

  signingAuthorityData(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.reports.generateDcc.signingAuthorityLookup, reqObj);
  }

  getTextCode(reqObj: any): any{
    return this.http.post(`${environment.baseUrl}` + constObj.reports.generateDcc.textCodeLookup, reqObj);
  }

  getValidateDcc(reqObj: any): any{
    return this.http.post(`${environment.baseUrl}` + constObj.reports.generateDcc.validateDcc, reqObj);
  }

  getGenerateDccDoc(reqObj: any): any{
    return this.http.post(`${environment.baseUrl}` + constObj.reports.generateDcc.generateDccDoc, reqObj);
  }

  getDownloadDccDoc(reqObj: any): any{
    return this.http.post(`${environment.baseUrl}` + constObj.reports.generateDcc.downloadDccDoc, reqObj);
  }
  getRevisionInitialReview(reqObj: any): any{
    return this.http.post(`${environment.baseUrl}` + constObj.reports.generateDcc.revisionInitialReview, reqObj);
  }

  getUploadDocument(reqObj: any): any{
    return this.http.post(`${environment.baseUrl}` + constObj.reports.generateDcc.uploadDocument, reqObj);
  }

  // Note Master API
  searchNoteMaster(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.noteMaster.search, reqObj);
  }
  updateNoteMaster(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.noteMaster.update, reqObj);
  }
  deleteNoteMaster(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.noteMaster.delete, reqObj);
  }
  noteType(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.noteMaster.noteType, reqObj);
  }
  noteStandard(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.noteMaster.noteStandard, reqObj);
  }
  noteStandardGroup(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.noteMaster.noteStandardGroup, reqObj);
  }
  createNoteMaster(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.masters.noteMaster.create, reqObj);
  }

  // Turn Around Time API
  getToxData(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + 'reports/tox', reqObj);
  } 

  // Change DCC Status API
  searchDcc(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.admin.dccstatuschange.searchDcc, reqObj);
  }
  getFacility(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.admin.dccstatuschange.searchFacility, reqObj);
  }
  getInitialReview(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.admin.dccstatuschange.searchInitialReview, reqObj);
  }
  save(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.admin.dccstatuschange.save, reqObj);
  }


  //Admin 
  //Chnage corporate
  getCorporate(reqObj:any):any{
    return this.http.post(`${environment.baseUrl}` + constObj.admin.changeCorporate.searchCorporate, reqObj);
  }
  getAssociatedDccByCorporate(reqObj:any){
    return this.http.post(`${environment.baseUrl}`+ constObj.admin.changeCorporate.getAssociatedDccByCorporate, reqObj);
  }
  updateAssociatedDccByCorporate(reqObj:any){
    return this.http.post(`${environment.baseUrl}`+ constObj.admin.changeCorporate.updateAssociatedDccByCorporate, reqObj);
  }

  // Change Item Type
  getDCCInfo(reqObj:any):any{
    return this.http.post(`${environment.baseUrl}`+ constObj.admin.changeItemType.getDccInfo, reqObj)
  }

  getChangeItemType(reqObj:any){
    return this.http.post(`${environment.baseUrl}`+ constObj.admin.changeItemType.dccChangeItemType, reqObj)
  }

  getItemTypeDropDown(reqObj:any){
    return this.http.post(`${environment.baseUrl}`+ constObj.admin.changeItemType.getItemTypeDropDown, reqObj)
  }
 
  saveItemType(reqObj:any){
    return this.http.post(`${environment.baseUrl}`+ constObj.admin.changeItemType.save, reqObj)
  }



  //Tracking Reports
  ////Bracketing Reports
  getBracketingDCC(reqObj:any):any{
    return this.http.post(`${environment.baseUrl}`+ constObj.reports.bracketingDCC, reqObj);
  }

  ///Bracketing Tool
  getStatusBracketingTool(reqObj:any){
    return this.http.post(`${environment.baseUrl}`+ constObj.reports.getStatusBracketingTool, reqObj);
  }

  getFilename(reqObj:any){
    return this.http.post(`${environment.baseUrl}`+ constObj.reports.filename, reqObj);
  }

  getBracketingTool(reqObj:any){
    return this.http.post(`${environment.baseUrl}`+ constObj.reports.bracketingTool ,reqObj)
  } 
  // product using dcc-REPORT
 getorderByDropdown(reqObj:any){
    return this.http.post(`${environment.baseUrl}`+ constObj.reports.fetchOrderByValuesProdDcc ,reqObj)
  }
  getproductDcc(reqObj:any){
    return this.http.post(`${environment.baseUrl}`+ constObj.reports.ProductDcc ,reqObj)
  } 

  // non food review log api's
  nonFoodReviewProgramDropDown(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.trackingReports.nonFoodReviewLog.programDropdown, reqObj);
  }
  nonFoodReviewProgramStatus(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.trackingReports.nonFoodReviewLog.programStatus, reqObj);
  }
  nonFoodReviewRevisionStatus(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.trackingReports.nonFoodReviewLog.revisionStatus, reqObj);
  }
  nonFoodReviewdccStatus(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.trackingReports.nonFoodReviewLog.dccStatus, reqObj);
  }
  nonFoodReviewnonFood(reqObj: any): any {
    return this.http.post(`${environment.baseUrl}` + constObj.trackingReports.nonFoodReviewLog.nonFood, reqObj);
  }


   // Admin
  //  export formulation
  getvalidDcc(reqObj:any){
    return this.http.post(`${environment.baseUrl}`+ constObj.admin.exportFormulation.isValidDcc ,reqObj)
  }
 getsequenceNo(reqObj:any){
  return this.http.post(`${environment.baseUrl}`+ constObj.admin.exportFormulation.getDspSeqNos ,reqObj)
}
getexport(reqObj:any){
  return this.http.post(`${environment.baseUrl}`+ constObj.admin.exportFormulation.export ,reqObj)
} 
  
}
