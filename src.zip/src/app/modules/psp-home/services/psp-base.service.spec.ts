import { TestBed } from '@angular/core/testing';

import { PspBaseService } from './psp-base.service';

describe('PspBaseService', () => {
  let service: PspBaseService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PspBaseService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
