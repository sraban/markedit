import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
@Component({
  selector: 'app-dietary-supplement-review-tool',
  templateUrl: './dietary-supplement-review-tool.component.html',
  styleUrls: ['./dietary-supplement-review-tool.component.scss']
})
export class DietarySupplementReviewToolComponent implements OnInit {
  public dietarySupplementForm: FormGroup;
  constructor(private formBuilder: FormBuilder) { 
    this.dietarySupplementForm = this.formBuilder.group({
      initialReview: new FormControl(''),
      facility: new FormControl('')
    });
  }

  ngOnInit(): void {
  }
  clearSearch(){

  }
  go(){
    
  }

}
