import { Component, OnInit, HostListener } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../../../environments/environment';
import { takeUntil } from 'rxjs/operators';
import { PspBaseService } from '../../services/psp-base.service';
import { FormGroup, FormControl, Validators, FormBuilder, FormArray } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-change-corporate',
  templateUrl: './change-corporate.component.html',
  styleUrls: ['./change-corporate.component.scss']
})
export class ChangeCorporateComponent implements OnInit {

  dcc = new Array(1).fill(null);
  public oldCorporate: any = '';
  public newCorporate: any;
  reqObj = {
    code: "C0439513",
    valid_flg: "Y"
  };
  isloading=false;

  notify: any;
  dccArray: any;
  row = [null];

  groupCorporate = new FormGroup({
    oldCorporate: new FormControl('', Validators.required),
    newCorporate: new FormControl('', Validators.required)
  });
  isOldCorp: any = null;
  isNewCorp: any = null;
  isSame = true;
  formGroup: any;
  showGrid = false;
  gridData: any[] = [];
  lookUpHeader: any = [];
  selectedRow: number[] = [1];
  extractDataItems: any;
  public mySelection: number[] = [1];
  adminTranslate: any;
  updateCorporateLabel: any;
  isUpdate = false;
  records: any;

  selectableSettings = {
    checkboxOnly: false,
    mode: "multiple",
    drag: true
  };

  get dccs(): FormArray {
    return this.formGroup.get("dccs") as FormArray;
  }


  constructor(private translate: TranslateService, private pspService: PspBaseService, private formBuilder: FormBuilder) {
    this.extract();
  }




  ngOnInit() {

    this.translate.get('admin').subscribe((text: string) => {
      this.adminTranslate = text;
      this.updateCorporateLabel = this.adminTranslate.updateConfirmation;
    })

    this.formGroup = this.formBuilder.group({
      oldCorporate: new FormControl('', Validators.required),
      newCorporate: new FormControl('', Validators.required),
      dccs: this.formBuilder.array([this.addedRow(), this.addedRow(), this.addedRow(), this.addedRow(), this.addedRow()])
    });

    this.lookUpHeader = [
      {
        field: 'dcc',
        header_title: 'DCC #',
        width: 150,
        type: 'input_text'
      },
      {
        field: 'currentCorp',
        header_title: 'Current Corp',
        width: 200,
        type: 'input_text'
      },
      {
        field: 'currentCorpName',
        header_title: 'Current Corporate Name',
        width: 200,
        type: 'input_text'
      },
      {
        field: 'newCorp',
        header_title: 'New Corp #',
        width: 200,
        type: 'input_text'
      },
      {
        field: 'newCorpName',
        header_title: 'New Corporate Name',
        width: 200,
        type: 'input_text'
      }

    ]

  }



  updateCorporate() {
    if (this.gridData.length) {
      this.isUpdate = true;
      this.records = 'Update ' + this.gridData.length + ' records from ' + this.gridData[0].currentCorp + ' to ' + this.gridData[0].newCorp;
    } else {
      this.notify = {
        style: 'error',
        content: 'Search Dcc'
      }
    }
  }

  updateData(e: any) {
    this.isUpdate = false;
    if (e === 'Yes') {
      this.isloading =true;
      let reqObj = {
        dcc_list: [{}],
        new_corporate_code: this.gridData[0].newCorp,
        old_corporate_code: this.gridData[0].currentCorp
      };

      for (let i = 0; i < this.gridData.length; i++) {
        let obj = { dcc: this.gridData[i].dcc, update_flag: "Y" }
        reqObj.dcc_list.push(obj)
      }
      reqObj.dcc_list = reqObj.dcc_list.filter(e => Object.keys(e).length);
      //console.log(reqObj);
      
      this.pspService.updateAssociatedDccByCorporate(reqObj).subscribe(
        (response: any) => {
          //console.log(response.results);
          this.isloading =false;
          if (response.status === 'SUCCESS') {
            this.notify = {
              style: 'success',
              content: 'Corporate Updated Successfully'
            }
          } else {
            this.notify = {
              style: 'error',
              content: 'Server Error'
            }
          }
        }
      )

    }
  }

  getOldCorporate() {
    this.formGroup.controls.oldCorporate.touched;
    this.isOldCorp = false;
    //console.log(this.formGroup.value.oldCorporate)
    const oldCorp = this.formGroup.value.oldCorporate;
    if (oldCorp.length >= 3) {
      this.reqObj.code = oldCorp;
      //console.log(this.reqObj);
      this.pspService.getCorporate(this.reqObj).subscribe(
        (response: any) => {
          //console.log(response.results)
          this.oldCorporate = response.results[0].name;
          if (response.status === 'SUCCESS') {
            this.isOldCorp = true;
          } else {
            this.isOldCorp = false;
          }
        }
      );
    }
  }

  getNewCorporate() {

    const newCorp = this.formGroup.value.newCorporate;
    //console.log(newCorp);
    if (newCorp.length >= 3) {
      this.reqObj.code = newCorp;
      this.pspService.getCorporate(this.reqObj).subscribe(
        (response: any) => {
          //console.log(response.results);
          this.newCorporate = response.results[0].name;
          if (response.status === 'SUCCESS') {
            this.isNewCorp = true;
          } else {
            this.isNewCorp = false;
          }
        }
      );
    }
  }

  searchDcc() {
    this.formGroup.markAllAsTouched();
    //console.log(this.formGroup.value);
    //console.log(this.formGroup.controls.dccs.value);
    this.formGroup.controls.dccs.value = this.formGroup.controls.dccs.value.filter((item: any) => item)
    //console.log(this.formGroup.controls.dccs.value);
    let reqObj = {
      old_corporate_code: this.formGroup.controls.oldCorporate.value,
      new_corporate_code: this.formGroup.controls.newCorporate.value,
      dcc_list: [{}]
    };
    let arr = this.formGroup.controls.dccs.value;
    let ui_index = 0;

    if (reqObj.old_corporate_code != '' && reqObj.new_corporate_code != '') {
      this.isSame = true;
     
      for (let i = 0; i < arr.length; i++) {

        ui_index += 1;
        let obj = { ui_index: ui_index, dcc: arr[i] };
        reqObj.dcc_list.push(obj)

      }

      reqObj.dcc_list = reqObj.dcc_list.filter(e => Object.keys(e).length);
      //console.log(reqObj);
      //console.log(reqObj);

      if (reqObj.dcc_list.length != 0) {
        this.isloading =true;
        this.pspService.getAssociatedDccByCorporate(reqObj).subscribe(
          (response: any) => {
            //console.log(response)
            this.isloading =false;
            if (response.status === 'SUCCESS') {
              this.notify = {
                style: 'success',
                content: response.results[0].message
              }
              this.showGrid = true;
              this.getGridData(reqObj);
              //console.log(response.results);
            } else {
              this.notify = {
                style: 'error',
                content: response.results[0].message
              }
            }
          }
        );
      } else {
        this.notify = {
          style: 'error',
          content: 'Enter Minimum 1 dcc'
        }
      }

    } else if (!reqObj.old_corporate_code && !reqObj.new_corporate_code) {
      this.isOldCorp = false;
      this.isNewCorp = false;
      this.notify = {
        style: 'error',
        content: 'Enter Current Corporate Code'
      }
    } else if (!reqObj.old_corporate_code) {
      this.isOldCorp = false;
      this.notify = {
        style: 'error',
        content: 'Enter Current Corporate Code'
      }
    } else if (reqObj.new_corporate_code === reqObj.old_corporate_code) {
      this.isNewCorp = null;
      this.isSame = false;
    } else if (reqObj.new_corporate_code == '') {
      this.isNewCorp = false;
      this.notify = {
        style: 'error',
        content: 'Enter New Corporate Code'
      }
    }



  }

  addedRow(): FormControl {
    return new FormControl('');
  }

  addNewRow() {
    this.dccArray = this.formGroup.controls.dccs as FormArray;
    this.dccArray.push(this.addedRow());
  }

  removeNewRow(i: any) {
    //console.log('removing...', i);
    (<FormArray>this.formGroup.get("dccs")).removeAt(i);

  }

  clearDcc() {
    this.showGrid = false;
    this.formGroup.reset();
    this.isNewCorp = null;
    this.isOldCorp = null;
    this.isSame = true;
    this.notify = {}
  }

  getGridData(data: any) {
    for (let i = 0; i < data.dcc_list.length; i++) {
      this.gridData.push(
        {
          dcc: data.dcc_list[i].dcc,
          currentCorp: data.old_corporate_code,
          currentCorpName: this.oldCorporate,
          newCorp: data.new_corporate_code,
          newCorpName: this.newCorporate
        }
      )
    }
    this.gridData = Array.from(new Set(this.gridData.map(g => g.dcc))).map(dcc => {
      return this.gridData.find(g => g.dcc === dcc)
    })

    //console.log(this.gridData);
  }

  onRowSelect(e: number[]) {
    //console.log(e);
    this.extractDataItems = this.selectedRow.map(idx => {
      return this.gridData.find(item => item.ProductID === idx);
    });
    //console.log('74', this.extractDataItems);
    //console.log(this.selectedRow)
  }
  keyChange(e: any) {
    this.extract();
  }

  extract() {
    this.extractDataItems = this.mySelection.map(idx => {
      return this.gridData.find(item => item.ProductID === idx);
    });
    //console.log('74', this.extractDataItems);
  }

  onblurOld(){
    if(this.formGroup.controls.oldCorporate.value){
    }else{
      this.isOldCorp =false;
    }
  }

  onblurNew(){
    if(this.formGroup.controls.newCorporate.value){
    }else{
      this.isNewCorp =false;
    }
  }
}
