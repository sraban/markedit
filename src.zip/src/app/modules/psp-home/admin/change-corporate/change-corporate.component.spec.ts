import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ChangeCorporateComponent } from './change-corporate.component';

describe('ChangeCorporateComponent', () => {
  let component: ChangeCorporateComponent;
  let fixture: ComponentFixture<ChangeCorporateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ChangeCorporateComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ChangeCorporateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
