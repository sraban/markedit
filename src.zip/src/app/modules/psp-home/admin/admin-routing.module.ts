import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminComponent } from './admin.component';
import { ChangeItemtypeComponent } from './change-itemtype/change-itemtype.component';
import { ChangeCorporateComponent } from './change-corporate/change-corporate.component';
import { ChangeDccstatusComponent } from './change-dccstatus/change-dccstatus.component';
import { CopyFormulationComponent } from './copy-formulation/copy-formulation.component';
import { DietarySupplementReviewToolComponent } from './dietary-supplement-review-tool/dietary-supplement-review-tool.component';
import { ExportFormulationComponent } from './export-formulation/export-formulation.component';
const routes: Routes = [
  {
    path: '',
    component: AdminComponent,
    children: [
      { path: '', redirectTo: 'changeItemtype', pathMatch: 'full' },
      { path: 'changeItemType', component: ChangeItemtypeComponent },
      { path: 'changeCorporate', component: ChangeCorporateComponent },
      { path: 'changeDccstatus', component: ChangeDccstatusComponent },
      { path: 'copyFormulationCpl', component: CopyFormulationComponent },
      { path: 'dietarySupplementReviewTool', component: DietarySupplementReviewToolComponent},
      { path: 'exportFormulation', component: ExportFormulationComponent }
    ]
  }];
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminRoutingModule { }
