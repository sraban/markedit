import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AdminRoutingModule } from './admin-routing.module';
import { AdminComponent } from './admin.component';
import { ChangeItemtypeComponent } from './change-itemtype/change-itemtype.component';
import { CopyFormulationComponent } from './copy-formulation/copy-formulation.component';
import { ChangeDccstatusComponent } from './change-dccstatus/change-dccstatus.component';
import { ChangeCorporateComponent } from './change-corporate/change-corporate.component';

import { LabelModule } from "@progress/kendo-angular-label";
import { InputsModule } from "@progress/kendo-angular-inputs";
import { LayoutModule } from "@progress/kendo-angular-layout";
import { ButtonsModule } from "@progress/kendo-angular-buttons";
import { IconsModule } from "@progress/kendo-angular-icons";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { AppSharedModule } from '../../../app-shared/app-shared.module';
import { ExportFormulationComponent } from './export-formulation/export-formulation.component';
import { HotTableModule } from '@handsontable/angular';
import { DietarySupplementReviewToolComponent } from './dietary-supplement-review-tool/dietary-supplement-review-tool.component';

@NgModule({
  declarations: [
    AdminComponent,
    ChangeItemtypeComponent,
    CopyFormulationComponent,
    ChangeDccstatusComponent,
    ChangeCorporateComponent,
    DietarySupplementReviewToolComponent,
    ExportFormulationComponent
  ],
  imports: [
    CommonModule,
    AdminRoutingModule, 
    AppSharedModule,
    FormsModule,
    ReactiveFormsModule,
    InputsModule,
    LabelModule,
    ButtonsModule,
    IconsModule,
    LayoutModule,
    HotTableModule
  ]
})
export class AdminModule { }
