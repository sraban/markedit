import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-change-dccstatus',
  templateUrl: './change-dccstatus.component.html',
  styleUrls: ['./change-dccstatus.component.scss']
})
export class ChangeDccstatusComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
