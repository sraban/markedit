import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ChangeDccstatusComponent } from './change-dccstatus.component';

describe('ChangeDccstatusComponent', () => {
  let component: ChangeDccstatusComponent;
  let fixture: ComponentFixture<ChangeDccstatusComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ChangeDccstatusComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ChangeDccstatusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
