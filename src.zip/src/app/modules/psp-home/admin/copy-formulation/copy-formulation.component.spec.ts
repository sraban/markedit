import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CopyFormulationComponent } from './copy-formulation.component';

describe('CopyFormulationComponent', () => {
  let component: CopyFormulationComponent;
  let fixture: ComponentFixture<CopyFormulationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CopyFormulationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CopyFormulationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
