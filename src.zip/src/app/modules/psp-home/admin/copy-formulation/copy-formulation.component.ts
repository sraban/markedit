import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-copy-formulation',
  templateUrl: './copy-formulation.component.html',
  styleUrls: ['./copy-formulation.component.scss']
})
export class CopyFormulationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
