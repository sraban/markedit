import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class AdminComponent implements OnInit {

  valueChangeItem:any;

  constructor(private routing:Router) { }

  ngOnInit(): void {
    this.valueChangeItem = this.routing.url.split('/',3)[2];
    this.valueChangeItem = this.valueChangeItem.split(/(?=[A-Z])/).join(' ');
  }

}
