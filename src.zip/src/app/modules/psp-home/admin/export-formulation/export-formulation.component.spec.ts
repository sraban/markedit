import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ExportFormulationComponent } from './export-formulation.component';

describe('ExportFormulationComponent', () => {
  let component: ExportFormulationComponent;
  let fixture: ComponentFixture<ExportFormulationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ExportFormulationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ExportFormulationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
