import { Component, OnInit, ViewChildren } from '@angular/core';
import { Validators, FormGroup, FormBuilder, FormControl } from "@angular/forms";
import { takeUntil } from 'rxjs/operators';
import { Subject } from 'rxjs';
import { PspBaseService } from '../../services/psp-base.service';
import { TranslateService } from '@ngx-translate/core';
import { BlockLike } from 'typescript';
@Component({
  selector: 'app-export-formulation',
  templateUrl: './export-formulation.component.html',
  styleUrls: ['./export-formulation.component.scss']
})
export class ExportFormulationComponent implements OnInit {
  public gridData: any;
  public notify: any;
  submitted = false;
  controlNames: any;
  isloading = false;
  formulation_flg: boolean = false;
  wpl_flg: boolean = false;
  dropItems: any;
  private isActive = new Subject();
  public form: FormGroup = new FormGroup({
    dcc: new FormControl(''),
    dsp_seq_nbr: new FormControl(''),
    compounding_flg: new FormControl(''),
  });
  constructor(private formBuilder: FormBuilder, private pspBaseService: PspBaseService, private translate: TranslateService) {
  }
  ngOnInit(): void {
    this.initializeForm();
  }
  initializeForm(): any {
    this.form = this.formBuilder.group({
      dcc: new FormControl(''),
      dsp_seq_nbr: new FormControl(''),
      wpl_flg: new FormControl(),
      formulation_flg: new FormControl(),
    });
    this.controlNames = {
      dcc: 'At least one of the parameters has to be entered ',
    };
  }
  public clearForm(): void {
    this.form.reset();
  }
  public dcc(): void {
    let dcc = this.form.controls.dcc.value;
    if (dcc.length > 6) {
      const reqObj = { dcc: dcc };
      this.gettingsequenceNo(reqObj);
      this.gettingvalidDcc(reqObj);
    }
  }
  public gettingvalidDcc(reqObj: any): any {
    this.pspBaseService
      .getvalidDcc(reqObj)
      .pipe(takeUntil(this.isActive))
      .subscribe((response: any) => {
        if (response.status === 'SUCCESS') {
          if (response.results.formulation_flg == "N")
            this.formulation_flg = false;
          else
            this.formulation_flg = true;
          if (response.results.wpl_flg == "N")
            this.wpl_flg = false;
          else
            this.wpl_flg = true;
        }
      });
  }
  // tslint:disable-next-line:typedef
  public gettingsequenceNo(reqObj: any) {
    this.dropItems = [];
    this.pspBaseService.getsequenceNo(reqObj).pipe(takeUntil(this.isActive)).subscribe(
      (response: any) => {
        if (response.status === 'SUCCESS') {
          if (response.results && response.results.length > 0) {
            response.results.forEach((row: any) => {
              this.dropItems.push({ 'DATA_VALUE': row, 'DISPLAY_VALUE': row });
            });
          } else {
            this.dropItems = [];
          }
        }
      },
      (err: any) => { }
    );
  }
  public exportForm(): any {
    this.form.markAllAsTouched();
    this.submitted = false;
    this.notify = {};
    const reqObj = {
      dcc: this.form.controls.dcc.value,
      dsp_seq_nbr: this.form.controls.dsp_seq_nbr.value,
      compounding_flg: 'N'
    };
    this.gettingexport(reqObj);
  }
  public exportcompoundForm(): any {
    this.form.markAllAsTouched();
    this.submitted = false;
    this.notify = {};
    const reqObj = {
      dcc: this.form.controls.dcc.value,
      dsp_seq_nbr: this.form.controls.dsp_seq_nbr.value,
      compounding_flg: 'Y'
    };
    this.gettingexport(reqObj);
  }
  // Search product dcc
  public gettingexport(reqObj: any) {
    this.submitted = true;
    this.notify = {};
    this.pspBaseService.getexport(reqObj).pipe(takeUntil(this.isActive)).subscribe(
      (response: any) => {
        var blob = response;
        var fileName = 'text.xls';
        console.log(blob);
        if (<any>window.navigator.msSaveOrOpenBlob) {
          alert('---');
          window.navigator.msSaveBlob(blob, fileName);
        } else {
          alert('++');
          var downloadLink = window.document.createElement('a');
          downloadLink.href = window.URL.createObjectURL(new Blob([blob], { type: 'application/octetstream' }));
          downloadLink.download = fileName;
          document.body.appendChild(downloadLink);
          downloadLink.click();
          document.body.removeChild(downloadLink);
        }
      },

      (err: any) => {
        this.notify = {
          style: 'error',
          content: 'no data'
        };
      }

    );
  }
}



