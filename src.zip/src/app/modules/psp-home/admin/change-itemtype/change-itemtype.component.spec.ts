import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ChangeItemtypeComponent } from './change-itemtype.component';

describe('ChangeItemtypeComponent', () => {
  let component: ChangeItemtypeComponent;
  let fixture: ComponentFixture<ChangeItemtypeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ChangeItemtypeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ChangeItemtypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
