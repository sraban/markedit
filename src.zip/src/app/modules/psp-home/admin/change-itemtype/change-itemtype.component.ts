import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { PspBaseService } from '../../services/psp-base.service';

@Component({
  selector: 'app-change-itemtype',
  templateUrl: './change-itemtype.component.html',
  styleUrls: ['./change-itemtype.component.scss', '../admin.component.scss']
})
export class ChangeItemtypeComponent implements OnInit {

  isloading = false;
  notify = {};
  isDCC: any = null;
  corpName = '';
  dataList: Array<{ text: string; value: string }> = [];
  itemType = '';
  item_seq = '';

  formItemType = new FormGroup({
    dcc: new FormControl(''),
    itemType: new FormControl()
  })

  constructor(private pspService: PspBaseService) { }

  ngOnInit(): void {
  }

  getDCCInfo() {
    if (this.formItemType.controls.dcc.value) {
      const reqObj = { dcc: this.formItemType.controls.dcc.value };
      this.pspService.getDCCInfo(reqObj).subscribe(
        (response: any) => {
          console.log(response);
          if (response.status === 'SUCCESS') {
            // this.corpName = response.results.co_num;
            this.item_seq = response.results.seq;
            this.isDCC = true;
          } else {
            this.isDCC = false;
          }
        },
        (error: any) => {
          this.isloading = false;
          this.notify = {
            style: 'error',
            content: 'Server Error'
          }
        }
      )
    }
  }

  onblurDCC() {
    if (this.formItemType.controls.dcc.value) {
      this.getDCCInfo();
     }
    else { this.isDCC = false }
  }

  show() {
    if (this.formItemType.controls.dcc.value) {
      this.isloading = true;
      const reqObj = { dcc: this.formItemType.controls.dcc.value };

      this.pspService.getDCCInfo(reqObj).subscribe(
        (resp: any) => {
          if (resp.status === 'SUCCESS') {
            this.corpName = resp.results.co_num;
            this.showItem(reqObj);
          } else {
            this.isloading = false;
            this.notify = {
              style: 'error',
              content: resp.results[0].message
            }
          }
        },
        (error: any) => {
          this.isloading = false;
          this.notify = {
            style: 'error',
            content: 'Server Error'
          }
        }
      )
    }

  }

  showItem(reqObj: any) {
    this.pspService.getChangeItemType(reqObj).subscribe(
      (response: any) => {
        console.log(response);
        if (response.status === 'SUCCESS') {
          this.isDCC = true;

          const getDropDown = {
            item_type: response.results[0].item_type,
            product_flg: response.results[0].product_flg
          }
          this.itemType = response.results[0].item_type_desc;

          this.pspService.getItemTypeDropDown(getDropDown).subscribe(
            (res: any) => {
              console.log(res);
              if (res.status === 'SUCCESS') {
                this.dataList =[];
                for (let i = 0; i < res.results.length; i++) {
                  this.dataList.push(
                    { value: res.results[i].DATA_VALUE, text: res.results[i].DISPLAY_VALUE }
                  );

                }
              }
            },
            (error: any) => {
              this.isloading = false;
              this.notify = {
                style: 'error',
                content: 'Server Error'
              }
            }
          )

          this.isloading = false;
        } else {
          this.notify = {
            style: 'error',
            content: response.results[0].message
          }
          this.isDCC = false;
          this.isloading = false;
        }
      },
      (error: any) => {
        this.isloading = false;
        this.notify = {
          style: 'error',
          content: 'Server Error'
        }
      }
    )
  }

  save() {
    console.log(this.formItemType.value);
    if (this.formItemType.controls.itemType.value && this.formItemType.controls.dcc.value) {
      this.isloading = true;
      const reqObj = {
        dcc: this.formItemType.controls.dcc.value,
        item_type: this.formItemType.controls.itemType.value.value,
        itm_seq: this.item_seq
      }
      console.log(reqObj);
      this.pspService.getDCCInfo({ dcc: reqObj.dcc }).subscribe(
        (resp: any) => {
          if (resp.status === 'SUCCESS') {
            this.saveItem(reqObj);
          } else {
            this.isloading = false;
            this.notify = {
              style: 'error',
              content: resp.results[0].message
            }
          }
        },
        (error: any) => {
          this.isloading = false;
          this.notify = {
            style: 'error',
            content: 'Server Error'
          }
        }
      )
    }else if(!this.formItemType.controls.itemType.value && this.formItemType.controls.dcc.value){
      this.notify={
        style: 'error',
        content: 'Please select type to change'
      }
    }

  }

  saveItem(reqObj: any) {
    this.pspService.saveItemType(reqObj).subscribe(
      (response: any) => {
        this.isloading = false;
        if (response.status === 'SUCCESS') {
          this.notify = {
            style: 'success',
            content: 'Saved Successfully..!'
          }
        } else {
          this.notify = {
            style: 'error',
            content: response.results[0].message
          }
        }
      },
      (error: any) => {
        this.isloading = false;
        this.notify = {
          style: 'error',
          content: 'Server Error'
        }
      }
    )
  }


  clear() {
    this.formItemType.reset();
    this.notify = {};
    this.isloading = false;
    this.isDCC = null;
    this.corpName = '';
    this.itemType = '';
    this.dataList = []
  }

}
